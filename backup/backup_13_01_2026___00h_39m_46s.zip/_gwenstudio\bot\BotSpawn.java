package _gwenstudio.bot;

import _gwenstudio.BotConfig;
import _gwenstudio.services.BotService;
import com.ngocrong.map.MapManager;
import com.ngocrong.map.TMap;
import com.ngocrong.map.tzone.Zone;
import com.ngocrong.util.Utils;
import java.util.ArrayList;
import java.util.List;

/**
 * Class spawn bot vào các map và zone
 * @author GwenDevStudio
 */
public class BotSpawn {
    
    private static BotSpawn instance;
    
    public static BotSpawn getInstance() {
        if (instance == null) {
            instance = new BotSpawn();
        }
        return instance;
    }
    
    private BotSpawn() {
    }
    
    /**
     * Spawn bot vào một map cụ thể
     * @param mapId ID của map
     * @param quantity Số lượng bot
     * @param customName Tên tùy chỉnh (null = random)
     * @param customCaiTrang ID caitrang (0 = random equipment)
     * @param customHead Head tùy chỉnh (-1 = random)
     * @param customBody Body tùy chỉnh (-1 = random)
     * @param customLeg Leg tùy chỉnh (-1 = random)
     * @return List các bot đã spawn
     */
    public List<Ur_BotDanhQuai> spawnBotsInMap(int mapId, int quantity, 
            String customName, int customCaiTrang, 
            short customHead, short customBody, short customLeg) {
        
        List<Ur_BotDanhQuai> spawnedBots = new ArrayList<>();
        
        TMap map = MapManager.getInstance().getMap(mapId);
        if (map == null) {
            return spawnedBots;
        }
        
        for (int i = 0; i < quantity; i++) {
            if (BotManager.getInstance().getTotalBots() >= BotConfig.MAX_TOTAL_BOTS) {
                break;
            }
            
            Zone zone = getRandomZone(map);
            if (zone == null) {
                continue;
            }
            
            if (zone.getPlayers().size() >= BotConfig.MAX_BOTS_PER_ZONE) {
                zone = map.getMinPlayerZone();
                if (zone == null || zone.getPlayers().size() >= BotConfig.MAX_BOTS_PER_ZONE) {
                    continue;
                }
            }
            
            String botName = customName != null ? customName : BotService.getInstance().generateBotName();
            Ur_BotDanhQuai bot = new Ur_BotDanhQuai(botName, zone);
            
            if (customCaiTrang > 0) {
                bot.customCaiTrang = customCaiTrang;
                bot.initAppearance();
            } else if (customHead > 0 && customBody > 0 && customLeg > 0) {
                bot.customHead = customHead;
                bot.customBody = customBody;
                bot.customLeg = customLeg;
                bot.initAppearance();
            }
            
            BotManager.getInstance().addBot(bot);
            spawnedBots.add(bot);
        }
        
        return spawnedBots;
    }
    
    /**
     * Spawn bot rải khắp các map mặc định
     * @param totalQuantity Tổng số lượng bot cần spawn (rải đều các map)
     * @return Tổng số bot đã spawn
     */
    public int spawnBotsAcrossMaps(int totalQuantity) {
        int totalSpawned = 0;
        int[] maps = BotConfig.DEFAULT_SPAWN_MAPS;
        
        if (maps.length == 0) {
            return 0;
        }
        
        int quantityPerMap = totalQuantity / maps.length;
        int remainder = totalQuantity % maps.length;
        
        for (int i = 0; i < maps.length; i++) {
            if (BotManager.getInstance().getTotalBots() >= BotConfig.MAX_TOTAL_BOTS) {
                break;
            }
            
            int quantity = quantityPerMap;
            if (i < remainder) {
                quantity++;
            }
            
            List<Ur_BotDanhQuai> bots = spawnBotsInMap(maps[i], quantity, null, 0, (short) -1, (short) -1, (short) -1);
            totalSpawned += bots.size();
        }
        
        return totalSpawned;
    }
    
    /**
     * Spawn bot vào random zone của map
     * @param map Map cần spawn
     * @return Zone được chọn
     */
    private Zone getRandomZone(TMap map) {
        if (map == null || map.zones == null || map.zones.isEmpty()) {
            return null;
        }
        
        List<Zone> availableZones = new ArrayList<>();
        for (Zone zone : map.zones) {
            if (zone != null && zone.getPlayers().size() < BotConfig.MAX_BOTS_PER_ZONE) {
                availableZones.add(zone);
            }
        }
        
        if (availableZones.isEmpty()) {
            return map.getMinPlayerZone();
        }
        
        return availableZones.get(Utils.nextInt(availableZones.size()));
    }
}
