package _gwenstudio.bot;

import com.ngocrong.map.tzone.Zone;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Manager quản lý tất cả bot trong hệ thống
 * @author GwenDevStudio
 */
public class BotManager {
    
    private static BotManager instance;
    private final List<Ur_BotDanhQuai> bots;
    
    public static BotManager getInstance() {
        if (instance == null) {
            instance = new BotManager();
        }
        return instance;
    }
    
    private BotManager() {
        this.bots = new CopyOnWriteArrayList<>();
    }
    
    /**
     * Thêm bot vào danh sách
     */
    public void addBot(Ur_BotDanhQuai bot) {
        if (bot != null && !bots.contains(bot)) {
            bots.add(bot);
        }
    }
    
    /**
     * Xóa bot khỏi danh sách
     */
    public void removeBot(Ur_BotDanhQuai bot) {
        bots.remove(bot);
    }
    
    /**
     * Lấy tổng số bot
     */
    public int getTotalBots() {
        return bots.size();
    }
    
    /**
     * Lấy danh sách tất cả bot
     */
    public List<Ur_BotDanhQuai> getAllBots() {
        return new ArrayList<>(bots);
    }
    
    /**
     * Lấy bot theo ID
     */
    public Ur_BotDanhQuai getBotById(int id) {
        for (Ur_BotDanhQuai bot : bots) {
            if (bot.id == id) {
                return bot;
            }
        }
        return null;
    }
    
    /**
     * Xóa tất cả bot trong một zone
     */
    public void removeBotsInZone(Zone zone) {
        if (zone == null) {
            return;
        }
        
        List<Ur_BotDanhQuai> toRemove = new ArrayList<>();
        for (Ur_BotDanhQuai bot : bots) {
            if (bot.zone != null && bot.zone.equals(zone)) {
                toRemove.add(bot);
            }
        }
        
        for (Ur_BotDanhQuai bot : toRemove) {
            if (bot.zone != null) {
                bot.zone.leave(bot);
            }
            bot.close();
            removeBot(bot);
        }
    }
    
    /**
     * Xóa tất cả bot
     */
    public void removeAllBots() {
        List<Ur_BotDanhQuai> toRemove = new ArrayList<>(bots);
        for (Ur_BotDanhQuai bot : toRemove) {
            if (bot.zone != null) {
                bot.zone.leave(bot);
            }
            bot.close();
        }
        bots.clear();
    }
    
    /**
     * Update tất cả bot
     */
    public void updateAllBots() {
        for (Ur_BotDanhQuai bot : bots) {
            try {
                if (bot != null && bot.zone != null) {
                    bot.update();
                }
            } catch (Exception e) {
                com.ngocrong.NQMP.UtilsNQMP.logError(e);
            }
        }
    }
}
