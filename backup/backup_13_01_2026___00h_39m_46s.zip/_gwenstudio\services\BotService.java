package _gwenstudio.services;

import _gwenstudio.BotConfig;
import com.ngocrong.item.ItemTemplate;
import com.ngocrong.server.DragonBall;
import com.ngocrong.server.Server;
import com.ngocrong.util.Utils;
import java.util.ArrayList;
import java.util.List;

/**
 * Service xử lý logic cho hệ thống Bot
 * @author GwenDevStudio
 */
public class BotService {
    
    private static BotService instance;
    
    public static BotService getInstance() {
        if (instance == null) {
            instance = new BotService();
        }
        return instance;
    }
    
    private BotService() {
    }
    
    /**
     * Generate random equipment cho bot dựa trên gender và level
     * @param gender 0=TraiDat, 1=Namec, 2=Xayda
     * @param level Level equipment (0-8)
     * @param type Type equipment (0-4: Ao, Quan, Gang, Giay, Rada)
     * @return ItemTemplate hoặc null
     */
    public ItemTemplate getRandomEquipment(byte gender, int level, byte type) {
        if (type < 0 || type > 4) {
            return null;
        }
        
        Server server = DragonBall.getInstance().getServer();
        if (server == null || server.iTemplates == null) {
            return null;
        }
        
        List<ItemTemplate> candidates = new ArrayList<>();
        
        for (ItemTemplate template : server.iTemplates.values()) {
            if (template.type == type 
                && template.gender == gender 
                && template.level == level
                && template.require <= 0) {
                candidates.add(template);
            }
        }
        
        if (candidates.isEmpty()) {
            return null;
        }
        
        return candidates.get(Utils.nextInt(candidates.size()));
    }
    
    /**
     * Generate random equipment set cho bot
     * @param gender Gender của bot
     * @return Array [head, body, leg] hoặc null
     */
    public short[] generateRandomEquipmentSet(byte gender) {
        int level = Utils.nextInt(BotConfig.MIN_EQUIPMENT_LEVEL, BotConfig.MAX_EQUIPMENT_LEVEL + 1);
        
        short[] parts = new short[3];
        
        ItemTemplate ao = getRandomEquipment(gender, level, (byte) 0);
        ItemTemplate quan = getRandomEquipment(gender, level, (byte) 1);
        ItemTemplate giay = getRandomEquipment(gender, level, (byte) 3);
        
        if (ao != null) {
            parts[0] = ao.head;
        } else {
            parts[0] = -1;
        }
        
        if (quan != null) {
            parts[1] = quan.body;
        } else {
            parts[1] = -1;
        }
        
        if (giay != null) {
            parts[2] = giay.leg;
        } else {
            parts[2] = -1;
        }
        
        return parts;
    }
    
    /**
     * Generate random name cho bot
     * @return Tên bot
     */
    public String generateBotName() {
        String[] names = {
            "Goku", "Vegeta", "Piccolo", "Gohan", "Trunks", "Goten", "Krillin", "Yamcha",
            "Tien", "Chiaotzu", "Bulma", "ChiChi", "Videl", "Pan", "Uub", "Broly",
            "Freeza", "Cell", "Buu", "Majin", "Beerus", "Whis", "Zamasu", "Black",
            "Jiren", "Hit", "Toppo", "Dyspo", "Kefla", "Caulifla", "Kale", "Cabba"
        };
        
        String baseName = names[Utils.nextInt(names.length)];
        
        if (Utils.nextInt(10) < 3) {
            baseName += Utils.nextInt(1000);
        }
        
        return BotConfig.BOT_NAME_PREFIX + baseName;
    }
    
    /**
     * Generate random stats cho bot
     * @return Array [hp, mp, damage, defense, critical]
     */
    public long[] generateRandomStats() {
        long hp = Utils.nextLong(BotConfig.DEFAULT_HP_MIN, BotConfig.DEFAULT_HP_MAX);
        long mp = BotConfig.DEFAULT_MP;
        long damage = Utils.nextLong(BotConfig.DEFAULT_DAMAGE_MIN, BotConfig.DEFAULT_DAMAGE_MAX);
        int defense = BotConfig.DEFAULT_DEFENSE;
        int critical = BotConfig.DEFAULT_CRITICAL;
        
        return new long[]{hp, mp, damage, defense, critical};
    }
    
    /**
     * Generate random power cho bot
     * @return Power value
     */
    public long generateRandomPower() {
        return Utils.nextLong(BotConfig.DEFAULT_POWER_MIN, BotConfig.DEFAULT_POWER_MAX);
    }
}
