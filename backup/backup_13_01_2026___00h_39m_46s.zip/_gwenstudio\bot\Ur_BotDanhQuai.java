package _gwenstudio.bot;

import _gwenstudio.BotConfig;
import _gwenstudio.services.BotService;
import com.ngocrong.bot.Boss;
import com.ngocrong.item.Item;
import com.ngocrong.map.tzone.Zone;
import com.ngocrong.mob.Mob;
import com.ngocrong.skill.Skills;
import com.ngocrong.util.Utils;
import java.util.ArrayList;
import java.util.List;

/**
 * Bot đánh quái - Bot giả người chơi có thể tùy chỉnh
 * @author GwenDevStudio
 */
public class Ur_BotDanhQuai extends Boss {
    
    public String customName;
    public int customCaiTrang = -1;
    public short customHead = -1;
    public short customBody = -1;
    public short customLeg = -1;
    
    public long lastAttackTime = 0;
    public Mob targetMob = null;
    
    public Ur_BotDanhQuai(String name, Zone zone) {
        super();
        
        this.customName = name != null ? name : BotService.getInstance().generateBotName();
        this.name = this.customName;
        
        BotService botService = BotService.getInstance();
        long[] stats = botService.generateRandomStats();
        long power = botService.generateRandomPower();
        
        this.setInfo(stats[0], stats[1], stats[2], (int) stats[3], (int) stats[4]);
        this.info.power = power;
        
        this.gender = (byte) Utils.nextInt(3);
        
        if (zone != null) {
            this.setX((short) Utils.nextInt(50, zone.map.width - 50));
            this.setY((short) zone.map.collisionLand(this.getX(), (short) 0));
        }
        
        this.id = Utils.nextInt(1000000, 9999999);
        this.itemBag = new Item[100];
        
        initAppearance();
        initSkill();
        
        if (zone != null) {
            zone.enter(this);
            BotManager.getInstance().addBot(this);
        }
    }
    
    public void initAppearance() {
        BotService botService = BotService.getInstance();
        
        if (customCaiTrang > 0) {
            this.setNhapThe(true);
            Item caiTrangItem = new Item(customCaiTrang);
            if (caiTrangItem.template != null && caiTrangItem.template.type == 5) {
                this.setHead(caiTrangItem.template.head);
                this.setBody(caiTrangItem.template.body);
                this.setLeg(caiTrangItem.template.leg);
                this.typePorata = getPorataType(customCaiTrang);
                this.fusionType = 6;
            }
        } else if (customHead > 0 && customBody > 0 && customLeg > 0) {
            this.setHead(customHead);
            this.setBody(customBody);
            this.setLeg(customLeg);
        } else {
            short[] equipment = botService.generateRandomEquipmentSet(this.gender);
            if (equipment[0] > 0) {
                this.setHead(equipment[0]);
            }
            if (equipment[1] > 0) {
                this.setBody(equipment[1]);
            }
            if (equipment[2] > 0) {
                this.setLeg(equipment[2]);
            }
        }
        
        this.updateSkin();
    }
    
    private byte getPorataType(int caiTrangId) {
        if (caiTrangId == 454) {
            return 0;
        } else if (caiTrangId == 921) {
            return 1;
        } else if (caiTrangId == 2374) {
            return 2;
        }
        return 0;
    }
    
    @Override
    public void initSkill() {
        try {
            skills = new ArrayList<>();
            byte skillId = (byte) (gender == 0 ? 0 : gender == 1 ? 9 : 17);
            skills.add(Skills.getSkill(skillId, (byte) 7).clone());
        } catch (CloneNotSupportedException ex) {
            com.ngocrong.NQMP.UtilsNQMP.logError(ex);
        }
    }
    
    @Override
    public void update() {
        this.info.mp = this.info.mpFull = Long.MAX_VALUE;
        
        if (this.zone == null) {
            return;
        }
        
        if (BotConfig.AUTO_ATTACK_MOBS) {
            attackMob();
        }
    }
    
    private void attackMob() {
        if (zone == null) {
            return;
        }
        
        if (targetMob == null || targetMob.status == 0 || targetMob.status == 1 
            || targetMob.isMobMe || targetMob.hp <= 0) {
            findTargetMob();
        }
        
        if (targetMob == null) {
            return;
        }
        
        if (this.skills == null || this.skills.isEmpty()) {
            return;
        }
        
        this.select = skills.get(0);
        this.select.manaUse = 0;
        
        int distanceX = Math.abs(this.getX() - targetMob.x);
        int distanceY = Math.abs(this.getY() - targetMob.y);
        
        if (distanceX > select.dx * 1.2 || distanceY > select.dy * 1.2) {
            if (this.meCanMove()) {
                this.moveTo(targetMob.x, targetMob.y);
            }
            return;
        }
        
        if (this.meCanAttack() && System.currentTimeMillis() - lastAttackTime >= BotConfig.ATTACK_COOLDOWN_MS) {
            lastAttackTime = System.currentTimeMillis();
            this.zone.attackNpc(this, targetMob, false);
        }
    }
    
    private void findTargetMob() {
        if (zone == null) {
            return;
        }
        
        List<Mob> mobs = zone.getListMob();
        double minDistance = Double.MAX_VALUE;
        Mob closestMob = null;
        
        int botX = this.getX();
        int botY = this.getY();
        
        for (Mob mob : mobs) {
            if (mob == null || mob.status == 0 || mob.status == 1 
                || mob.isMobMe || mob.hp <= 0) {
                continue;
            }
            
            double distance = Math.sqrt(
                Math.pow(mob.x - botX, 2) + Math.pow(mob.y - botY, 2)
            );
            
            if (distance < BotConfig.ATTACK_RANGE && distance < minDistance) {
                minDistance = distance;
                closestMob = mob;
            }
        }
        
        targetMob = closestMob;
    }
    
    @Override
    public boolean isBoss() {
        return false;
    }
    
    @Override
    public boolean isHuman() {
        return true;
    }
    
    @Override
    public void sendNotificationWhenAppear(String map) {
    }
    
    @Override
    public void sendNotificationWhenDead(String name) {
    }
    
    @Override
    public void setDefaultLeg() {
    }
    
    @Override
    public void setDefaultBody() {
    }
    
    @Override
    public void setDefaultHead() {
    }
    
    @Override
    public void startDie() {
        BotManager.getInstance().removeBot(this);
        super.startDie();
    }
    
    @Override
    public void close() {
        BotManager.getInstance().removeBot(this);
        super.close();
    }
}
