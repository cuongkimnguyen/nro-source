package _gwenstudio;

/**
 * Config cho hệ thống Bot mới
 * @author GwenDevStudio
 */
public class BotConfig {
    
    public static final boolean ENABLED = true;
    
    public static final int MAX_BOTS_PER_ZONE = 10;
    public static final int MAX_TOTAL_BOTS = 500;
    
    public static final long DEFAULT_HP_MIN = 10000;
    public static final long DEFAULT_HP_MAX = 50000;
    public static final long DEFAULT_MP = Long.MAX_VALUE;
    public static final long DEFAULT_DAMAGE_MIN = 100;
    public static final long DEFAULT_DAMAGE_MAX = 500;
    public static final int DEFAULT_DEFENSE = 100;
    public static final int DEFAULT_CRITICAL = 5;
    
    public static final long DEFAULT_POWER_MIN = 1_000_000L;
    public static final long DEFAULT_POWER_MAX = 10_000_000L;
    
    public static final String BOT_NAME_PREFIX = "[GWEN]";
    
    public static final int[] DEFAULT_SPAWN_MAPS = {0, 7, 14, 1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13};
    
    public static final int MIN_EQUIPMENT_LEVEL = 0;
    public static final int MAX_EQUIPMENT_LEVEL = 8;
    
    public static final int ATTACK_COOLDOWN_MS = 550;
    public static final int UPDATE_INTERVAL_MS = 1000;
    
    public static final boolean AUTO_ATTACK_MOBS = true;
    public static final int ATTACK_RANGE = 500;
}
