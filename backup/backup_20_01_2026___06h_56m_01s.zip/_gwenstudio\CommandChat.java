
package _gwenstudio;

/**
 *
 * @author GwenDevStudio
 */
public class CommandChat {

}
