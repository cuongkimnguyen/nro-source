package com.ngocrong.security;

import java.math.BigInteger;
import java.security.SecureRandom;

public class ECCAuth {

    private final SimpleECC ecc;
    private final BigInteger secret;
    private final SimpleECC.Point challengePoint;

    public ECCAuth(SimpleECC ecc) {
        this.ecc = ecc;
        ecc.testGeneratorPoint();
        SecureRandom rnd = new SecureRandom();

        // Use at least 256 bits of randomness for the secret
        this.secret = new BigInteger(256, rnd).mod(ecc.getP());
        this.challengePoint = ecc.multiply(ecc.g, secret);

        // DEBUG: In thông tin khởi tạo
        System.out.println("=== ECC AUTH INITIALIZATION ===");
        System.out.println("Curve parameters:");
        System.out.println("p: " + ecc.getP());
        System.out.println("a: " + ecc.getA());
        System.out.println("b: " + ecc.getB());
        System.out.println("Generator point G:");
        System.out.println("gx: " + ecc.g.x);
        System.out.println("gy: " + ecc.g.y);
        System.out.println("Server secret key: " + secret);
        System.out.println("Challenge point (secret * G):");
        System.out.println("cx: " + challengePoint.x);
        System.out.println("cy: " + challengePoint.y);
        System.out.println("=== END INITIALIZATION ===\n");
    }

    public SimpleECC getCurve() {
        return ecc;
    }

    public SimpleECC.Point getChallengePoint() {
        return challengePoint;
    }

    public boolean verify(SimpleECC.Point R, SimpleECC.Point S) {
        System.out.println("=== VERIFICATION PROCESS ===");
        System.out.println("Received from client:");
        System.out.println("R point:");
        System.out.println("rx: " + R.x);
        System.out.println("ry: " + R.y);
        System.out.println("S point:");
        System.out.println("sx: " + S.x);
        System.out.println("sy: " + S.y);

        // Kiểm tra điểm có trên đường cong không
        boolean rOnCurve = ecc.isOnCurve(R);
        boolean sOnCurve = ecc.isOnCurve(S);
        System.out.println("R on curve: " + rOnCurve);
        System.out.println("S on curve: " + sOnCurve);

        if (!rOnCurve || !sOnCurve) {
            System.out.println("VERIFICATION FAILED: Points not on curve");
            System.out.println("=== END VERIFICATION ===\n");
            return false;
        }

        // Tính expected = secret * R
        SimpleECC.Point expected = ecc.multiply(R, secret);
        System.out.println("Expected point (secret * R):");
        System.out.println("expected_x: " + expected.x);
        System.out.println("expected_y: " + expected.y);

        // So sánh
        boolean xMatch = expected.x.equals(S.x);
        boolean yMatch = expected.y.equals(S.y);
        boolean verified = xMatch && yMatch;

        System.out.println("X coordinates match: " + xMatch);
        System.out.println("Y coordinates match: " + yMatch);
        System.out.println("VERIFICATION RESULT: " + verified);

        if (!verified) {
            System.out.println("Expected vs Received:");
            System.out.println("Expected X: " + expected.x);
            System.out.println("Received X: " + S.x);
            System.out.println("Expected Y: " + expected.y);
            System.out.println("Received Y: " + S.y);
        }

        System.out.println("=== END VERIFICATION ===\n");
        return verified;
    }
}
