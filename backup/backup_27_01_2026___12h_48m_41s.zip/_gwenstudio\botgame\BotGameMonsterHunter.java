package _gwenstudio.botgame;

import _gwenstudio.boss.Boss;
import com.ngocrong.map.tzone.Zone;
import com.ngocrong.mob.Mob;
import com.ngocrong.network.Service;
import com.ngocrong.skill.Skill;
import com.ngocrong.skill.Skills;
import com.ngocrong.user.Info;
import com.ngocrong.util.Utils;
import org.apache.log4j.Logger;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

/**
 * Bot đánh quái đơn giản
 * Tự động tìm và tấn công quái gần nhất trong zone
 */
public class BotGameMonsterHunter extends Boss {

    private static final Logger logger = Logger.getLogger(BotGameMonsterHunter.class);

    // Mob đang nhắm tấn công
    public Mob mobTarget = null;
    
    // Thời gian tấn công lần cuối (ms)
    public long lastAttackTime = 0;
    
    // Tốc độ tấn công (ms) - mặc định 550ms
    public int attackSpeed = 550;
    
    // Thời gian spawn bot
    public long timeSpawn = System.currentTimeMillis();
    
    // Level bot (1-200)
    public int botLevel = 50;
    
    // Power bot
    public long botPower = 100000L;

    /**
     * Constructor bot đánh quái
     * @param name - Tên bot
     * @param level - Level bot (1-200)
     * @param power - Power bot
     * @param zone - Zone spawn bot
     */
    public BotGameMonsterHunter(String name, int level, long power, Zone zone) {
        super();
        this.name = name;
        this.id = Utils.nextInt(1000000, 9999999);
        this.botLevel = level;
        this.botPower = power;
        
        logger.debug(String.format("[BotGame] Tạo bot mới - Name: %s, ID: %d, Level: %d, Power: %d", 
            name, this.id, level, power));
        
        initializeBot(zone);
    }

    /**
     * Khởi tạo bot với các thông số cơ bản
     * @param zone - Zone spawn bot
     */
    private void initializeBot(Zone zone) {
        try {
            this.itemBag = new com.ngocrong.item.Item[100];
            this.gender = (byte) Utils.nextInt(3);
            
            // Tính HP, MP, Damage dựa trên power
            long hp = botPower * 10L;
            long mp = Long.MAX_VALUE;
            long dame = botPower / 10L;
            
            this.setInfo(hp, mp, dame, 100, 5);
            this.info.power = botPower;
            this.info.level = botLevel;
            
            logger.debug(String.format("[BotGame] Khởi tạo bot - HP: %d, MP: %d, Damage: %d", 
                hp, mp, dame));
            
            // Set appearance ngẫu nhiên
            setRandomAppearance();
            
            // Khởi tạo skill cho bot (phải gọi sau khi set gender)
            initSkill();
            
            // Spawn vào zone
            if (zone != null) {
                this.setX((short) Utils.nextInt(50, zone.map.width - 50));
                this.setY((short) zone.map.collisionLand(this.getX(), (short) 0));
                this.service = new Service(this);
                zone.enter(this);
                
                logger.debug(String.format("[BotGame] Bot spawn vào Map: %d, Zone: %d, X: %d, Y: %d", 
                    zone.map.mapID, zone.zoneID, this.getX(), this.getY()));
            }
        } catch (Exception e) {
            logger.error("[BotGame] Lỗi khởi tạo bot: " + e.getMessage(), e);
        }
    }

    /**
     * Set appearance ngẫu nhiên cho bot
     */
    private void setRandomAppearance() {
        try {
            short[][] hair = new short[][]{
                {64, 30, 31}, {9, 29, 32}, {6, 27, 28}
            };
            short head = hair[this.gender][Utils.nextInt(hair[this.gender].length)];
            short body = (short) (this.gender == 0 ? 14 : this.gender == 1 ? 10 : 16);
            short leg = (short) (this.gender == 0 ? 15 : this.gender == 1 ? 11 : 17);
            
            Method setHeadMethod = com.ngocrong.user.Player.class.getDeclaredMethod("setHead", short.class);
            setHeadMethod.setAccessible(true);
            setHeadMethod.invoke(this, head);
            
            Field headField = com.ngocrong.user.Player.class.getDeclaredField("head");
            Field bodyField = com.ngocrong.user.Player.class.getDeclaredField("body");
            Field legField = com.ngocrong.user.Player.class.getDeclaredField("leg");
            Field headDefaultField = com.ngocrong.user.Player.class.getDeclaredField("headDefault");
            
            headField.setAccessible(true);
            bodyField.setAccessible(true);
            legField.setAccessible(true);
            headDefaultField.setAccessible(true);
            
            headField.setShort(this, head);
            bodyField.setShort(this, body);
            legField.setShort(this, leg);
            headDefaultField.setShort(this, head);
            
            logger.debug(String.format("[BotGame] Set appearance - Gender: %d, Head: %d, Body: %d, Leg: %d", 
                this.gender, head, body, leg));
        } catch (Exception e) {
            logger.error("[BotGame] Lỗi set appearance: " + e.getMessage(), e);
        }
    }

    /**
     * Update bot mỗi frame
     * Tìm và tấn công quái gần nhất
     */
    @Override
    public void update() {
        if (this.zone == null) {
            return;
        }
        
        // Set MP = MAX để bot luôn có đủ mana
        this.info.mp = this.info.mpFull = Long.MAX_VALUE;
        
        // Nếu bot đã chết thì không làm gì
        if (this.isDead()) {
            return;
        }
        
        // Tìm và tấn công quái
        findAndAttackMob();
    }

    /**
     * Tìm và tấn công quái gần nhất
     */
    private void findAndAttackMob() {
        // Nếu đã có target, kiểm tra target còn sống không
        if (mobTarget != null) {
            if (mobTarget.hp <= 0 || mobTarget.isDead() || mobTarget.status == 0 || mobTarget.status == 1) {
                logger.debug(String.format("[BotGame] Bot %s: Target đã chết, tìm target mới", this.name));
                mobTarget = null;
                return;
            }
            
            // Kiểm tra trong tầm tấn công
            if (isInAttackRange(mobTarget)) {
                attackMob(mobTarget);
            } else {
                // Di chuyển đến target
                moveToMob(mobTarget);
            }
        } else {
            // Chưa có target, tìm quái gần nhất
            findNearestMob();
        }
    }

    /**
     * Tìm quái gần nhất trong zone
     */
    private void findNearestMob() {
        List<Mob> mobs = this.zone.getListMob();
        if (mobs == null || mobs.isEmpty()) {
            return;
        }
        
        double minDistance = Double.MAX_VALUE;
        Mob nearestMob = null;
        
        int botX = this.getX();
        int botY = this.getY();
        
        for (Mob mob : mobs) {
            // Kiểm tra mob hợp lệ
            if (mob == null || mob.hp <= 0 || mob.isDead() || 
                mob.status == 0 || mob.status == 1 || mob.isMobMe) {
                continue;
            }
            
            // Tính khoảng cách
            double distance = Math.sqrt(
                Math.pow(mob.x - botX, 2) + Math.pow(mob.y - botY, 2)
            );
            
            // Tìm mob gần nhất trong phạm vi 2000 pixel
            if (distance < minDistance && distance < 2000) {
                minDistance = distance;
                nearestMob = mob;
            }
        }
        
        if (nearestMob != null) {
            mobTarget = nearestMob;
            logger.debug(String.format("[BotGame] Bot %s: Tìm thấy target - Mob TemplateID: %d, Distance: %.2f", 
                this.name, nearestMob.templateId, minDistance));
        }
    }

    /**
     * Kiểm tra bot có trong tầm tấn công không
     * @param mob - Mob cần kiểm tra
     * @return true nếu trong tầm tấn công
     */
    private boolean isInAttackRange(Mob mob) {
        if (mob == null || this.skills == null || this.skills.isEmpty()) {
            return false;
        }
        
        Skill skill = this.skills.get(0);
        if (skill == null) {
            return false;
        }
        
        int distanceX = Math.abs(this.getX() - mob.x);
        int distanceY = Math.abs(this.getY() - mob.y);
        
        // Tầm tấn công = skill.dx * 1.2 và skill.dy * 1.2
        boolean inRange = distanceX <= skill.dx * 1.2 && distanceY <= skill.dy * 1.2;
        
        if (inRange) {
            logger.debug(String.format("[BotGame] Bot %s: Trong tầm tấn công - DistanceX: %d, DistanceY: %d", 
                this.name, distanceX, distanceY));
        }
        
        return inRange;
    }

    /**
     * Di chuyển đến mob target
     * @param mob - Mob cần di chuyển đến
     */
    private void moveToMob(Mob mob) {
        if (mob == null || !this.meCanMove()) {
            return;
        }
        
        int stepSize = 100;
        int newX = mob.x;
        int newY = mob.y;
        
        // Di chuyển từng bước nhỏ để tránh teleport
        if (Math.abs(mob.x - this.getX()) > stepSize) {
            newX = this.getX() + (mob.x > this.getX() ? stepSize : -stepSize);
        }
        
        if (Math.abs(mob.y - this.getY()) > stepSize) {
            newY = this.getY() + (mob.y > this.getY() ? stepSize : -stepSize);
        }
        
        this.moveTo((short) newX, (short) newY);
        
        logger.debug(String.format("[BotGame] Bot %s: Di chuyển đến target - X: %d, Y: %d", 
            this.name, newX, newY));
    }

    /**
     * Tấn công mob target
     * @param mob - Mob cần tấn công
     */
    private void attackMob(Mob mob) {
        if (mob == null || mob.hp <= 0 || mob.isDead()) {
            mobTarget = null;
            return;
        }
        
        // Kiểm tra có thể tấn công không
        if (!this.meCanAttack()) {
            return;
        }
        
        // Kiểm tra cooldown tấn công
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastAttackTime < attackSpeed) {
            return;
        }
        
        // Kiểm tra có skill không
        if (this.skills == null || this.skills.isEmpty()) {
            logger.debug(String.format("[BotGame] Bot %s: Không có skill, đang khởi tạo lại...", this.name));
            initSkill();
            if (this.skills == null || this.skills.isEmpty()) {
                return;
            }
        }
        
        // Chọn skill đầu tiên và tấn công
        this.select = this.skills.get(0);
        if (this.select != null) {
            this.select.manaUse = 0;
            lastAttackTime = currentTime;
            
            logger.debug(String.format("[BotGame] Bot %s: Tấn công mob TemplateID: %d, HP trước: %d, Skill ID: %d", 
                this.name, mob.templateId, mob.hp, this.select.id));
            
            this.zone.attackNpc(this, mob, false);
            
            // Log sau khi tấn công để kiểm tra damage
            logger.debug(String.format("[BotGame] Bot %s: Sau tấn công - HP mob còn lại: %d", 
                this.name, mob.hp));
        } else {
            logger.debug(String.format("[BotGame] Bot %s: Skill select là null", this.name));
        }
    }

    /**
     * Xử lý khi bot giết được mob
     * @param victim - Đối tượng bị giết
     */
    @Override
    public void kill(Object victim) {
        super.kill(victim);
        
        if (victim instanceof Mob) {
            Mob mob = (Mob) victim;
            if (mob.level > 0 && zone != null) {
                // Tính exp từ mob
                long exp = mob.level * 100L;
                exp = Zone.callEXP(this, exp);
                if (exp > 0) {
                    info.addPowerOrPotential(Info.POWER_AND_POTENTIAL, exp);
                    
                    logger.debug(String.format("[BotGame] Bot %s: Giết mob Level %d, Nhận exp: %d, Power mới: %d", 
                        this.name, mob.level, exp, info.power));
                }
            }
            // Reset target sau khi giết
            mobTarget = null;
        }
    }

    @Override
    public boolean isBoss() {
        return false;
    }

    @Override
    public boolean isHuman() {
        return true;
    }

    /**
     * Khởi tạo skill cho bot
     * Bot chỉ dùng skill đấm cơ bản (skill 0, level 1)
     */
    @Override
    public void initSkill() {
        try {
            this.skills = new java.util.ArrayList<>();
            // Skill đấm cơ bản: skill ID 0, level 1
            Skill skill = Skills.getSkill((byte) 0, (byte) 1).clone();
            skill.manaUse = 0;
            this.skills.add(skill);
            
            logger.debug(String.format("[BotGame] Bot %s: Khởi tạo skill đấm cơ bản - Skill ID: %d, Range: %dx%d", 
                this.name, skill.id, skill.dx, skill.dy));
        } catch (Exception e) {
            logger.error("[BotGame] Lỗi khởi tạo skill: " + e.getMessage(), e);
            // Fallback: tạo skill đơn giản nếu lỗi
            try {
                this.skills = new java.util.ArrayList<>();
                Skill fallbackSkill = new Skill();
                fallbackSkill.id = 0;
                fallbackSkill.manaUse = 0;
                fallbackSkill.dx = 50;
                fallbackSkill.dy = 50;
                this.skills.add(fallbackSkill);
                logger.debug("[BotGame] Sử dụng skill fallback đơn giản");
            } catch (Exception e2) {
                logger.error("[BotGame] Lỗi tạo skill fallback: " + e2.getMessage(), e2);
            }
        }
    }

    @Override
    public void setDefaultHead() {
    }

    @Override
    public void setDefaultBody() {
    }

    @Override
    public void setDefaultLeg() {
    }
}
