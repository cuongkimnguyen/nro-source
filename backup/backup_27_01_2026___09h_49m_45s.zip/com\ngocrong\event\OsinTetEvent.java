package com.ngocrong.event;

import com.ngocrong.data.OsinLixiData;
import com.ngocrong.item.Item;
import com.ngocrong.repository.GameRepository;
import com.ngocrong.repository.OsinLixiRepository;
import com.ngocrong.user.Player;
import com.ngocrong.util.Utils;

import java.time.Instant;
import java.util.Optional;

public class OsinTetEvent {

    private static OsinLixiRepository repo() {
        return GameRepository.getInstance().osinLixiRepository;
    }

    public static final int[] CHU_ANKHANG_THINHVUONG = {2462, 2463, 2464, 2465};
    public static final int[] CHU_CHUCMUNG_NAMMOI = {2466, 2467, 2468, 2469};
    public static final int[] ALL_CHU_IDS = {2462, 2463, 2464, 2465, 2466, 2467, 2468, 2469};
    public static final int REWARD_ITEM_ID = 457;
    public static final int REWARD_QUANTITY = 100;

    public static void rutLixi(Player player) {
        if (player == null) {
            return;
        }

        if (player.getSession().user.getActivated() == 0) {
            player.service.sendThongBao("Bạn cần kích hoạt thành viên để tham gia tính năng này");
            return;
        }

        Optional<OsinLixiData> existingLixiOpt = repo().findTodayByPlayer(player.id);
        if (existingLixiOpt.isPresent()) {
            player.service.sendThongBao("Bạn đã rút lì xì hôm nay rồi. Hãy quay lại vào ngày mai.");
            return;
        }

        if (player.getCountEmptyBag() == 0) {
            player.service.sendThongBao("Hành trang đã đầy");
            return;
        }

        int randomChuId = ALL_CHU_IDS[Utils.nextInt(ALL_CHU_IDS.length)];
        Item chuItem = new Item(randomChuId);
        chuItem.setDefaultOptions();
        chuItem.quantity = 1;

        if (player.addItem(chuItem)) {
            OsinLixiData newData = new OsinLixiData();
            newData.setPlayerId(player.id);
            newData.setLixiDate(Instant.now());
            repo().save(newData);

            player.service.sendThongBao("Bạn nhận được: " + chuItem.template.name);
        } else {
            player.service.sendThongBao("Không thể nhận lì xì. Hành trang đã đầy.");
        }
    }

    public static void doiChu(Player player, int[] chuIds) {
        if (player == null) {
            return;
        }

        for (int chuId : chuIds) {
            Item chuItem = player.getItemInBag(chuId);
            if (chuItem == null || chuItem.quantity < 1) {
                player.service.sendThongBao("Bạn không đủ chữ để đổi. Cần đủ 4 chữ cùng bộ.");
                return;
            }
        }

        if (player.getCountEmptyBag() == 0) {
            player.service.sendThongBao("Hành trang đã đầy. Không thể nhận quà.");
            return;
        }

        for (int chuId : chuIds) {
            Item chuItem = player.getItemInBag(chuId);
            player.removeItem(chuItem.indexUI, 1);
        }

        Item rewardItem = new Item(REWARD_ITEM_ID);
        rewardItem.setDefaultOptions();
        rewardItem.quantity = REWARD_QUANTITY;

        if (player.addItem(rewardItem)) {
            player.service.sendThongBao("Bạn đã đổi thành công! Nhận được: " + rewardItem.template.name + " x" + REWARD_QUANTITY);
        } else {
            player.service.sendThongBao("Không thể nhận quà. Hành trang đã đầy.");
            for (int chuId : chuIds) {
                Item chuItem = new Item(chuId);
                chuItem.setDefaultOptions();
                chuItem.quantity = 1;
                player.addItem(chuItem);
            }
        }
    }
}
