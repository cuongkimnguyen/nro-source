package com.ngocrong.NQMP;

import com.ngocrong.bot.VirtualBot_SoSinh;
import com.ngocrong.consts.CMDMenu;
import com.ngocrong.consts.NpcName;
import com.ngocrong.data.BotConfigData;
import com.ngocrong.lib.KeyValue;
import com.ngocrong.map.MapManager;
import com.ngocrong.map.TMap;
import com.ngocrong.map.tzone.Zone;
import com.ngocrong.repository.GameRepository;
import com.ngocrong.user.Player;
import com.ngocrong.util.Utils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class BotMenuHandler {

    public static final int CMD_Menu_Bot = 2100;
    public static BotMenuHandler instance = new BotMenuHandler();

    public static BotMenuHandler gI() {
        return instance;
    }

    public void showMenu(Player player) {
        player.menus.clear();
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo Bot", 1));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa Bot", 2));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa Bot Khu hiện tại", 3));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xem danh sách Bot", 4));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Reset tên Bot đã dùng", 5));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Thêm tên Bot", 6));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Thêm ID Cải Trang", 7));
        player.service.openUIConfirm(NpcName.CON_MEO, "Quản lý Bot", player.getPetAvatar(), player.menus);
    }

    public void perform(int idAction, Player player, Object... p) {
        switch (idAction) {
            case 1: {
                showCreateBotMenu(player);
                break;
            }
            case 2: {
                showDeleteBotMenu(player);
                break;
            }
            case 3: {
                deleteBotsInCurrentZone(player);
                break;
            }
            case 4: {
                showBotList(player);
                break;
            }
            case 5: {
                resetUsedBotNames(player);
                break;
            }
            case 10: {
                int quantity = ((Integer) p[0]);
                createBots(player, quantity);
                break;
            }
            case 20: {
                int quantity = ((Integer) p[0]);
                deleteBots(player, quantity);
                break;
            }
        }
    }

    private void showCreateBotMenu(Player player) {
        player.menus.clear();
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo 1 Bot", 10, 1));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo 5 Bot", 10, 5));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo 10 Bot", 10, 10));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo 20 Bot", 10, 20));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo 50 Bot", 10, 50));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo 100 Bot", 10, 100));
        player.service.openUIConfirm(NpcName.CON_MEO, "Chọn số lượng Bot muốn tạo", player.getPetAvatar(), player.menus);
    }

    private void showDeleteBotMenu(Player player) {
        player.menus.clear();
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa 1 Bot", 20, 1));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa 5 Bot", 20, 5));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa 10 Bot", 20, 10));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa 20 Bot", 20, 20));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa 50 Bot", 20, 50));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa tất cả Bot", 20, -1));
        player.service.openUIConfirm(NpcName.CON_MEO, "Chọn số lượng Bot muốn xóa", player.getPetAvatar(), player.menus);
    }

    public void createBots(Player player, int quantity) {
        int created = 0;
        int maxAttempts = quantity * 10;
        int attempts = 0;

        List<BotConfigData> allConfigs = GameRepository.getInstance().botConfig.findByIsUsedFalse();
        if (allConfigs.isEmpty()) {
            player.service.sendThongBao("Hết tên bot vui lòng thêm tên vào bảng bot_config");
            return;
        }

        for (int i = 0; i < quantity && attempts < maxAttempts; attempts++) {
            String botName = Player.generateCharacterName();
            boolean found = false;
            
            for (BotConfigData config : allConfigs) {
                if (config.getBotnameJson() == null || config.getBotnameJson().isEmpty()) {
                    continue;
                }
                
                try {
                    JSONArray botnameArray = new JSONArray(config.getBotnameJson());
                    for (int j = 0; j < botnameArray.length(); j++) {
                        String configBotname = botnameArray.optString(j, "");
                        
                        if (configBotname.equals(botName)) {
                            botnameArray.remove(j);
                            config.setBotnameJson(botnameArray.toString());
                            
                            if (botnameArray.length() == 0) {
                                config.setIsUsed(true);
                            }
                            
                            GameRepository.getInstance().botConfig.save(config);
                            
                            VirtualBot_SoSinh bot = new VirtualBot_SoSinh(botName);
                            bot.setLocation(0, -1);
                            UtilsNQMP.lastCreateBot = System.currentTimeMillis();
                            created++;
                            i++;
                            found = true;
                            break;
                        }
                    }
                    if (found) {
                        break;
                    }
                } catch (Exception e) {
                    continue;
                }
            }
        }

        if (created > 0) {
            player.service.sendThongBao("Đã tạo " + created + " Bot");
        }
        if (created < quantity) {
            player.service.sendThongBao("Hết tên bot vui lòng thêm tên vào bảng bot_config");
        }
    }

    private void deleteBots(Player player, int quantity) {
        int deleted = 0;
        List<Player> botsToDelete = new ArrayList<>();

        for (TMap map : MapManager.getInstance().maps.values()) {
            if (map == null || map.zones == null) {
                continue;
            }
            for (Zone zone : map.zones) {
                if (zone == null || zone.players == null) {
                    continue;
                }
                synchronized (zone.players) {
                    for (Player p : zone.players) {
                        if (p != null && p instanceof VirtualBot_SoSinh && !p.equals(player)) {
                            botsToDelete.add(p);
                            if (quantity > 0 && botsToDelete.size() >= quantity) {
                                break;
                            }
                        }
                    }
                }
                if (quantity > 0 && botsToDelete.size() >= quantity) {
                    break;
                }
            }
            if (quantity > 0 && botsToDelete.size() >= quantity) {
                break;
            }
        }

        for (Player bot : botsToDelete) {
            if (bot.zone != null) {
                bot.zone.leave(bot);
                bot.close();
                deleted++;
            }
        }

        player.service.sendThongBao("Đã xóa " + deleted + " Bot");
    }

    private void deleteBotsInCurrentZone(Player player) {
        if (player.zone == null) {
            return;
        }

        int deleted = 0;
        List<Player> botsToDelete = new ArrayList<>();

        synchronized (player.zone.players) {
            for (Player p : player.zone.players) {
                if (p != null && p instanceof VirtualBot_SoSinh && !p.equals(player)) {
                    botsToDelete.add(p);
                }
            }
        }

        for (Player bot : botsToDelete) {
            player.zone.leave(bot);
            bot.close();
            deleted++;
        }

        player.service.sendThongBao("Đã xóa " + deleted + " Bot trong khu hiện tại");
    }

    private void showBotList(Player player) {
        int totalBots = 0;
        StringBuilder botList = new StringBuilder("Danh sách Bot:\n");

        for (TMap map : MapManager.getInstance().maps.values()) {
            if (map == null || map.zones == null) {
                continue;
            }
            for (Zone zone : map.zones) {
                if (zone == null || zone.players == null) {
                    continue;
                }
                synchronized (zone.players) {
                    for (Player p : zone.players) {
                        if (p != null && p instanceof VirtualBot_SoSinh) {
                            totalBots++;
                            if (totalBots <= 20) {
                                botList.append("- ").append(p.name).append(" (Map: ").append(zone.map.mapID).append(")\n");
                            }
                        }
                    }
                }
            }
        }

        if (totalBots > 20) {
            botList.append("... và ").append(totalBots - 20).append(" Bot khác");
        }

        botList.append("\nTổng: ").append(totalBots).append(" Bot");

        player.service.sendThongBao(botList.toString());
    }

    private void resetUsedBotNames(Player player) {
        try {
            List<BotConfigData> allConfigs = GameRepository.getInstance().botConfig.findAll();
            int resetCount = 0;

            for (BotConfigData config : allConfigs) {
                if (config.getIsUsed() != null && config.getIsUsed()) {
                    config.setIsUsed(false);
                    GameRepository.getInstance().botConfig.save(config);
                    resetCount++;
                }
            }

            player.service.sendThongBao("Đã reset " + resetCount + " config Bot");
        } catch (Exception e) {
            player.service.sendThongBao("Lỗi khi reset config Bot");
        }
    }

    public void addBotNames(Player player, String namesStr) {
        try {
            if (namesStr == null || namesStr.trim().isEmpty()) {
                player.service.sendThongBao("Vui lòng nhập tên bot, cách nhau bởi dấu phẩy");
                return;
            }

            String[] names = namesStr.split(",");
            List<BotConfigData> allConfigs = GameRepository.getInstance().botConfig.findByIsUsedFalse();
            
            if (allConfigs.isEmpty()) {
                BotConfigData newConfig = new BotConfigData();
                newConfig.setBotnameJson("[]");
                newConfig.setCaitrangIdJson("[]");
                newConfig.setRatioCaitrang(30);
                newConfig.setRatioTrangbi(70);
                newConfig.setIsUsed(false);
                allConfigs.add(newConfig);
            }

            BotConfigData config = allConfigs.get(0);
            JSONArray botnameArray = new JSONArray();
            
            if (config.getBotnameJson() != null && !config.getBotnameJson().isEmpty()) {
                botnameArray = new JSONArray(config.getBotnameJson());
            }

            int added = 0;
            for (String name : names) {
                name = name.trim();
                if (!name.isEmpty()) {
                    boolean exists = false;
                    for (int i = 0; i < botnameArray.length(); i++) {
                        if (botnameArray.getString(i).equals(name)) {
                            exists = true;
                            break;
                        }
                    }
                    if (!exists) {
                        botnameArray.put(name);
                        added++;
                    }
                }
            }

            config.setBotnameJson(botnameArray.toString());
            GameRepository.getInstance().botConfig.save(config);

            player.service.sendThongBao("Đã thêm " + added + " tên bot vào config");
        } catch (Exception e) {
            player.service.sendThongBao("Lỗi khi thêm tên bot: " + e.getMessage());
        }
    }

    public void addCaiTrangIds(Player player, String idsStr) {
        try {
            if (idsStr == null || idsStr.trim().isEmpty()) {
                player.service.sendThongBao("Vui lòng nhập ID cải trang, cách nhau bởi dấu phẩy");
                return;
            }

            String[] ids = idsStr.split(",");
            List<BotConfigData> allConfigs = GameRepository.getInstance().botConfig.findByIsUsedFalse();
            
            if (allConfigs.isEmpty()) {
                BotConfigData newConfig = new BotConfigData();
                newConfig.setBotnameJson("[]");
                newConfig.setCaitrangIdJson("[]");
                newConfig.setRatioCaitrang(30);
                newConfig.setRatioTrangbi(70);
                newConfig.setIsUsed(false);
                allConfigs.add(newConfig);
            }

            BotConfigData config = allConfigs.get(0);
            JSONArray caitrangArray = new JSONArray();
            
            if (config.getCaitrangIdJson() != null && !config.getCaitrangIdJson().isEmpty()) {
                caitrangArray = new JSONArray(config.getCaitrangIdJson());
            }

            int added = 0;
            for (String idStr : ids) {
                idStr = idStr.trim();
                if (!idStr.isEmpty()) {
                    try {
                        int id = Integer.parseInt(idStr);
                        boolean exists = false;
                        for (int i = 0; i < caitrangArray.length(); i++) {
                            if (caitrangArray.getInt(i) == id) {
                                exists = true;
                                break;
                            }
                        }
                        if (!exists) {
                            caitrangArray.put(id);
                            added++;
                        }
                    } catch (NumberFormatException e) {
                        continue;
                    }
                }
            }

            config.setCaitrangIdJson(caitrangArray.toString());
            GameRepository.getInstance().botConfig.save(config);

            player.service.sendThongBao("Đã thêm " + added + " ID cải trang vào config");
        } catch (Exception e) {
            player.service.sendThongBao("Lỗi khi thêm ID cải trang: " + e.getMessage());
        }
    }
}
