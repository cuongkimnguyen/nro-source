package com.ngocrong.data;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "nr_bo_mong_moc_diem")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BoMongMocDiemData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    public Integer id;

    @Column(name = "diem_can_thiet")
    public Integer diemCanThiet;

    @Column(name = "item_id_1")
    public Integer itemId1;

    @Column(name = "item_id_2")
    public Integer itemId2;

    @Column(name = "item_id_3")
    public Integer itemId3;

    @Column(name = "item_id_4")
    public Integer itemId4;

    @Column(name = "quantity_1")
    public Integer quantity1;

    @Column(name = "quantity_2")
    public Integer quantity2;

    @Column(name = "quantity_3")
    public Integer quantity3;

    @Column(name = "quantity_4")
    public Integer quantity4;

    @Column(name = "active")
    public Integer active;

    @Column(name = "sort_order")
    public Integer sortOrder;
}
