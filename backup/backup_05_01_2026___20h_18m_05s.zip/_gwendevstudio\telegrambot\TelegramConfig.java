package _gwendevstudio.telegrambot;

import com.ngocrong.server.Config;
import org.apache.log4j.Logger;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

public class TelegramConfig {
    
    private static final Logger logger = Logger.getLogger(TelegramConfig.class);
    
    public static String BOT_TOKEN;
    public static String CHAT_ID;
    public static boolean ENABLED = false;
    public static boolean AUTO_CCU_ENABLED = false;
    public static int AUTO_CCU_INTERVAL = 300;
    public static boolean USE_PROXY = false;
    public static String PROXY_HOST = "148.163.101.4";
    public static int PROXY_PORT = 11677;
    public static String PROXY_USERNAME = "dfsg68uwerg";
    public static String PROXY_PASSWORD = "sdf356y45";
    
    public static void load() {
        try {
            InputStream input = Config.class.getClassLoader().getResourceAsStream("application.properties");
            Properties props = new Properties();
            props.load(new InputStreamReader(input, StandardCharsets.UTF_8));
            
            BOT_TOKEN = props.getProperty("game.bot_token");
            CHAT_ID = props.getProperty("game.chat_id");
            String enabledStr = props.getProperty("game.telegram.enabled");
            if (enabledStr != null) {
                ENABLED = "true".equals(enabledStr) || "1".equals(enabledStr);
            } else {
                String logCcuStr = props.getProperty("game.log_ccu");
                ENABLED = (BOT_TOKEN != null && !BOT_TOKEN.isEmpty() && CHAT_ID != null && !CHAT_ID.isEmpty()) 
                        && ("1".equals(logCcuStr) || "true".equals(logCcuStr));
            }
            
            String autoCcuStr = props.getProperty("game.telegram.auto_ccu");
            if (autoCcuStr != null) {
                AUTO_CCU_ENABLED = "true".equals(autoCcuStr) || "1".equals(autoCcuStr);
            } else {
                String logCcuStr = props.getProperty("game.log_ccu");
                AUTO_CCU_ENABLED = "1".equals(logCcuStr) || "true".equals(logCcuStr);
            }
            
            String intervalStr = props.getProperty("game.telegram.ccu_interval", "300");
            try {
                AUTO_CCU_INTERVAL = Integer.parseInt(intervalStr);
            } catch (NumberFormatException e) {
                AUTO_CCU_INTERVAL = 300;
            }
            
            String useProxyStr = props.getProperty("game.telegram.use_proxy", "false");
            USE_PROXY = "true".equals(useProxyStr) || "1".equals(useProxyStr);
            
            String proxyHost = props.getProperty("game.telegram.proxy_host");
            if (proxyHost != null && !proxyHost.isEmpty()) {
                PROXY_HOST = proxyHost;
            }
            
            String proxyPortStr = props.getProperty("game.telegram.proxy_port");
            if (proxyPortStr != null && !proxyPortStr.isEmpty()) {
                try {
                    PROXY_PORT = Integer.parseInt(proxyPortStr);
                } catch (NumberFormatException e) {
                }
            }
            
            String proxyUser = props.getProperty("game.telegram.proxy_username");
            if (proxyUser != null && !proxyUser.isEmpty()) {
                PROXY_USERNAME = proxyUser;
            }
            
            String proxyPass = props.getProperty("game.telegram.proxy_password");
            if (proxyPass != null && !proxyPass.isEmpty()) {
                PROXY_PASSWORD = proxyPass;
            }
            
            logger.info("Telegram Bot Config loaded - Enabled: " + ENABLED + ", Auto CCU: " + AUTO_CCU_ENABLED);
        } catch (Exception ex) {
            logger.error("Failed to load Telegram config", ex);
        }
    }
}
