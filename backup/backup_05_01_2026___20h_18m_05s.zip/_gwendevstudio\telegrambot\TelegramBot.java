package _gwendevstudio.telegrambot;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

public class TelegramBot {
    
    private static final Logger logger = Logger.getLogger(TelegramBot.class);
    private static Thread botThread;
    private static boolean running = false;
    private static long lastUpdateId = 0;
    
    public static void start() {
        logger.info("Attempting to start Telegram bot...");
        logger.info("ENABLED: " + TelegramConfig.ENABLED);
        logger.info("BOT_TOKEN: " + (TelegramConfig.BOT_TOKEN != null && !TelegramConfig.BOT_TOKEN.isEmpty() ? "SET" : "NOT SET"));
        logger.info("CHAT_ID: " + (TelegramConfig.CHAT_ID != null && !TelegramConfig.CHAT_ID.isEmpty() ? "SET" : "NOT SET"));
        
        if (!TelegramConfig.ENABLED) {
            logger.info("Telegram bot is disabled in config");
            return;
        }
        
        if (TelegramConfig.BOT_TOKEN == null || TelegramConfig.BOT_TOKEN.isEmpty()) {
            logger.error("Telegram bot token is not configured");
            return;
        }
        
        if (running) {
            logger.warn("Telegram bot is already running");
            return;
        }
        
        running = true;
        botThread = new Thread(() -> {
            logger.info("Telegram bot thread started, beginning long polling...");
            
            while (running) {
                try {
                    String response = TelegramBotService.getUpdates(lastUpdateId + 1);
                    
                    if (response != null && !response.isEmpty()) {
                        try {
                            JSONObject json = new JSONObject(response);
                            if (json.getBoolean("ok")) {
                                JSONArray results = json.getJSONArray("result");
                                if (results.length() > 0) {
                                    logger.debug("Received " + results.length() + " updates");
                                    TelegramCommandHandler.processUpdate(response);
                                    
                                    JSONObject lastUpdate = results.getJSONObject(results.length() - 1);
                                    lastUpdateId = lastUpdate.getLong("update_id");
                                }
                            } else {
                                logger.warn("Telegram API returned error: " + response);
                            }
                        } catch (Exception e) {
                            logger.error("Error parsing update", e);
                        }
                    }
                    
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    logger.info("Telegram bot thread interrupted");
                    break;
                } catch (Exception e) {
                    logger.error("Error in Telegram bot loop", e);
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
            
            logger.info("Telegram bot stopped");
        }, "TelegramBot-Thread");
        
        botThread.setDaemon(true);
        botThread.start();
        
        TelegramScheduler.start();
    }
    
    public static void stop() {
        running = false;
        
        if (botThread != null && botThread.isAlive()) {
            botThread.interrupt();
            try {
                botThread.join(5000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        
        TelegramScheduler.stop();
        logger.info("Telegram bot stopped");
    }
    
    public static boolean isRunning() {
        return running;
    }
    
    public static void sendCCU() {
        TelegramScheduler.sendCCUNow();
    }
}

