package _gwenstudio.bomongtask;

import com.ngocrong.util.Utils;
import com.ngocrong.server.mysql.MySQLConnect;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class BoMongNhiemVu {

    public static final int LOAI_KILL_MOB = 1;
    public static final int LOAI_NAP_TIEN = 2;
    public static final int LOAI_DAT_SM = 3;
    public static final int LOAI_KILL_BOSS = 4;
    public static final int LOAI_NANG_TRANG_BI = 5;
    public static final int LOAI_TRAIN = 6;
    public static final int LOAI_LAM_TASK = 7;

    public static final int DO_KHO_EASY = 0;
    public static final int DO_KHO_NORMAL = 1;
    public static final int DO_KHO_HARD = 2;

    public int loaiNv;
    public int doKho;
    public int yeuCau;
    public int tienDo;
    public String[] bossIds;

    public static class CauHinhNv {
        int loaiNv;
        int doKho;
        int yeuCauMin;
        int yeuCauMax;
        int diemMin;
        int diemMax;
    }

    private static List<CauHinhNv> CAU_HINH_NV = new ArrayList<>();
    private static int MAX_TASK_ID = 26;
    private static int TY_LE_EASY = 50;
    private static int TY_LE_NORMAL = 35;
    private static int TY_LE_HARD = 15;

    public static void loadConfig() {
        CAU_HINH_NV.clear();

        try {
            Connection conn = MySQLConnect.getConnection();
            if (conn == null) {
                return;
            }
            String sql = "SELECT loai_nv, do_kho, yeu_cau_min, yeu_cau_max, diem_min, diem_max " +
                    "FROM nr_bo_mong_nhiem_vu_config WHERE active = 1";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                CauHinhNv config = new CauHinhNv();
                config.loaiNv = rs.getInt("loai_nv");
                config.doKho = rs.getInt("do_kho");
                config.yeuCauMin = rs.getInt("yeu_cau_min");
                config.yeuCauMax = rs.getInt("yeu_cau_max");
                config.diemMin = rs.getInt("diem_min");
                config.diemMax = rs.getInt("diem_max");
                CAU_HINH_NV.add(config);
            }
            rs.close();
            ps.close();

            sql = "SELECT config_value FROM nr_bo_mong_config WHERE config_key = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, "ty_le_easy");
            rs = ps.executeQuery();
            if (rs.next()) {
                TY_LE_EASY = Integer.parseInt(rs.getString("config_value"));
            }
            rs.close();

            ps.setString(1, "ty_le_normal");
            rs = ps.executeQuery();
            if (rs.next()) {
                TY_LE_NORMAL = Integer.parseInt(rs.getString("config_value"));
            }
            rs.close();

            ps.setString(1, "ty_le_hard");
            rs = ps.executeQuery();
            if (rs.next()) {
                TY_LE_HARD = Integer.parseInt(rs.getString("config_value"));
            }
            rs.close();

            ps.setString(1, "max_task_id");
            rs = ps.executeQuery();
            if (rs.next()) {
                MAX_TASK_ID = Integer.parseInt(rs.getString("config_value"));
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static BoMongNhiemVu randomNhiemVu(long currentPower, int currentTaskId) {
        if (CAU_HINH_NV.isEmpty()) {
            loadConfig();
        }

        int random = Utils.nextInt(100);
        int doKho;
        if (random < TY_LE_EASY) {
            doKho = DO_KHO_EASY;
        } else if (random < TY_LE_EASY + TY_LE_NORMAL) {
            doKho = DO_KHO_NORMAL;
        } else {
            doKho = DO_KHO_HARD;
        }

        int maxRetry = 10;
        CauHinhNv config = null;
        int loaiNv = 0;

        for (int retry = 0; retry < maxRetry; retry++) {
            loaiNv = Utils.nextInt(7) + 1;

            for (CauHinhNv c : CAU_HINH_NV) {
                if (c.loaiNv == loaiNv && c.doKho == doKho) {
                    if (loaiNv == LOAI_DAT_SM) {
                        if (currentPower >= c.yeuCauMax) {
                            continue;
                        }
                        if (currentPower >= c.yeuCauMin) {
                            c.yeuCauMin = (int) Math.min(currentPower + 1, c.yeuCauMax);
                        }
                    }

                    if (loaiNv == LOAI_LAM_TASK) {
                        int taskConLai = MAX_TASK_ID - currentTaskId;
                        if (taskConLai < c.yeuCauMin) {
                            continue;
                        }
                        if (taskConLai < c.yeuCauMax) {
                            c.yeuCauMax = Math.max(c.yeuCauMin, taskConLai);
                        }
                    }

                    config = c;
                    break;
                }
            }

            if (config != null) {
                break;
            }
        }

        if (config == null) {
            return null;
        }

        BoMongNhiemVu nv = new BoMongNhiemVu();
        nv.loaiNv = loaiNv;
        nv.doKho = doKho;
        nv.yeuCau = Utils.nextInt(config.yeuCauMax - config.yeuCauMin + 1) + config.yeuCauMin;
        nv.tienDo = 0;

        if (loaiNv == LOAI_KILL_BOSS) {
            nv.bossIds = getBossNamesByDifficulty(doKho);
        }

        if (loaiNv == LOAI_DAT_SM && currentPower >= nv.yeuCau) {
            nv.tienDo = nv.yeuCau;
        }

        return nv;
    }

    public static String[] getBossNamesByDifficulty(int doKho) {
        List<String> bossList = new ArrayList<>();
        try {
            Connection conn = MySQLConnect.getConnection();
            if (conn == null) {
                return new String[0];
            }
            String sql = "SELECT boss_class_name FROM nr_bo_mong_boss_config WHERE do_kho = ? AND active = 1";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, doKho);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                bossList.add(rs.getString("boss_class_name"));
            }
            rs.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return bossList.toArray(new String[0]);
    }

    public static int tinhDiemThuong(int doKho) {
        CauHinhNv config = null;
        for (CauHinhNv c : CAU_HINH_NV) {
            if (c.doKho == doKho) {
                config = c;
                break;
            }
        }
        if (config == null) {
            return 1;
        }
        return Utils.nextInt(config.diemMax - config.diemMin + 1) + config.diemMin;
    }

    public static int tinhDiemThuong(int loaiNv, int doKho) {
        for (CauHinhNv c : CAU_HINH_NV) {
            if (c.loaiNv == loaiNv && c.doKho == doKho) {
                return Utils.nextInt(c.diemMax - c.diemMin + 1) + c.diemMin;
            }
        }
        return 1;
    }
}

