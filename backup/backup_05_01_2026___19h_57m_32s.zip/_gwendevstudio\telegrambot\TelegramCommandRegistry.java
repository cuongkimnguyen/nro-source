package _gwendevstudio.telegrambot;

import org.apache.log4j.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiFunction;

public class TelegramCommandRegistry {
    
    private static final Logger logger = Logger.getLogger(TelegramCommandRegistry.class);
    private static final Map<String, BiFunction<String, String, String>> commands = new HashMap<>();
    
    static {
        registerCommand("/ccu", TelegramCommandHandler::handleCCU);
    }
    
    public static void registerCommand(String command, BiFunction<String, String, String> handler) {
        commands.put(command.toLowerCase(), handler);
        logger.debug("Registered command: " + command);
    }
    
    public static String executeCommand(String command, String chatId, String username) {
        String commandKey = command.toLowerCase();
        BiFunction<String, String, String> handler = commands.get(commandKey);
        
        if (handler != null) {
            logger.info("Executing command: " + command + " for chat: " + chatId);
            return handler.apply(chatId, username);
        }
        
        logger.debug("Command not found: " + command);
        return null;
    }
    
    public static boolean hasCommand(String command) {
        return commands.containsKey(command.toLowerCase());
    }
}

