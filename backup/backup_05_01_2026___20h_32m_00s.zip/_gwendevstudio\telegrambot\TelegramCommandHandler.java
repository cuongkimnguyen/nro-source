package _gwendevstudio.telegrambot;

import com.ngocrong.data.UserData;
import com.ngocrong.repository.GameRepository;
import com.ngocrong.server.Config;
import com.ngocrong.server.DragonBall;
import com.ngocrong.server.Server;
import com.ngocrong.server.ServerMaintenance;
import com.ngocrong.server.SessionManager;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class TelegramCommandHandler {
    
    private static final Logger logger = Logger.getLogger(TelegramCommandHandler.class);
    
    public static String handleCCU(String[] args) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String formattedTime = LocalDateTime.now().format(formatter);
        
        int totalSessions = SessionManager.sessions.size();
        long totalPlayers = SessionManager.getCountPlayer();
        
        StringBuilder sb = new StringBuilder();
        sb.append("THONG KE CCU\n");
        sb.append("━━━━━━━━━━━━━━━━━━\n");
        sb.append("Thoi gian: ").append(formattedTime).append("\n");
        sb.append("Server ID: ").append(Config.serverID()).append("\n");
        sb.append("Tong Session: ").append(totalSessions).append("\n");
        sb.append("Player Online: ").append(totalPlayers).append("\n");
        sb.append("━━━━━━━━━━━━━━━━━━");
        
        return sb.toString();
    }
    
    public static String handleBaoTri(String[] args) {
        try {
            Server server = DragonBall.getInstance().getServer();
            
            if (server.isMaintained) {
                return "Server dang trong che do bao tri!";
            }
            
            if (args == null || args.length < 1) {
                return "Cu phap: /baotri <thoi_gian>\nVi du: /baotri 30 (30 giay)\nVi du: /baotri 5m (5 phut)";
            }
            
            String timeStr = args[0].trim().toLowerCase();
            int seconds = 0;
            
            if (timeStr.endsWith("m")) {
                try {
                    int minutes = Integer.parseInt(timeStr.substring(0, timeStr.length() - 1));
                    seconds = minutes * 60;
                } catch (NumberFormatException e) {
                    return "Thoi gian khong hop le! Su dung: /baotri 30 hoac /baotri 5m";
                }
            } else {
                try {
                    seconds = Integer.parseInt(timeStr);
                } catch (NumberFormatException e) {
                    return "Thoi gian khong hop le! Su dung: /baotri 30 hoac /baotri 5m";
                }
            }
            
            if (seconds <= 0) {
                return "Thoi gian phai lon hon 0!";
            }
            
            if (seconds > 3600) {
                return "Thoi gian toi da la 60 phut (3600 giay)!";
            }
            
            ServerMaintenance serverMaintenance = new ServerMaintenance("Bảo trì từ GwenDevStudio", seconds);
            Thread t = new Thread(serverMaintenance);
            t.start();
            
            int minutes = seconds / 60;
            int remainingSeconds = seconds % 60;
            String timeDisplay = minutes > 0 ? minutes + " phút " + remainingSeconds + " giây" : seconds + " giây";
            
            StringBuilder sb = new StringBuilder();
            sb.append("Da khoi dong bao tri server!\n");
            sb.append("━━━━━━━━━━━━━━━━━━\n");
            sb.append("Thoi gian dem nguoc: ").append(timeDisplay).append("\n");
            sb.append("Thong bao: Bao tri tu Telegram Bot\n");
            sb.append("━━━━━━━━━━━━━━━━━━");
            
            logger.info("Maintenance started from Telegram: " + seconds + " seconds");
            
            return sb.toString();
        } catch (Exception e) {
            logger.error("Error handling baotri command", e);
            return "Da xay ra loi khi khoi dong bao tri: " + e.getMessage();
        }
    }
    
    public static String handleMoney(String[] args) {
        try {
            if (args == null || args.length < 1) {
                return "Cu phap:\n/money add <ten_tk> <so_tien>\n/money remove <ten_tk> <so_tien>\n/money top";
            }
            
            String action = args[0].toLowerCase();
            
            if (action.equals("add")) {
                if (args.length < 3) {
                    return "Cu phap: /money add <ten_tk> <so_tien>";
                }
                
                String username = args[1];
                long amount;
                try {
                    amount = Long.parseLong(args[2]);
                    if (amount <= 0) {
                        return "So tien phai lon hon 0!";
                    }
                } catch (NumberFormatException e) {
                    return "So tien khong hop le!";
                }
                
                List<UserData> users = GameRepository.getInstance().user.findByUsername(username);
                if (users.isEmpty()) {
                    return "Khong tim thay tai khoan: " + username;
                }
                
                int updated = GameRepository.getInstance().user.addVnd(username, amount);
                if (updated > 0) {
                    UserData user = users.get(0);
                    long newVnd = (user.getVnd() != null ? user.getVnd() : 0) + amount;
                    
                    StringBuilder sb = new StringBuilder();
                    sb.append("Da them tien thanh cong!\n");
                    sb.append("━━━━━━━━━━━━━━━━━━\n");
                    sb.append("Tai khoan: ").append(username).append("\n");
                    sb.append("So tien them: ").append(amount).append("\n");
                    sb.append("Tong tien hien tai: ").append(newVnd).append("\n");
                    sb.append("━━━━━━━━━━━━━━━━━━");
                    
                    logger.info("Added " + amount + " VND to user: " + username);
                    return sb.toString();
                } else {
                    return "Khong the cap nhat tien cho tai khoan: " + username;
                }
                
            } else if (action.equals("remove")) {
                if (args.length < 3) {
                    return "Cu phap: /money remove <ten_tk> <so_tien>";
                }
                
                String username = args[1];
                long amount;
                try {
                    amount = Long.parseLong(args[2]);
                    if (amount <= 0) {
                        return "So tien phai lon hon 0!";
                    }
                } catch (NumberFormatException e) {
                    return "So tien khong hop le!";
                }
                
                List<UserData> users = GameRepository.getInstance().user.findByUsername(username);
                if (users.isEmpty()) {
                    return "Khong tim thay tai khoan: " + username;
                }
                
                UserData user = users.get(0);
                long currentVnd = user.getVnd() != null ? user.getVnd() : 0;
                
                if (currentVnd < amount) {
                    return "Tai khoan khong du tien! Hien co: " + currentVnd;
                }
                
                int updated = GameRepository.getInstance().user.removeVnd(username, amount);
                if (updated > 0) {
                    long newVnd = currentVnd - amount;
                    
                    StringBuilder sb = new StringBuilder();
                    sb.append("Da tru tien thanh cong!\n");
                    sb.append("━━━━━━━━━━━━━━━━━━\n");
                    sb.append("Tai khoan: ").append(username).append("\n");
                    sb.append("So tien tru: ").append(amount).append("\n");
                    sb.append("Tong tien hien tai: ").append(newVnd).append("\n");
                    sb.append("━━━━━━━━━━━━━━━━━━");
                    
                    logger.info("Removed " + amount + " VND from user: " + username);
                    return sb.toString();
                } else {
                    return "Khong the cap nhat tien cho tai khoan: " + username;
                }
                
            } else if (action.equals("top")) {
                List<UserData> topUsers = GameRepository.getInstance().user.findTopVnd(50);
                
                if (topUsers.isEmpty()) {
                    return "Chua co du lieu!";
                }
                
                StringBuilder sb = new StringBuilder();
                sb.append("TOP 50 TAI KHOAN CO TIEN NHIEU NHAT\n");
                sb.append("━━━━━━━━━━━━━━━━━━\n");
                
                for (int i = 0; i < topUsers.size(); i++) {
                    UserData user = topUsers.get(i);
                    long vnd = user.getVnd() != null ? user.getVnd() : 0;
                    sb.append(String.format("%2d. %-20s : %,d VND\n", i + 1, user.getUsername(), vnd));
                }
                
                sb.append("━━━━━━━━━━━━━━━━━━");
                
                return sb.toString();
                
            } else {
                return "Lenh khong hop le! Su dung: add, remove, hoac top";
            }
            
        } catch (Exception e) {
            logger.error("Error handling money command", e);
            return "Da xay ra loi: " + e.getMessage();
        }
    }
    
    public static void processUpdate(String jsonResponse) {
        try {
            JSONObject json = new JSONObject(jsonResponse);
            if (!json.getBoolean("ok")) {
                logger.warn("Telegram API returned not ok: " + jsonResponse);
                return;
            }
            
            JSONArray results = json.getJSONArray("result");
            logger.debug("Processing " + results.length() + " updates");
            
            for (int i = 0; i < results.length(); i++) {
                JSONObject update = results.getJSONObject(i);
                
                JSONObject message = null;
                if (update.has("message")) {
                    message = update.getJSONObject("message");
                } else if (update.has("channel_post")) {
                    message = update.getJSONObject("channel_post");
                } else if (update.has("edited_message")) {
                    message = update.getJSONObject("edited_message");
                } else if (update.has("edited_channel_post")) {
                    message = update.getJSONObject("edited_channel_post");
                }
                
                if (message != null && message.has("text")) {
                    String text = message.getString("text");
                    JSONObject chat = message.getJSONObject("chat");
                    String chatId = String.valueOf(chat.getLong("id"));
                    String username = "Unknown";
                    
                    if (chat.has("username")) {
                        username = chat.getString("username");
                    } else if (chat.has("first_name")) {
                        username = chat.getString("first_name");
                    } else if (chat.has("title")) {
                        username = chat.getString("title");
                    }
                    
                    logger.info("Received message: " + text + " from chat: " + chatId + " (" + username + ")");
                    
                    if (text.startsWith("/")) {
                        String[] parts = text.split(" ", 2);
                        String command = parts[0];
                        String[] args = parts.length > 1 ? parts[1].split(" ") : new String[0];
                        
                        logger.info("Processing command: " + command + " with args: " + java.util.Arrays.toString(args));
                        
                        String response = TelegramCommandRegistry.executeCommand(command, args);
                        
                        if (response != null && !response.isEmpty()) {
                            boolean sent = TelegramBotService.sendMessage(chatId, response);
                            if (sent) {
                                logger.info("Successfully sent response for command: " + command + " to chat: " + chatId);
                            } else {
                                logger.error("Failed to send response for command: " + command + " to chat: " + chatId);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            logger.error("Error processing update: " + jsonResponse, e);
        }
    }
}
