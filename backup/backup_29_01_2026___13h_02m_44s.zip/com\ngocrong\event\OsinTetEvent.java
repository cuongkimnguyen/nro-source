package com.ngocrong.event;

import _gwenstudio.ConfigStudio;
import com.ngocrong.data.OsinLixiData;
import com.ngocrong.item.Item;
import com.ngocrong.item.ItemMap;
import com.ngocrong.item.ItemOption;
import com.ngocrong.mob.Mob;
import com.ngocrong.repository.GameRepository;
import com.ngocrong.repository.OsinLixiRepository;
import com.ngocrong.user.Player;
import com.ngocrong.util.Utils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class OsinTetEvent {

    private static OsinLixiRepository repo() {
        return GameRepository.getInstance().osinLixiRepository;
    }

    public static final int[] CHU_ANKHANG_THINHVUONG = {2462, 2463, 2464, 2465};
    public static final int[] CHU_CHUCMUNG_NAMMOI = {2466, 2467, 2468, 2469};
    public static final int[] CHU_BINH_NGO_2026 = {2470, 2471, 2472};
    public static final int[] ALL_CHU_IDS = {
            2462, 2463, 2464, 2465,
            2466, 2467, 2468, 2469,
            2470, 2471, 2472
    };

    public static class ChuReward {
        public int itemId;
        public int quantity;
        public List<int[]> options;

        public ChuReward(int itemId, int quantity, List<int[]> options) {
            this.itemId = itemId;
            this.quantity = quantity;
            this.options = options;
        }
    }

    private static List<ChuReward> getRewardForBoChu(int[] chuIds) {
        List<ChuReward> rewards = new ArrayList<>();

   
        if (chuIds.length != 4 && chuIds.length != 3) {
            return rewards;
        }

        boolean hasAn = false, hasKhang = false, hasThinh = false, hasVuong = false;
        boolean hasChuc = false, hasMung = false, hasNam = false, hasMoi = false;
        boolean hasBinh = false, hasNgo = false, has2026 = false;

        for (int chuId : chuIds) {
            if (chuId == 2462) hasAn = true;
            else if (chuId == 2463) hasKhang = true;
            else if (chuId == 2464) hasThinh = true;
            else if (chuId == 2465) hasVuong = true;
            else if (chuId == 2466) hasChuc = true;
            else if (chuId == 2467) hasMung = true;
            else if (chuId == 2468) hasNam = true;
            else if (chuId == 2469) hasMoi = true;
            else if (chuId == 2470) hasBinh = true;
            else if (chuId == 2471) hasNgo = true;
            else if (chuId == 2472) has2026 = true;
        }

        boolean isAnKhangThinhVuong = hasAn && hasKhang && hasThinh && hasVuong;
        boolean isChucMungNamMoi = hasChuc && hasMung && hasNam && hasMoi;
        boolean isBinhNgo2026 = hasBinh && hasNgo && has2026;

        if (isAnKhangThinhVuong) {
            rewards.add(new ChuReward(2263, 50, List.of(new int[]{73, 0}))); 
            rewards.add(new ChuReward(2262, 50, List.of(new int[]{73, 0}))); 
            rewards.add(new ChuReward(2265, 50, List.of(new int[]{73, 0}))); 

        } else if (isChucMungNamMoi) {
            rewards.add(new ChuReward(2264, 1, List.of(new int[]{73, 0})));
        } else if (isBinhNgo2026) {
            rewards.add(new ChuReward(2481, 1, List.of(new int[]{50, 3}, new int[]{77, 3}, new int[]{101, 3})));
        }

        return rewards;
    }

    public static void rutLixi(Player player) {
        if (player == null) {
            return;
        }


        Optional<OsinLixiData> existingLixiOpt = repo().findTodayByPlayer(player.id);
        if (existingLixiOpt.isPresent()) {
            player.service.sendThongBao("Bạn đã rút lì xì hôm nay rồi. Hãy quay lại vào ngày mai.");
            return;
        }

        if (player.getCountEmptyBag() == 0) {
            player.service.sendThongBao("Hành trang đã đầy");
            return;
        }

        int randomChuId = ALL_CHU_IDS[Utils.nextInt(ALL_CHU_IDS.length)];
        Item chuItem = new Item(randomChuId);
        chuItem.setDefaultOptions();
        chuItem.addItemOption(new ItemOption(30, 1));
        chuItem.addItemOption(new ItemOption(174, 2026));
        chuItem.quantity = 1;

        if (player.addItem(chuItem)) {
            OsinLixiData newData = new OsinLixiData();
            newData.setPlayerId(player.id);
            newData.setLixiDate(Instant.now());
            repo().save(newData);

            player.service.sendThongBao("Bạn nhận được: " + chuItem.template.name);
        } else {
            player.service.sendThongBao("Không thể nhận lì xì. Hành trang đã đầy.");
        }
    }

    public static void doiChu(Player player, int[] chuIds) {
        if (player == null) {
            return;
        }

        for (int chuId : chuIds) {
            Item chuItem = player.getItemInBag(chuId);
            if (chuItem == null || chuItem.quantity < 1) {
                player.service.sendThongBao("Bạn không đủ chữ để đổi. Cần đủ 4 chữ cùng bộ.");
                return;
            }
        }

        List<ChuReward> rewards = getRewardForBoChu(chuIds);
        
        if (rewards.isEmpty()) {
            player.service.sendThongBao("Bộ chữ không hợp lệ.");
            return;
        }

        if (player.getCountEmptyBag() < rewards.size()) {
            player.service.sendThongBao("Hành trang không đủ chỗ. Cần ít nhất " + rewards.size() + " ô trống.");
            return;
        }

        List<Item> rewardItems = new ArrayList<>();
        StringBuilder rewardMessage = new StringBuilder();
        boolean hasError = false;

        for (ChuReward reward : rewards) {
            Item rewardItem = new Item(reward.itemId);
            rewardItem.setDefaultOptions();
            rewardItem.quantity = reward.quantity;
            
            if (reward.options != null) {
                for (int[] option : reward.options) {
                    if (option.length >= 2) {
                        rewardItem.addItemOption(new ItemOption(option[0], option[1]));
                    }
                }
            }
            
            rewardItems.add(rewardItem);
            if (rewardMessage.length() > 0) {
                rewardMessage.append(", ");
            }
            rewardMessage.append(rewardItem.template.name).append(" x").append(reward.quantity);
        }

        for (int chuId : chuIds) {
            Item chuItem = player.getItemInBag(chuId);
            player.removeItem(chuItem.indexUI, 1);
        }

        for (Item rewardItem : rewardItems) {
            if (!player.addItem(rewardItem)) {
                hasError = true;
                break;
            }
        }

        if (hasError) {
            player.service.sendThongBao("Không thể nhận quà. Hành trang đã đầy.");
            for (int chuId : chuIds) {
                Item chuItem = new Item(chuId);
                chuItem.setDefaultOptions();
                chuItem.addItemOption(new ItemOption(30, 1));
                chuItem.addItemOption(new ItemOption(174, 2026));
                chuItem.quantity = 1;
                player.addItem(chuItem);
            }
        } else {
            player.service.sendThongBao("Bạn đã đổi thành công! Nhận được: " + rewardMessage.toString());
        }
    }

    /**
     * Sự kiện đánh quái rơi đồ Tết
     * Drop item ID 2076-2078 khi đánh quái
     * Tỷ lệ: 20% (acc thường) hoặc 25% (acc đã kích hoạt MTV)
     */
    public static void mobReward(Player player, Mob mob) {
        if (player == null || mob == null || player.zone == null) {
            return;
        }

        // Chỉ hoạt động khi event Tết bật
        if (!ConfigStudio.EVENT_NEWYEAR_2026) {
            return;
        }

        // Chỉ drop từ mob thường, không phải boss
        if (mob.isBoss) {
            return;
        }

        // Tính tỷ lệ drop: 20% (thường) hoặc 25% (MTV)
        int dropRate = player.getSession().user.getActivated() == 1 ? 50 : 40;
        if (!Utils.isTrue(dropRate, 100)) {
            return;
        }

        // Random 1 trong 3 item: 2476, 2477, 2478
        int[] itemIds = {2476, 2477, 2478};
        int randomItemId = itemIds[Utils.nextInt(itemIds.length)];

        // Tạo item
        Item item = new Item(randomItemId);
        item.setDefaultOptions();
        item.quantity = 1;

        // Tạo ItemMap
        ItemMap itemMap = new ItemMap(mob.zone.autoIncrease++);
        itemMap.item = item;
        itemMap.playerID = Math.abs(player.id);
        itemMap.isPickedUp = false;
        itemMap.x = (short) (mob.x + Utils.nextInt(-30, 30));
        itemMap.y = mob.zone.map.collisionLand(mob.x, mob.y);

        // Add vào mob và zone
        mob.items.add(itemMap);
        mob.zone.addItemMap(itemMap);
        mob.zone.service.addItemMap(itemMap);
    }

    /**
     * Kiểm tra player có đủ 3 túi phúc (item 2076, 2077, 2078) không
     */
    public static boolean hasEnoughTuPhuc(Player player) {
        if (player == null) {
            return false;
        }

        int[] tuPhucIds = {2476, 2477, 2478};
        for (int itemId : tuPhucIds) {
            Item item = player.getItemInBag(itemId);
            if (item == null || item.quantity < 1) {
                return false;
            }
        }
        return true;
    }

    /**
     * Xử lý dâng túi phúc tại NPC Quy Lão
     */
    public static void dangTuPhuc(Player player) {
        if (player == null) {
            return;
        }

        // Check event đang bật
        if (!ConfigStudio.EVENT_NEWYEAR_2026) {
            player.service.sendThongBao("Sự kiện Tết chưa được kích hoạt.");
            return;
        }

        // Check đủ túi phúc
        if (!hasEnoughTuPhuc(player)) {
            player.service.sendThongBao("Bạn cần có đủ 3 túi phúc (ID: 2076, 2077, 2078) để dâng.");
            return;
        }

        // Check hành trang
        if (player.getCountEmptyBag() == 0) {
            player.service.sendThongBao("Hành trang đã đầy");
            return;
        }

        // Remove 3 túi phúc
        int[] tuPhucIds = {2476, 2477, 2478};
        for (int itemId : tuPhucIds) {
            Item item = player.getItemInBag(itemId);
            if (item != null) {
                player.removeItem(item.indexUI, 1);
            }
        }

        // Trao hộp quà 2483
        Item hopQua = new Item(2483);
        hopQua.setDefaultOptions();
        hopQua.quantity = 1;

        if (player.addItem(hopQua)) {
            player.service.sendThongBao("Bạn đã dâng túi phúc thành công! Nhận được: " + hopQua.template.name);
        } else {
            player.service.sendThongBao("Không thể nhận hộp quà. Hành trang đã đầy.");
            // Rollback: trả lại túi phúc
            for (int itemId : tuPhucIds) {
                Item rollbackItem = new Item(itemId);
                rollbackItem.setDefaultOptions();
                rollbackItem.quantity = 1;
                player.addItem(rollbackItem);
            }
        }
    }

    /**
     * Sử dụng hộp quà 2483
     * +1 điểm sự kiện vào top điểm siêu hạng
     * Random pet ID 2189 với options random
     */
    public static boolean useHopQuaTet(Player player, Item item) {
        if (player == null || item == null) {
            return false;
        }

        // Check item ID
        if (item.template.id != 2483) {
            return false;
        }

        // Check event đang bật
        if (!ConfigStudio.EVENT_NEWYEAR_2026) {
            return false;
        }

        // Check hành trang
        if (player.getCountEmptyBag() == 0) {
            player.service.dialogMessage("Hành trang đã đầy");
            return false;
        }

        // Load SuperRank nếu chưa có
        if (player.superrank == null) {
            com.ngocrong.NQMP.DHVT_SH.SuperRank.loadSuperRank(player);
            if (player.superrank == null) {
                com.ngocrong.NQMP.DHVT_SH.DHVT_SH_Service.gI().checkTop(player);
                com.ngocrong.NQMP.DHVT_SH.SuperRank.loadSuperRank(player);
            }
        }

        // +1 điểm sự kiện vào top điểm siêu hạng
        _event.newyear_2026.EventNewYear2026.addEventPoint(player, 1);

        // Random pet ID 2189 với options random
        Item petItem = new Item(2189);
        petItem.setDefaultOptions();
        
        // Random 3 options: 50, 77, 101 với param 1-7
        petItem.addItemOption(new ItemOption(50, Utils.nextInt(1, 7)));
        petItem.addItemOption(new ItemOption(77, Utils.nextInt(1, 7)));
        petItem.addItemOption(new ItemOption(101, Utils.nextInt(1, 7)));
        petItem.quantity = 1;

        // Remove item đã dùng
        player.removeItem(item.indexUI, 1);

        // Add pet vào bag
        if (player.addItem(petItem)) {
            player.service.sendThongBao("Bạn nhận được +1 điểm sự kiện và " + petItem.template.name);
            return true;
        } else {
            player.service.sendThongBao("Không thể nhận pet. Hành trang đã đầy.");
            // Rollback: trả lại hộp quà
            Item rollbackItem = new Item(2483);
            rollbackItem.setDefaultOptions();
            rollbackItem.quantity = 1;
            player.addItem(rollbackItem);
            return false;
        }
    }
}
