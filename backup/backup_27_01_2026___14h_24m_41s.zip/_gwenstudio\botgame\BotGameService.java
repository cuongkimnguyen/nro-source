package _gwenstudio.botgame;

import com.ngocrong.map.tzone.Zone;
import com.ngocrong.util.Utils;
import org.apache.log4j.Logger;

/**
 * Service xử lý logic tạo và quản lý bot game
 */
public class BotGameService {

    private static final Logger logger = Logger.getLogger(BotGameService.class);
    private static BotGameService instance = new BotGameService();

    public static BotGameService getInstance() {
        return instance;
    }

    /**
     * Tạo bot đánh quái
     * @param name - Tên bot
     * @param level - Level bot (1-200)
     * @param power - Power bot
     * @param zone - Zone spawn bot
     * @return BotGameMonsterHunter đã được tạo
     */
    public BotGameMonsterHunter createBot(String name, int level, long power, Zone zone) {
        try {
            BotGameMonsterHunter bot = new BotGameMonsterHunter(name, level, power, zone);
            logger.debug(String.format("[BotGameService] Đã tạo bot - Name: %s, Level: %d, Power: %d", 
                name, level, power));
            return bot;
        } catch (Exception e) {
            logger.error("[BotGameService] Lỗi khi tạo bot: " + e.getMessage(), e);
            return null;
        }
    }

    /**
     * Tạo nhiều bot cùng lúc
     * @param quantity - Số lượng bot
     * @param levelMin - Level tối thiểu
     * @param levelMax - Level tối đa
     * @param powerMin - Power tối thiểu
     * @param powerMax - Power tối đa
     * @param zone - Zone spawn bot
     * @return Số lượng bot đã tạo thành công
     */
    public int createBots(int quantity, int levelMin, int levelMax, long powerMin, long powerMax, Zone zone) {
        int created = 0;
        for (int i = 0; i < quantity; i++) {
            try {
                String botName = "BotGame_" + Utils.nextInt(1000, 9999);
                int level = Utils.nextInt(levelMin, levelMax);
                long power = Utils.nextInt((int)powerMin, (int)powerMax);
                
                BotGameMonsterHunter bot = createBot(botName, level, power, zone);
                if (bot != null) {
                    created++;
                }
            } catch (Exception e) {
                logger.error("[BotGameService] Lỗi khi tạo bot thứ " + (i + 1) + ": " + e.getMessage(), e);
            }
        }
        return created;
    }
}
