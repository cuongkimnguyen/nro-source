package _gwenstudio.botgame;

import com.ngocrong.mob.Mob;
import com.ngocrong.user.Player;
import org.apache.log4j.Logger;

/**
 * Logic di chuyển cho bot đánh quái
 * Xử lý di chuyển đến target một cách mượt mà
 */
public class BotGameMovement {

    private static final Logger logger = Logger.getLogger(BotGameMovement.class);
    
    private Player bot;
    private static final int STEP_SIZE = 100;

    public BotGameMovement(Player bot) {
        this.bot = bot;
    }

    /**
     * Di chuyển đến mob target
     * @param mob - Mob cần di chuyển đến
     */
    public void moveToTarget(Mob mob) {
        if (mob == null || !bot.meCanMove()) {
            return;
        }
        
        int botX = bot.getX();
        int botY = bot.getY();
        int mobX = mob.x;
        int mobY = mob.y;
        
        int newX = botX;
        int newY = botY;
        
        if (Math.abs(mobX - botX) > STEP_SIZE) {
            newX = botX + (mobX > botX ? STEP_SIZE : -STEP_SIZE);
        } else {
            newX = mobX;
        }
        
        if (Math.abs(mobY - botY) > STEP_SIZE) {
            newY = botY + (mobY > botY ? STEP_SIZE : -STEP_SIZE);
        } else {
            newY = mobY;
        }
        
        bot.moveTo((short) newX, (short) newY);
        
        logger.debug(String.format("[BotGame] Bot %s: Di chuyển đến target - X: %d, Y: %d", 
            bot.name, newX, newY));
    }
}
