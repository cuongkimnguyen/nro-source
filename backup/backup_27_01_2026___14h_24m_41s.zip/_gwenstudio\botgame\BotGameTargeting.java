package _gwenstudio.botgame;

import com.ngocrong.mob.Mob;
import com.ngocrong.user.Player;
import org.apache.log4j.Logger;

import java.util.List;

/**
 * Logic tìm target cho bot đánh quái
 * Tìm mob gần nhất và quản lý target
 */
public class BotGameTargeting {

    private static final Logger logger = Logger.getLogger(BotGameTargeting.class);
    
    private Player bot;
    private Mob currentTarget = null;
    private static final double MAX_TARGET_DISTANCE = 2000.0;

    public BotGameTargeting(Player bot) {
        this.bot = bot;
    }

    /**
     * Tìm mob target gần nhất
     * @return Mob gần nhất hoặc null nếu không tìm thấy
     */
    public Mob findTarget() {
        if (currentTarget != null) {
            if (isTargetValid(currentTarget)) {
                return currentTarget;
            } else {
                currentTarget = null;
            }
        }
        
        List<Mob> mobs = bot.zone.getListMob();
        if (mobs == null || mobs.isEmpty()) {
            return null;
        }
        
        double minDistance = Double.MAX_VALUE;
        Mob nearestMob = null;
        
        int botX = bot.getX();
        int botY = bot.getY();
        
        for (Mob mob : mobs) {
            if (!isMobValid(mob)) {
                continue;
            }
            
            double distance = calculateDistance(botX, botY, mob.x, mob.y);
            
            if (distance < minDistance && distance < MAX_TARGET_DISTANCE) {
                minDistance = distance;
                nearestMob = mob;
            }
        }
        
        if (nearestMob != null) {
            currentTarget = nearestMob;
            logger.debug(String.format("[BotGame] Bot %s: Tìm thấy target - Mob TemplateID: %d, Distance: %.2f", 
                bot.name, nearestMob.templateId, minDistance));
        }
        
        return currentTarget;
    }

    /**
     * Kiểm tra mob có hợp lệ không
     * @param mob - Mob cần kiểm tra
     * @return true nếu mob hợp lệ
     */
    private boolean isMobValid(Mob mob) {
        return mob != null 
            && mob.hp > 0 
            && !mob.isDead() 
            && mob.status != 0 
            && mob.status != 1 
            && !mob.isMobMe;
    }

    /**
     * Kiểm tra target còn hợp lệ không
     * @param target - Target cần kiểm tra
     * @return true nếu target còn hợp lệ
     */
    private boolean isTargetValid(Mob target) {
        return isMobValid(target);
    }

    /**
     * Tính khoảng cách giữa 2 điểm
     * @param x1 - Tọa độ X điểm 1
     * @param y1 - Tọa độ Y điểm 1
     * @param x2 - Tọa độ X điểm 2
     * @param y2 - Tọa độ Y điểm 2
     * @return Khoảng cách
     */
    private double calculateDistance(int x1, int y1, int x2, int y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }

    /**
     * Xóa target hiện tại
     */
    public void clearTarget() {
        currentTarget = null;
    }

    public Mob getCurrentTarget() {
        return currentTarget;
    }
}
