/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ngocrong.combine;

import com.ngocrong.consts.CMDMenu;
import com.ngocrong.item.Item;
import com.ngocrong.item.ItemOption;
import com.ngocrong.lib.KeyValue;
import com.ngocrong.server.Config;
import com.ngocrong.util.Utils;

/**
 *
 * @author Administrator
 */
public class DoiDoKichHoat extends Combine {

    public static int[] SKHTD = new int[]{40, 40, 20}; // Tỉ lệ % cho gender 0 (Trái Đất)
    public static int[] SKHNM = new int[]{20, 20, 60}; // Tỉ lệ % cho gender 1 (Namec)
    public static int[] SKHXD = new int[]{20, 60, 20}; // Tỉ lệ % cho gender 2 (Xayda)
    static final int goldRequire = 500_000_000;

    /**
     * Set tỉ lệ % cho SKH Trái Đất
     *
     * @param txh tỉ lệ % cho TXH (index 0)
     * @param krilin tỉ lệ % cho Krilin (index 1)
     * @param sgk tỉ lệ % cho SGK (index 2)
     * @return true nếu set thành công, false nếu tổng không bằng 100
     */
    public static boolean setSKHTD(int txh, int krilin, int sgk) {
        if (txh + krilin + sgk != 100) {
            return false;
        }
        if (txh < 0 || krilin < 0 || sgk < 0) {
            return false;
        }
        SKHTD[0] = txh;
        SKHTD[1] = krilin;
        SKHTD[2] = sgk;
        return true;
    }

    /**
     * Set tỉ lệ % cho SKH Namec
     *
     * @param pcl tỉ lệ % cho PCL (index 0)
     * @param octiu tỉ lệ % cho Octiu (index 1)
     * @param daimao tỉ lệ % cho Daimao (index 2)
     * @return true nếu set thành công, false nếu tổng không bằng 100
     */
    public static boolean setSKHNM(int pcl, int octiu, int daimao) {
        if (pcl + octiu + daimao != 100) {
            return false;
        }
        if (pcl < 0 || octiu < 0 || daimao < 0) {
            return false;
        }
        SKHNM[0] = pcl;
        SKHNM[1] = octiu;
        SKHNM[2] = daimao;
        return true;
    }

    /**
     * Set tỉ lệ % cho SKH Xayda
     *
     * @param kkr tỉ lệ % cho KKR (index 0)
     * @param cadic tỉ lệ % cho Cadic (index 1)
     * @param nappa tỉ lệ % cho Nappa (index 2)
     * @return true nếu set thành công, false nếu tổng không bằng 100
     */
    public static boolean setSKHXD(int kkr, int cadic, int nappa) {
        if (kkr + cadic + nappa != 100) {
            return false;
        }
        if (kkr < 0 || cadic < 0 || nappa < 0) {
            return false;
        }
        SKHXD[0] = kkr;
        SKHXD[1] = cadic;
        SKHXD[2] = nappa;
        return true;
    }

    public DoiDoKichHoat() {
        StringBuilder sb = new StringBuilder();
        sb.append("Vào hành trang").append("\n");
        sb.append("Chọn 1 món đồ Hủy Diệt").append("\n");
        sb.append("Sau đó chọn 'Đổi Đồ'");
        setInfo(sb.toString());

        StringBuilder sb2 = new StringBuilder();
        sb2.append("Ta sẽ phù phép").append("\n");
        sb2.append("Biến đồ Hủy Diệt thành Đồ Kích hoạt").append("\n");
        setInfo2(sb2.toString());
    }
    public int type;

    @Override
    public void confirm() {
        if (itemCombine == null) {
            return;
        }
        if (itemCombine.size() != 1) {
            player.service.dialogMessage("Số lượng trang bị không hợp lệ");
            return;
        }
        Item item = player.itemBag[itemCombine.get(0)];
        if (item == null || item.template.type >= 5 || item.template.level != 14) {
            player.service.dialogMessage("Vật phẩm không hợp lệ");
            return;
        }
        String info = "Sau khi cường hóa, sẽ nhận được 1 trang bị kích hoạt ngẫu nhiên (cần 500tr vàng)";
        player.menus.clear();
        if (item.template.type != 4) {
            player.menus.add(new KeyValue(CMDMenu.COMBINE, "Đồng ý\n500tr vàng", -1));
        } else {
            player.menus.add(new KeyValue(CMDMenu.COMBINE, "Chỉ Số SKH\nTrái Đất", 0));
            player.menus.add(new KeyValue(CMDMenu.COMBINE, "Chỉ Số SKH\nNamec", 1));
            player.menus.add(new KeyValue(CMDMenu.COMBINE, "Chỉ Số SKH\nXayda", 2));

        }
        player.menus.add(new KeyValue(CMDMenu.CANCEL, "Từ chối"));
        player.service.openUIConfirm(npc.templateId, info, npc.avatar, player.menus);
    }

    static int getTempId(Item item) {
        int[][] ao = new int[][]{
            {0, 33, 3, 34, 136, 137, 138, 139, 230, 231, 232, 233},
            {1, 41, 4, 42, 152, 153, 154, 155, 234, 235, 236, 237},
            {2, 49, 5, 50, 168, 169, 170, 171, 238, 239, 240, 241}
        };
        int[][] quan = new int[][]{
            {6, 35, 9, 36, 140, 141, 142, 143, 242, 243, 244, 245},
            {7, 43, 10, 44, 156, 157, 158, 159, 246, 247, 248, 249},
            {8, 51, 11, 52, 172, 173, 174, 175, 250, 251, 252, 253}
        };
        int[][] gang = new int[][]{
            {21, 24, 37, 38, 144, 145, 146, 147, 254, 255, 256, 257},
            {22, 46, 25, 45, 160, 161, 162, 163, 258, 259, 260, 261},
            {23, 53, 26, 54, 176, 177, 178, 179, 262, 263, 264, 265}
        };
        int[][] giay = new int[][]{
            {27, 30, 39, 40, 148, 149, 150, 151, 266, 267, 268, 269},
            {28, 47, 31, 48, 164, 165, 166, 167, 270, 271, 272, 273},
            {29, 55, 32, 56, 180, 181, 182, 183, 274, 275, 276, 277}
        };
        int[] rd = new int[]{12, 57, 58, 59, 184, 185, 186, 187, 278, 279, 280, 281};
        int[] temp = new int[]{};
        switch (item.template.type) {
            case 0:
                temp = ao[item.template.gender];
                break;
            case 1:
                temp = quan[item.template.gender];
                break;
            case 2:
                temp = gang[item.template.gender];
                break;
            case 3:
                temp = giay[item.template.gender];
                break;
            case 4:
                temp = rd;
        }
        int index = Config.serverID() == 1 ? 0 : Utils.nextInt(temp.length);
        return temp[index];
    }

    public static final int[][][] OPTIONS = {
        {
            {127, 139}, // txh
            {128, 140}, // krilin
            {129, 141} // sgk
        }, {
            {130, 142}, //pcl
            {131, 143}, // octiu
            {132, 144} //daimao
        }, {
            {133, 136}, // kkr
            {134, 137}, // cadic
            {135, 138} // nappa
        }
    };

    /**
     * Chọn index dựa trên tỉ lệ % từ các mảng SKHTD, SKHNM, SKHXD
     *
     * @param gender giới tính của trang bị (0: Trái Đất, 1: Namec, 2: Xayda)
     * @return index được chọn (0, 1, hoặc 2)
     */
    private int getRandomIndexByPercentage(int gender) {
        int[] percentages;
        switch (gender) {
            case 0:
                percentages = SKHTD;
                break;
            case 1:
                percentages = SKHNM;
                break;
            case 2:
                percentages = SKHXD;
                break;
            default:
                percentages = SKHTD; // Default fallback
                break;
        }

        // Tính tổng tỉ lệ
        int totalPercentage = 0;
        for (int percentage : percentages) {
            totalPercentage += percentage;
        }

        // Random một số từ 0 đến totalPercentage - 1
        int randomValue = Utils.nextInt(totalPercentage);

        // Tìm index tương ứng với giá trị random
        int currentSum = 0;
        for (int i = 0; i < percentages.length; i++) {
            currentSum += percentages[i];
            if (randomValue < currentSum) {
                return i;
            }
        }

        // Fallback (không bao giờ xảy ra nếu logic đúng)
        return 0;
    }

    @Override
    public void combine() {
        if (itemCombine == null) {
            return;
        }
        if (itemCombine.size() != 1) {
            player.service.dialogMessage("Số lượng trang bị không hợp lệ");
            return;
        }
        Item item = player.itemBag[itemCombine.get(0)];
        if (item == null || item.template.type >= 5 || item.template.level != 14) {
            player.service.dialogMessage("Vật phẩm không hợp lệ");
            return;
        }
        if (player.gold < 500000000) {
            player.service.sendThongBao("Bạn không đủ vàng");
            return;
        }
        player.addGold(-500000000);
        short oldIcon = item.template.iconID;
        result((byte) 2, oldIcon, item.template.iconID);
        item = new Item(getTempId(item));
        item.quantity = 1;
        item.setDefaultOptions();

        // Sử dụng tỉ lệ % thay vì random đơn giản
        int index;
        if (item.template.gender == 3 && type != -1) {
            // Nếu là radar và đã chọn type cụ thể
            index = getRandomIndexByPercentage(type);
            item.addItemOption(new ItemOption(OPTIONS[type][index][0], 0));
            item.addItemOption(new ItemOption(OPTIONS[type][index][1], 0));
        } else {
            // Sử dụng gender của trang bị
            index = getRandomIndexByPercentage(item.template.gender);
            item.addItemOption(new ItemOption(OPTIONS[item.template.gender][index][0], 0));
            item.addItemOption(new ItemOption(OPTIONS[item.template.gender][index][1], 0));
        }

        item.addItemOption(new ItemOption(30, 0));
        item.indexUI = itemCombine.get(0);
        player.itemBag[item.indexUI] = item;
        player.service.refreshItem((byte) 1, item);
        update();
    }

    @Override
    public void showTab() {
        player.service.combine((byte) 0, this, (short) -1, (short) -1);
    }
}
