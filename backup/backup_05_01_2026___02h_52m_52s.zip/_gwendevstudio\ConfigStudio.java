
package _gwendevstudio;

/**
 *
 * @author GwenDevStudio
 */
public class ConfigStudio {
    
    public static final String SLOGAN = "Chào mừng bạn đến với Hồi Ức Ngọc Rông";
    public static final String ABBREVIATION = "HUNR";
    public static final String SLOGAN_BOTCOLD = "HUNR";
    public static final String SLOGAN_BOTSOSINH = "HUNR";
    public static final String SLOGAN_BOTTRAIN = "HUNR";
    public static final String MESSAGE_LOGIN2 = "Đăng ký tài khoản tại Hồi Ức Ngọc Rồng (hoiucngocrong.com)";
    public static final String MESSAGE_INPUT_CARD = "Bạn hãy truy cập trang: HOIUCNGOCRONG.COM để nạp tiền!";
    public static final String SERVER_VERSION = "0.0.7";
    public static final String WEBSITE_URL = "HOIUCNGOCRONG.COM";

}
