package _gwenstudio.botgame;

import com.ngocrong.mob.Mob;
import com.ngocrong.user.Player;
import org.apache.log4j.Logger;

/**
 * Logic combat cho bot đánh quái
 * Xử lý tấn công và kiểm tra tầm tấn công
 */
public class BotGameCombat {

    private static final Logger logger = Logger.getLogger(BotGameCombat.class);
    
    private Player bot;
    private long lastAttackTime = 0;
    private int attackSpeed = 550;

    public BotGameCombat(Player bot) {
        this.bot = bot;
    }

    /**
     * Kiểm tra bot có trong tầm tấn công không
     * @param mob - Mob cần kiểm tra
     * @return true nếu trong tầm tấn công
     */
    public boolean isInAttackRange(Mob mob) {
        if (mob == null || bot.skills == null || bot.skills.isEmpty()) {
            return false;
        }
        
        com.ngocrong.skill.Skill skill = bot.skills.get(0);
        if (skill == null) {
            return false;
        }
        
        int distanceX = Math.abs(bot.getX() - mob.x);
        int distanceY = Math.abs(bot.getY() - mob.y);
        
        return distanceX <= skill.dx * 1.2 && distanceY <= skill.dy * 1.2;
    }

    /**
     * Tấn công mob target
     * @param mob - Mob cần tấn công
     */
    public void attack(Mob mob) {
        if (mob == null || mob.hp <= 0 || mob.isDead()) {
            return;
        }
        
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastAttackTime < attackSpeed) {
            return;
        }
        
        if (bot.skills == null || bot.skills.isEmpty()) {
            return;
        }
        
        bot.select = bot.skills.get(0);
        if (bot.select != null && bot.meCanAttack()) {
            bot.select.manaUse = 0;
            lastAttackTime = currentTime;
            
            logger.debug(String.format("[BotGame] Bot %s: Tấn công mob TemplateID: %d, HP trước: %d, Skill ID: %d", 
                bot.name, mob.templateId, mob.hp, bot.select.id));
            
            bot.zone.attackNpc(bot, mob, false);
            
            logger.debug(String.format("[BotGame] Bot %s: Sau tấn công - HP mob còn lại: %d", 
                bot.name, mob.hp));
        }
    }

    public void setAttackSpeed(int speed) {
        this.attackSpeed = speed;
    }
}
