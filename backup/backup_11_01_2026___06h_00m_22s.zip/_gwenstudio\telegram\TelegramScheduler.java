package _gwenstudio.telegram;

import _gwenstudio.services.TelegramBotService;
import com.ngocrong.server.Config;
import com.ngocrong.server.SessionManager;
import org.apache.log4j.Logger;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class TelegramScheduler {
    
    private static final Logger logger = Logger.getLogger(TelegramScheduler.class);
    private static ScheduledExecutorService scheduler;
    private static boolean running = false;
    
    public static void start() {
        if (!TelegramConfig.ENABLED || !TelegramConfig.AUTO_CCU_ENABLED) {
            logger.info("Telegram auto CCU is disabled");
            return;
        }
        
        if (running) {
            logger.warn("Telegram scheduler is already running");
            return;
        }
        
        scheduler = Executors.newScheduledThreadPool(1);
        running = true;
        
        scheduler.scheduleAtFixedRate(() -> {
            try {
                sendCCUReport();
            } catch (Exception e) {
                logger.error("Error in Telegram scheduler", e);
            }
        }, TelegramConfig.AUTO_CCU_INTERVAL, TelegramConfig.AUTO_CCU_INTERVAL, TimeUnit.SECONDS);
        
        logger.info("Telegram scheduler started with interval: " + TelegramConfig.AUTO_CCU_INTERVAL + " seconds");
    }
    
    public static void stop() {
        if (scheduler != null && !scheduler.isShutdown()) {
            scheduler.shutdown();
            try {
                if (!scheduler.awaitTermination(5, TimeUnit.SECONDS)) {
                    scheduler.shutdownNow();
                }
            } catch (InterruptedException e) {
                scheduler.shutdownNow();
                Thread.currentThread().interrupt();
            }
            running = false;
            logger.info("Telegram scheduler stopped");
        }
    }
    
    private static void sendCCUReport() {
        if (!TelegramConfig.ENABLED) {
            return;
        }
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String formattedTime = LocalDateTime.now().format(formatter);
        
        int totalSessions = SessionManager.sessions.size();
        long totalPlayers = SessionManager.getCountPlayer();
        
        StringBuilder sb = new StringBuilder();
        sb.append("GWENDEV STUDIO - CHECKER SERVER ").append(Config.serverID()).append("   -   ").append(formattedTime).append("\n");
        sb.append("Tổng CCU : ").append(totalSessions).append(" Session\n");
        sb.append("     -      ").append(totalPlayers).append(" Player Online");
        
        String message = sb.toString();
        boolean success = TelegramBotService.sendMessage(message);
        
        if (success) {
            logger.info("Auto CCU report sent successfully");
        } else {
            logger.warn("Failed to send auto CCU report");
        }
    }
    
    public static void sendCCUNow() {
        sendCCUReport();
    }
    
    public static boolean isRunning() {
        return running;
    }
}

