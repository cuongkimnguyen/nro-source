package _gwenstudio.services;

import _gwenstudio.telegram.TelegramConfig;
import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class TelegramBotService {
    
    private static final Logger logger = Logger.getLogger(TelegramBotService.class);
    private static final String API_BASE_URL = "https://api.telegram.org/bot";
    
    public static boolean sendMessage(String chatId, String message) {
        if (TelegramConfig.BOT_TOKEN == null || TelegramConfig.BOT_TOKEN.isEmpty()) {
            logger.warn("Bot token not configured");
            return false;
        }
        
        if (chatId == null || chatId.isEmpty()) {
            logger.warn("Chat ID is empty");
            return false;
        }
        
        logger.debug("Sending message to chat: " + chatId);
        
        try {
            String encodedMessage = URLEncoder.encode(message, StandardCharsets.UTF_8.toString());
            String urlString = API_BASE_URL + TelegramConfig.BOT_TOKEN + "/sendMessage";
            URL url = new URL(urlString);
            
            HttpURLConnection conn;
            
            if (TelegramConfig.USE_PROXY) {
                Proxy proxy = new Proxy(Proxy.Type.SOCKS, new InetSocketAddress(TelegramConfig.PROXY_HOST, TelegramConfig.PROXY_PORT));
                conn = (HttpURLConnection) url.openConnection(proxy);
                java.net.Authenticator.setDefault(new java.net.Authenticator() {
                    @Override
                    protected java.net.PasswordAuthentication getPasswordAuthentication() {
                        return new java.net.PasswordAuthentication(
                            TelegramConfig.PROXY_USERNAME, 
                            TelegramConfig.PROXY_PASSWORD.toCharArray()
                        );
                    }
                });
            } else {
                conn = (HttpURLConnection) url.openConnection();
            }
            
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(30000);
            
            String data = "chat_id=" + chatId + "&text=" + encodedMessage;
            
            try (OutputStream os = conn.getOutputStream()) {
                os.write(data.getBytes(StandardCharsets.UTF_8));
                os.flush();
            }
            
            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                logger.debug("Message sent successfully to chat: " + chatId);
                return true;
            } else {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getErrorStream()))) {
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) {
                        response.append(line);
                    }
                    logger.error("Telegram API error: " + responseCode + " - " + response.toString());
                } catch (Exception e) {
                    logger.error("Failed to read error stream", e);
                }
                return false;
            }
        } catch (Exception e) {
            logger.error("Failed to send Telegram message", e);
            return false;
        }
    }
    
    public static boolean sendMessage(String message) {
        if (TelegramConfig.CHAT_ID == null || TelegramConfig.CHAT_ID.isEmpty()) {
            logger.warn("Chat ID not configured");
            return false;
        }
        return sendMessage(TelegramConfig.CHAT_ID, message);
    }
    
    public static String getUpdates(long offset) {
        if (TelegramConfig.BOT_TOKEN == null || TelegramConfig.BOT_TOKEN.isEmpty()) {
            logger.warn("Cannot get updates: Bot token not configured");
            return null;
        }
        
        try {
            String urlString = API_BASE_URL + TelegramConfig.BOT_TOKEN + "/getUpdates?offset=" + offset + "&timeout=30";
            logger.debug("Getting updates with offset: " + offset);
            URL url = new URL(urlString);
            
            HttpURLConnection conn;
            
            if (TelegramConfig.USE_PROXY) {
                Proxy proxy = new Proxy(Proxy.Type.SOCKS, new InetSocketAddress(TelegramConfig.PROXY_HOST, TelegramConfig.PROXY_PORT));
                conn = (HttpURLConnection) url.openConnection(proxy);
                java.net.Authenticator.setDefault(new java.net.Authenticator() {
                    @Override
                    protected java.net.PasswordAuthentication getPasswordAuthentication() {
                        return new java.net.PasswordAuthentication(
                            TelegramConfig.PROXY_USERNAME, 
                            TelegramConfig.PROXY_PASSWORD.toCharArray()
                        );
                    }
                });
            } else {
                conn = (HttpURLConnection) url.openConnection();
            }
            
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(35000);
            conn.setReadTimeout(35000);
            
            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) {
                        response.append(line);
                    }
                    String result = response.toString();
                    logger.debug("Received updates response: " + (result.length() > 100 ? result.substring(0, 100) + "..." : result));
                    return result;
                }
            } else {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8))) {
                    StringBuilder errorResponse = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) {
                        errorResponse.append(line);
                    }
                    logger.error("Failed to get updates: " + responseCode + " - " + errorResponse.toString());
                } catch (Exception e) {
                    logger.error("Failed to get updates: " + responseCode, e);
                }
                return null;
            }
        } catch (Exception e) {
            logger.error("Failed to get Telegram updates", e);
            return null;
        }
    }
}

