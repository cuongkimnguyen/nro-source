package _event.newyear_2026;

import _gwenstudio.ConfigStudio;
import com.ngocrong.NQMP.DHVT_SH.Top_SieuHang;
import com.ngocrong.server.mysql.MySQLConnect;
import com.ngocrong.user.Player;
import com.ngocrong.util.Utils;
import org.apache.log4j.Logger;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EventNewYear2026 {

    private static final Logger logger = Logger.getLogger(EventNewYear2026.class);
    private static final int[] POINTS_BY_RANK = {20, 18, 16, 14, 12, 10, 8, 6, 4, 2};
    private static final int MAX_RANK_FOR_POINTS = 10;

    public static boolean isActive() {
        return ConfigStudio.EVENT_NEWYEAR_2026;
    }

    public static NewYear2026RankData getOrCreateData(Player player) {
        if (player == null) {
            return null;
        }
        if (!isActive()) {
            return null;
        }

        try {
            PreparedStatement ps = MySQLConnect.getConnection().prepareStatement(
                    "SELECT * FROM nr_super_rank WHERE player_id = ? LIMIT 1");
            ps.setInt(1, player.id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String eventData = rs.getString("event_newyear2026");
                if (eventData != null && !eventData.isEmpty() && !eventData.equals("null")) {
                    return NewYear2026RankData.fromJSON(eventData);
                }
            }

            NewYear2026RankData newData = new NewYear2026RankData();
            saveData(player, newData);
            return newData;
        } catch (SQLException e) {
            logger.error("Error loading NewYear2026 data", e);
            return new NewYear2026RankData();
        }
    }

    public static void saveData(Player player, NewYear2026RankData data) {
        if (player == null || data == null || !isActive()) {
            return;
        }

        try {
            PreparedStatement ps = MySQLConnect.getConnection().prepareStatement(
                    "UPDATE nr_super_rank SET event_newyear2026 = ? WHERE player_id = ?");
            ps.setString(1, data.toJSON());
            ps.setInt(2, player.id);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            logger.error("Error saving NewYear2026 data", e);
        }
    }

    public static int getPointsForRank(int rank) {
        if (rank < 1 || rank > MAX_RANK_FOR_POINTS) {
            return 0;
        }
        return POINTS_BY_RANK[rank - 1];
    }

    public static void onRankUp(Player player, int newRank, int oldRank) {
        if (!isActive() || player == null) {
            return;
        }

        NewYear2026RankData data = getOrCreateData(player);
        if (data == null) {
            return;
        }

        if (newRank <= MAX_RANK_FOR_POINTS) {
            if (data.currentRank != newRank) {
                if (data.isHoldingRank() && !data.hasHeldLongEnough()) {
                    player.service.sendThongBao("Bạn chưa giữ đủ 30 phút ở hạng cũ, không được điểm");
                }
                data.holdStartTime = System.currentTimeMillis();
                data.currentRank = newRank;
                data.points = 0;
            }
        } else {
            data.holdStartTime = 0;
            data.currentRank = newRank;
            data.points = 0;
        }

        saveData(player, data);
    }

    public static void onRankDown(Player player, int newRank, int oldRank) {
        if (!isActive() || player == null) {
            return;
        }

        NewYear2026RankData data = getOrCreateData(player);
        if (data == null) {
            return;
        }

        if (data.isHoldingRank() && !data.hasHeldLongEnough()) {
            data.holdStartTime = 0;
            data.points = 0;
            player.service.sendThongBao("Bạn chưa giữ đủ 30 phút, không được điểm");
        }

        if (newRank <= MAX_RANK_FOR_POINTS) {
            data.holdStartTime = System.currentTimeMillis();
            data.currentRank = newRank;
            data.points = 0;
        } else {
            data.holdStartTime = 0;
            data.currentRank = newRank;
            data.points = 0;
        }

        saveData(player, data);
    }

    public static void checkHoldTime(Player player) {
        if (!isActive() || player == null) {
            return;
        }

        NewYear2026RankData data = getOrCreateData(player);
        if (data == null) {
            return;
        }

        if (data.hasHeldLongEnough() && data.points == 0) {
            int points = getPointsForRank(data.currentRank);
            if (points > 0) {
                data.points = points;
                data.totalPoints += points;
                data.holdStartTime = System.currentTimeMillis();
                saveData(player, data);

                player.service.dialogMessage(String.format(
                        "Bạn đã giữ hạng đủ 30 phút!\n" +
                        "Nhận được %d điểm sự kiện\n" +
                        "Tổng điểm: %d điểm",
                        points, data.totalPoints));
            }
        }
    }

    public static String getRemainingTime(Player player) {
        if (!isActive() || player == null) {
            return "";
        }

        NewYear2026RankData data = getOrCreateData(player);
        if (data == null || !data.isHoldingRank()) {
            return "";
        }

        long remaining = data.getRemainingHoldTime();
        if (remaining <= 0) {
            return "00:00";
        }

        long minutes = remaining / (1000 * 60);
        long seconds = (remaining % (1000 * 60)) / 1000;

        return String.format("%02d:%02d", minutes, seconds);
    }

    public static boolean checkTicket(Player player) {
        if (!isActive() || player == null) {
            return false;
        }

        NewYear2026RankData data = getOrCreateData(player);
        if (data == null) {
            return false;
        }

        NewYear2026RankData.resetTicketsIfNewDay(data);

        if (data.freeTicketsToday > 0) {
            data.freeTicketsToday--;
            saveData(player, data);
            return true;
        }

        com.ngocrong.item.Item thoivang = player.getItemInBag(com.ngocrong.consts.ItemName.THOI_VANG);
        if (thoivang != null && thoivang.quantity >= 5) {
            player.subThoiVang(5);
            return true;
        }

        return false;
    }

    public static byte getFreeTicketsRemaining(Player player) {
        if (!isActive() || player == null) {
            return 0;
        }

        NewYear2026RankData data = getOrCreateData(player);
        if (data == null) {
            return 0;
        }

        NewYear2026RankData.resetTicketsIfNewDay(data);
        return data.freeTicketsToday;
    }

    public static int getTotalPoints(Player player) {
        if (!isActive() || player == null) {
            return 0;
        }

        NewYear2026RankData data = getOrCreateData(player);
        if (data == null) {
            return 0;
        }

        return data.totalPoints;
    }
}
