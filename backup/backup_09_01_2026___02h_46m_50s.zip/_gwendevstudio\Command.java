
package _gwendevstudio;

/**
 *
 * @author GwenDevStudio
 */
public class Command {

}
