
package _gwenstudio.npclist;

/**
 *
 * @author GwenDevStudio
 */
public class BoMong {

}
