package com.ngocrong.repository;

import com.ngocrong.data.BotConfigData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BotConfigRepository extends JpaRepository<BotConfigData, Integer> {
    
    Optional<BotConfigData> findByBotname(String botname);
    
    Optional<BotConfigData> findByBotnameAndIsUsedFalse(String botname);
    
    List<BotConfigData> findByCaitrangIdIsNotNull();
    
    List<BotConfigData> findByIsUsedFalse();
    
    List<BotConfigData> findAll();
}
