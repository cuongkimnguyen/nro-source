package com.ngocrong.NQMP;

import com.ngocrong.bot.VirtualBot_SoSinh;
import com.ngocrong.consts.CMDMenu;
import com.ngocrong.consts.NpcName;
import com.ngocrong.data.BotConfigData;
import com.ngocrong.lib.KeyValue;
import com.ngocrong.map.MapManager;
import com.ngocrong.map.TMap;
import com.ngocrong.map.tzone.Zone;
import com.ngocrong.repository.GameRepository;
import com.ngocrong.user.Player;
import com.ngocrong.util.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BotMenuHandler {

    public static final int CMD_Menu_Bot = 2100;
    public static BotMenuHandler instance = new BotMenuHandler();

    public static BotMenuHandler gI() {
        return instance;
    }

    public void showMenu(Player player) {
        player.menus.clear();
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo Bot", 1));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa Bot", 2));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa Bot Khu hiện tại", 3));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xem danh sách Bot", 4));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Reset tên Bot đã dùng", 5));
        player.service.openUIConfirm(NpcName.CON_MEO, "Quản lý Bot", player.getPetAvatar(), player.menus);
    }

    public void perform(int idAction, Player player, Object... p) {
        switch (idAction) {
            case 1: {
                showCreateBotMenu(player);
                break;
            }
            case 2: {
                showDeleteBotMenu(player);
                break;
            }
            case 3: {
                deleteBotsInCurrentZone(player);
                break;
            }
            case 4: {
                showBotList(player);
                break;
            }
            case 5: {
                resetUsedBotNames(player);
                break;
            }
            case 10: {
                int quantity = ((Integer) p[0]);
                createBots(player, quantity);
                break;
            }
            case 20: {
                int quantity = ((Integer) p[0]);
                deleteBots(player, quantity);
                break;
            }
        }
    }

    private void showCreateBotMenu(Player player) {
        player.menus.clear();
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo 1 Bot", 10, 1));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo 5 Bot", 10, 5));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo 10 Bot", 10, 10));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo 20 Bot", 10, 20));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo 50 Bot", 10, 50));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo 100 Bot", 10, 100));
        player.service.openUIConfirm(NpcName.CON_MEO, "Chọn số lượng Bot muốn tạo", player.getPetAvatar(), player.menus);
    }

    private void showDeleteBotMenu(Player player) {
        player.menus.clear();
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa 1 Bot", 20, 1));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa 5 Bot", 20, 5));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa 10 Bot", 20, 10));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa 20 Bot", 20, 20));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa 50 Bot", 20, 50));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa tất cả Bot", 20, -1));
        player.service.openUIConfirm(NpcName.CON_MEO, "Chọn số lượng Bot muốn xóa", player.getPetAvatar(), player.menus);
    }

    private void createBots(Player player, int quantity) {
        int created = 0;
        int maxAttempts = quantity * 10;
        int attempts = 0;

        for (int i = 0; i < quantity && attempts < maxAttempts; attempts++) {
            String botName = Player.generateCharacterName();
            Optional<BotConfigData> configOpt = GameRepository.getInstance().botConfig.findByBotnameAndIsUsedFalse(botName);
            if (configOpt.isPresent()) {
                BotConfigData config = configOpt.get();
                config.setIsUsed(true);
                GameRepository.getInstance().botConfig.save(config);

                VirtualBot_SoSinh bot = new VirtualBot_SoSinh(botName);
                bot.setLocation(0, -1);
                UtilsNQMP.lastCreateBot = System.currentTimeMillis();
                created++;
                i++;
            }
        }

        if (created > 0) {
            player.service.sendThongBao("Đã tạo " + created + " Bot");
        }
        if (created < quantity) {
            player.service.sendThongBao("Hết tên bot vui lòng thêm tên vào bảng bot_config");
        }
    }

    private void deleteBots(Player player, int quantity) {
        int deleted = 0;
        List<Player> botsToDelete = new ArrayList<>();

        for (TMap map : MapManager.getInstance().maps.values()) {
            if (map == null || map.zones == null) {
                continue;
            }
            for (Zone zone : map.zones) {
                if (zone == null || zone.players == null) {
                    continue;
                }
                synchronized (zone.players) {
                    for (Player p : zone.players) {
                        if (p != null && p instanceof VirtualBot_SoSinh && !p.equals(player)) {
                            botsToDelete.add(p);
                            if (quantity > 0 && botsToDelete.size() >= quantity) {
                                break;
                            }
                        }
                    }
                }
                if (quantity > 0 && botsToDelete.size() >= quantity) {
                    break;
                }
            }
            if (quantity > 0 && botsToDelete.size() >= quantity) {
                break;
            }
        }

        for (Player bot : botsToDelete) {
            if (bot.zone != null) {
                bot.zone.leave(bot);
                bot.close();
                deleted++;
            }
        }

        player.service.sendThongBao("Đã xóa " + deleted + " Bot");
    }

    private void deleteBotsInCurrentZone(Player player) {
        if (player.zone == null) {
            return;
        }

        int deleted = 0;
        List<Player> botsToDelete = new ArrayList<>();

        synchronized (player.zone.players) {
            for (Player p : player.zone.players) {
                if (p != null && p instanceof VirtualBot_SoSinh && !p.equals(player)) {
                    botsToDelete.add(p);
                }
            }
        }

        for (Player bot : botsToDelete) {
            player.zone.leave(bot);
            bot.close();
            deleted++;
        }

        player.service.sendThongBao("Đã xóa " + deleted + " Bot trong khu hiện tại");
    }

    private void showBotList(Player player) {
        int totalBots = 0;
        StringBuilder botList = new StringBuilder("Danh sách Bot:\n");

        for (TMap map : MapManager.getInstance().maps.values()) {
            if (map == null || map.zones == null) {
                continue;
            }
            for (Zone zone : map.zones) {
                if (zone == null || zone.players == null) {
                    continue;
                }
                synchronized (zone.players) {
                    for (Player p : zone.players) {
                        if (p != null && p instanceof VirtualBot_SoSinh) {
                            totalBots++;
                            if (totalBots <= 20) {
                                botList.append("- ").append(p.name).append(" (Map: ").append(zone.map.mapID).append(")\n");
                            }
                        }
                    }
                }
            }
        }

        if (totalBots > 20) {
            botList.append("... và ").append(totalBots - 20).append(" Bot khác");
        }

        botList.append("\nTổng: ").append(totalBots).append(" Bot");

        player.service.sendThongBao(botList.toString());
    }

    private void resetUsedBotNames(Player player) {
        try {
            List<BotConfigData> allConfigs = GameRepository.getInstance().botConfig.findAll();
            int resetCount = 0;

            for (BotConfigData config : allConfigs) {
                if (config.getIsUsed() != null && config.getIsUsed()) {
                    config.setIsUsed(false);
                    GameRepository.getInstance().botConfig.save(config);
                    resetCount++;
                }
            }

            player.service.sendThongBao("Đã reset " + resetCount + " tên Bot");
        } catch (Exception e) {
            player.service.sendThongBao("Lỗi khi reset tên Bot");
        }
    }
}
