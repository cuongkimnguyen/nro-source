/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ngocrong.top;

import com.ngocrong.consts.ItemName;
import com.ngocrong.item.Item;
import com.ngocrong.item.ItemOption;
import com.ngocrong.server.mysql.MySQLConnect;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Administrator
 */
public class ExportTop {

    private static final String INSERT_REWARD
            = "INSERT INTO nr_rewardtop (player_name, item, infoTop, isReward) VALUES (?, ?, ?, 0)";

    /**
     * Finalize Top Power rankings and export reward data.
     */
    public static void exportTopPower() {
        Top top = Top.getTop(Top.TOP_POWER);
        if (top == null) {
            return;
        }

        List<TopInfo> list = new ArrayList<>(top.getElements());
        try (PreparedStatement ps = MySQLConnect.getConnection().prepareStatement(INSERT_REWARD)) {
            for (int i = 0; i < list.size(); i++) {
                int rank = i + 1;
                TopInfo info = list.get(i);
                List<Item> items = itemRewardPower(rank);
                if (items.isEmpty()) {
                    continue;
                }
                ps.setString(1, info.name);
                ps.setString(2, com.ngocrong.top.AutoReward.AutoReward.ItemstoJson(items));
                ps.setString(3, "Top " + rank + " Sức mạnh sư phụ");
                ps.addBatch();
            }
            ps.executeBatch();
        } catch (SQLException e) {
            // com.ngocrong.NQMP.// UtilsNQMP.logError(e);
        }
    }

    /**
     * Finalize Top Task rankings and export reward data.
     */
    public static void exportTopTask() {
        Top top = Top.getTop(Top.TOP_TASK);
        if (top == null) {
            return;
        }

        List<TopInfo> list = new ArrayList<>(top.getElements());
        try (PreparedStatement ps = MySQLConnect.getConnection().prepareStatement(INSERT_REWARD)) {
            for (int i = 0; i < list.size(); i++) {
                int rank = i + 1;
                TopInfo info = list.get(i);
                List<Item> items = itemRewardTask(rank);
                if (items.isEmpty()) {
                    continue;
                }
                ps.setString(1, info.name);
                ps.setString(2, com.ngocrong.top.AutoReward.AutoReward.ItemstoJson(items));
                ps.setString(3, "Top " + rank + " Nhiệm vụ");
                ps.addBatch();
            }
            ps.executeBatch();
        } catch (SQLException e) {
            // com.ngocrong.NQMP.// UtilsNQMP.logError(e);
        }
    }

    /**
     * Finalize Top spending Gold Bar rankings and export reward data.
     */
    public static void exportTopUseGoldBar() {
        Top top = Top.getTop(Top.TOP_USING_GOLBAR);
        if (top == null) {
            return;
        }

        List<TopInfo> list = new ArrayList<>(top.getElements());
        try (PreparedStatement ps = MySQLConnect.getConnection().prepareStatement(INSERT_REWARD)) {
            for (int i = 0; i < list.size(); i++) {
                int rank = i + 1;
                TopInfo info = list.get(i);
                List<Item> items = itemRewardGoldBar(rank);
                if (items.isEmpty()) {
                    continue;
                }
                ps.setString(1, info.name);
                ps.setString(2, com.ngocrong.top.AutoReward.AutoReward.ItemstoJson(items));
                ps.setString(3, "Top " + rank + " Tiêu thỏi vàng");
                ps.addBatch();
            }
            ps.executeBatch();
        } catch (SQLException e) {
            // com.ngocrong.NQMP.// UtilsNQMP.logError(e);
        }
    }

    /**
     * Finalize Top Raiti boss kill rankings and export reward data.
     */
    public static void exportTopKillRaiti() {
        Top top = Top.getTop(Top.TOP_RAITI);
        if (top == null) {
            return;
        }

        List<TopInfo> list = new ArrayList<>(top.getElements());
        try (PreparedStatement ps = MySQLConnect.getConnection().prepareStatement(INSERT_REWARD)) {
            for (int i = 0; i < list.size(); i++) {
                int rank = i + 1;
                TopInfo info = list.get(i);
                List<Item> items = itemRewardRaiti(rank);
                if (items.isEmpty()) {
                    continue;
                }
                ps.setString(1, info.name);
                ps.setString(2, com.ngocrong.top.AutoReward.AutoReward.ItemstoJson(items));
                ps.setString(3, "Top " + rank + " Săn Boss Raiti");
                ps.addBatch();
            }
            ps.executeBatch();
        } catch (SQLException e) {
            // com.ngocrong.NQMP.// UtilsNQMP.logError(e);
        }
    }

    /**
     * Finalize Top Disciple power rankings and export reward data.
     */
    public static void exportTopDisciple() {
        Top top = Top.getTop(Top.TOP_DISCIPLE_POWER);
        if (top == null) {
            return;
        }

        List<TopInfo> list = new ArrayList<>(top.getElements());
        try (PreparedStatement ps = MySQLConnect.getConnection().prepareStatement(INSERT_REWARD)) {
            for (int i = 0; i < list.size(); i++) {
                int rank = i + 1;
                TopInfo info = list.get(i);
                List<Item> items = itemRewardDisciple(rank);
                if (items.isEmpty()) {
                    continue;
                }
                ps.setString(1, info.name);
                ps.setString(2, com.ngocrong.top.AutoReward.AutoReward.ItemstoJson(items));
                ps.setString(3, "Top " + rank + " Úp sức mạnh đệ tử");
                ps.addBatch();
            }
            ps.executeBatch();
        } catch (SQLException e) {
            // com.ngocrong.NQMP.// UtilsNQMP.logError(e);
        }
    }


    /**
     * Finalize Top Kill Boss rankings and export reward data.
     */
    public static void exportTopKillBoss() {
        Top top = Top.getTop(Top.TOP_KILLBOSS);
        if (top == null) {
            return;
        }

        List<TopInfo> list = new ArrayList<>(top.getElements());
        try (PreparedStatement ps = MySQLConnect.getConnection().prepareStatement(INSERT_REWARD)) {
            for (int i = 0; i < list.size(); i++) {
                int rank = i + 1;
                TopInfo info = list.get(i);
                List<Item> items = itemRewardKillBoss(rank);
                if (items.isEmpty()) {
                    continue;
                }
                ps.setString(1, info.name);
                ps.setString(2, com.ngocrong.top.AutoReward.AutoReward.ItemstoJson(items));
                ps.setString(3, "Top " + rank + " Săn Boss");
                ps.addBatch();
            }
            ps.executeBatch();
        } catch (SQLException e) {
            // com.ngocrong.NQMP.// UtilsNQMP.logError(e);
        }
    }

    /**
     * Finalize Top Disciple Mabu power rankings and export reward data.
     */
    public static void exportTopDisciplePowerMabu() {
        Top top = Top.getTop(Top.TOP_DT_MABU);
        if (top == null) {
            return;
        }

        List<TopInfo> list = new ArrayList<>(top.getElements());
        try (PreparedStatement ps = MySQLConnect.getConnection().prepareStatement(INSERT_REWARD)) {
            for (int i = 0; i < list.size(); i++) {
                int rank = i + 1;
                TopInfo info = list.get(i);
                List<Item> items = itemRewardDisciplePowerMabu(rank);
                if (items.isEmpty()) {
                    continue;
                }
                ps.setString(1, info.name);
                ps.setString(2, com.ngocrong.top.AutoReward.AutoReward.ItemstoJson(items));
                ps.setString(3, "Top " + rank + " Đệ tử Mabu");
                ps.addBatch();
            }
            ps.executeBatch();
        } catch (SQLException e) {
            // com.ngocrong.NQMP.// UtilsNQMP.logError(e);
        }
    }



    private static List<Item> itemRewardPower(int rank) {
        List<Item> list = new ArrayList<>();
        if (rank == 1) {
            list.add(createItem(ItemName.RUONG_THAN_LINH, 3));
            list.add(createItem(ItemName.DANH_HIEU_TOP_1_SUC_MANH, 1));
        } else if (rank == 2) {
            list.add(createItem(ItemName.RUONG_THAN_LINH, 2));
            list.add(createItem(ItemName.DANH_HIEU_TOP_2_SUC_MANH, 1));
        } else if (rank == 3) {
            list.add(createItem(ItemName.RUONG_THAN_LINH, 2));
            list.add(createItem(ItemName.DANH_HIEU_TOP_3_SUC_MANH, 1));
        } else if (rank >= 4 && rank <= 10) {
            list.add(createItem(ItemName.RUONG_THAN_LINH, 1));
            list.add(createItem(ItemName.HONG_NGOC, 1000));
        } else if (rank >= 11 && rank <= 20) {
            list.add(createItem(ItemName.THOI_VANG, 200));
            list.add(createItem(ItemName.HONG_NGOC, 500));
            list.add(createItem(ItemName.RUONG_DA_NANG_CAP, 1000));
            list.add(createItem(ItemName.RUONG_NGOC_RONG, 10));
        } else if (rank >= 21 && rank <= 50) {
            list.add(createItem(ItemName.THOI_VANG, 100));
            list.add(createItem(ItemName.RUONG_ITEM_CAP_1, 30));
            list.add(createItem(ItemName.RUONG_NGOC_RONG, 10));
        } else if (rank >= 51 && rank <= 100) {
            list.add(createItem(ItemName.THOI_VANG, 50));
            list.add(createItem(ItemName.RUONG_NGOC_RONG, 10));
        }
        return list;
    }

    private static List<Item> itemRewardTask(int rank) {
        List<Item> list = new ArrayList<>();
        if (rank == 1) {
            list.add(createItem(2335, 1));
            list.add(createItem(2355, 1));
            list.add(createItem(ItemName.RUONG_THAN_LINH, 2));
            list.add(createItem(ItemName.DANH_HIEU_TOP_1_NHIEM_VU, 1));
            list.add(createItem(ItemName.VE_TICH_DIEM, 400));
        } else if (rank == 2) {
            list.add(createItem(2335, 1));
            list.add(createItem(2355, 1));
            list.add(createItem(ItemName.RUONG_THAN_LINH, 1));
            list.add(createItem(ItemName.DANH_HIEU_TOP_2_NHIEM_VU, 1));
            list.add(createItem(ItemName.VE_TICH_DIEM, 300));
        } else if (rank == 3) {
            list.add(createItem(2335, 1));
            list.add(createItem(2355, 1));
            list.add(createItem(ItemName.RUONG_THAN_LINH, 1));
            list.add(createItem(ItemName.DANH_HIEU_TOP_3_NHIEM_VU, 1));
            list.add(createItem(ItemName.VE_TICH_DIEM, 200));
        } else if (rank >= 4 && rank <= 10) {
            list.add(createItem(2335, 1));
            list.add(createItem(2355, 1));
            list.add(createItem(ItemName.RUONG_1_MON_HUY_DIET, 3));
            list.add(createItem(ItemName.VE_TICH_DIEM, 100));
        } else if (rank >= 11 && rank <= 20) {
            list.add(createItem(2355, 1));
            list.add(createItem(ItemName.DA_BAO_VE_987, 20));
            list.add(createItem(ItemName.RUONG_NGOC_RONG, 10));
        } else if (rank >= 21 && rank <= 50) {
            list.add(createItem(ItemName.THOI_VANG, 50));
            list.add(createItem(ItemName.RUONG_NGOC_RONG, 10));
            list.add(createItem(ItemName.RUONG_ITEM_CAP_2, 10));
        } else if (rank >= 51 && rank <= 100) {
            list.add(createItem(ItemName.THOI_VANG, 30));
            list.add(createItem(ItemName.DA_BAO_VE_987, 5));
        }
        return list;
    }

    private static List<Item> itemRewardGoldBar(int rank) {
        List<Item> list = new ArrayList<>();
        if (rank == 1) {
            list.add(createItem(ItemName.THOI_VANG, 10000));
            list.add(createItem(ItemName.DANH_HIEU_VIP_1, 1));
            list.add(createItem(ItemName.RUONG_THAN_LINH_KICH_HOAT, 1));
            list.add(createItem(2353, 1));
            list.add(createItem(ItemName.HON_LINH_THU, 10000));
        } else if (rank == 2) {
            list.add(createItem(ItemName.THOI_VANG, 7000));
            list.add(createItem(ItemName.DANH_HIEU_VIP_2, 1));
            list.add(createItem(ItemName.RUONG_THAN_LINH_KICH_HOAT, 1));
            list.add(createItem(2353, 1));
            list.add(createItem(ItemName.HON_LINH_THU, 7000));
        } else if (rank == 3) {
            list.add(createItem(ItemName.THOI_VANG, 5000));
            list.add(createItem(ItemName.DANH_HIEU_VIP_3, 1));
            list.add(createItem(ItemName.RUONG_THAN_LINH_KICH_HOAT, 1));
            list.add(createItem(2353, 1));
            list.add(createItem(ItemName.HON_LINH_THU, 5000));
        } else if (rank >= 4 && rank <= 10) {
            list.add(createItem(ItemName.RUONG_SET_HUY_DIET, 1));
            list.add(createItem(2353, 1));
        } else if (rank >= 11 && rank <= 20) {
            list.add(createItem(ItemName.DA_BAO_VE_987, 50));
            list.add(createItem(ItemName.NGOC_RONG_1_SAO, 1));
            list.add(createItem(ItemName.NGOC_RONG_2_SAO, 1));
            list.add(createItem(ItemName.NGOC_RONG_3_SAO, 1));
            list.add(createItem(ItemName.NGOC_RONG_4_SAO, 1));
            list.add(createItem(ItemName.NGOC_RONG_5_SAO, 1));
            list.add(createItem(ItemName.NGOC_RONG_6_SAO, 1));
            list.add(createItem(ItemName.NGOC_RONG_7_SAO, 1));
            list.add(createItem(ItemName.THU_BAY, 1));
            list.add(createItem(ItemName.RUONG_1_MON_HUY_DIET, 3));
        } else if (rank >= 21 && rank <= 50) {
            list.add(createItem(ItemName.DA_BAO_VE_987, 20));
            list.add(createItem(ItemName.THOI_VANG, 50));
            list.add(createItem(ItemName.THU_BAY, 1));
            list.add(createItem(ItemName.GIAP_TAP_LUYEN_CAP_4, 1));
        } else if (rank >= 51 && rank <= 100) {
            list.add(createItem(ItemName.THU_BAY, 1));
            list.add(createItem(ItemName.RUONG_DA_NANG_CAP, 1000));
        }
        return list;
    }

    private static List<Item> itemRewardRaiti(int rank) {
        List<Item> list = new ArrayList<>();
        if (rank == 1) {
            list.add(createItem(ItemName.DANH_HIEU_CAY_TOP_1, 1));
            list.add(createItem(ItemName.NGOC_RONG_1_SAO, 3));
            list.add(createItem(ItemName.NGOC_RONG_2_SAO, 3));
            list.add(createItem(ItemName.NGOC_RONG_3_SAO, 3));
            list.add(createItem(ItemName.NGOC_RONG_4_SAO, 3));
            list.add(createItem(ItemName.NGOC_RONG_5_SAO, 3));
            list.add(createItem(ItemName.NGOC_RONG_6_SAO, 3));
            list.add(createItem(ItemName.NGOC_RONG_7_SAO, 3));
        } else if (rank == 2) {
            list.add(createItem(ItemName.DANH_HIEU_CAY_TOP_2, 1));
            list.add(createItem(ItemName.NGOC_RONG_1_SAO, 2));
            list.add(createItem(ItemName.NGOC_RONG_2_SAO, 2));
            list.add(createItem(ItemName.NGOC_RONG_3_SAO, 2));
            list.add(createItem(ItemName.NGOC_RONG_4_SAO, 2));
            list.add(createItem(ItemName.NGOC_RONG_5_SAO, 2));
            list.add(createItem(ItemName.NGOC_RONG_6_SAO, 2));
            list.add(createItem(ItemName.NGOC_RONG_7_SAO, 2));
        } else if (rank == 3) {
            list.add(createItem(ItemName.DANH_HIEU_CAY_TOP_3, 1));
            list.add(createItem(ItemName.NGOC_RONG_1_SAO, 1));
            list.add(createItem(ItemName.NGOC_RONG_2_SAO, 1));
            list.add(createItem(ItemName.NGOC_RONG_3_SAO, 1));
            list.add(createItem(ItemName.NGOC_RONG_4_SAO, 1));
            list.add(createItem(ItemName.NGOC_RONG_5_SAO, 1));
            list.add(createItem(ItemName.NGOC_RONG_6_SAO, 1));
            list.add(createItem(ItemName.NGOC_RONG_7_SAO, 1));
        } else if (rank >= 4 && rank <= 10) {
            list.add(createItem(ItemName.THOI_VANG, 100));
        } else if (rank >= 11 && rank <= 20) {
            list.add(createItem(ItemName.THOI_VANG, 50));
        } else if (rank >= 21 && rank <= 50) {
            list.add(createItem(ItemName.THOI_VANG, 20));
        } else if (rank >= 51 && rank <= 100) {
            list.add(createItem(ItemName.THOI_VANG, 10));
        }
        return list;
    }

    private static List<Item> itemRewardDisciple(int rank) {
        List<Item> list = new ArrayList<>();
        if (rank == 1) {
            list.add(createItem(ItemName.DANH_HIEU_THANH_UP_DE, 1));
            list.add(createItem(2355, 1));
            list.add(createItem(942, 1));
            list.add(createItem(ItemName.RUONG_THAN_LINH, 2));
        } else if (rank == 2) {
            list.add(createItem(ItemName.DANH_HIEU_THANH_UP_DE, 1));
            list.add(createItem(2355, 1));
            list.add(createItem(942, 1));
            list.add(createItem(ItemName.RUONG_THAN_LINH, 1));
        } else if (rank == 3) {
            list.add(createItem(ItemName.DANH_HIEU_THANH_UP_DE, 1));
            list.add(createItem(2355, 1));
            list.add(createItem(942, 1));
            list.add(createItem(ItemName.RUONG_THAN_LINH, 1));
        } else if (rank >= 4 && rank <= 10) {
            list.add(createItem(2355, 1));
            list.add(createItem(942, 1));
            list.add(createItem(ItemName.THOI_VANG, 500));
        } else if (rank >= 11 && rank <= 20) {
            list.add(createItem(ItemName.THOI_VANG, 200));
            list.add(createItem(942, 1));
        } else if (rank >= 21 && rank <= 50) {
            list.add(createItem(ItemName.THOI_VANG, 50));
            list.add(createItem(942, 1));
        } else if (rank >= 51 && rank <= 100) {
            list.add(createItem(ItemName.THOI_VANG, 30));
            list.add(createItem(ItemName.RUONG_DA_NANG_CAP, 200));
        }
        return list;
    }

    private static List<Item> itemRewardKillBoss(int rank) {
        List<Item> list = new ArrayList<>();
        if (rank == 1) {
            list.add(createItem(ItemName.THOI_VANG, 5000));
            list.add(createItem(ItemName.DANH_HIEU_TOP_SAN_BOSS, 1));
        } else if (rank == 2) {
            list.add(createItem(ItemName.THOI_VANG, 3000));
            list.add(createItem(ItemName.DANH_HIEU_TOP_SAN_BOSS, 1));
        } else if (rank == 3) {
            list.add(createItem(ItemName.THOI_VANG, 1000));
            list.add(createItem(ItemName.DANH_HIEU_TOP_SAN_BOSS, 1));
        } else if (rank >= 4 && rank <= 10) {
            list.add(createItem(ItemName.THOI_VANG, 200));
        } else if (rank >= 11 && rank <= 20) {
            list.add(createItem(ItemName.THOI_VANG, 100));
        } else if (rank >= 21 && rank <= 50) {
            list.add(createItem(ItemName.THOI_VANG, 50));
        } else if (rank >= 51 && rank <= 100) {
            list.add(createItem(ItemName.THOI_VANG, 20));
        }
        return list;
    }


    private static List<Item> itemRewardDisciplePowerMabu(int rank) {
        List<Item> list = new ArrayList<>();
        if (rank == 1) {
            list.add(createItem(ItemName.RUONG_SET_KICH_HOAT, 1));
            list.add(createItem(ItemName.DANH_HIEU_THANH_UP_DE, 1));
            list.add(createItem(ItemName.HON_LINH_THU, 3000));
            list.add(createItem(942, 1));
        } else if (rank == 2) {
            list.add(createItem(ItemName.RUONG_SET_KICH_HOAT, 1));
            list.add(createItem(ItemName.DANH_HIEU_THANH_UP_DE, 1));
            list.add(createItem(ItemName.HON_LINH_THU, 2000));
            list.add(createItem(942, 1));
        } else if (rank == 3) {
            list.add(createItem(ItemName.RUONG_SET_KICH_HOAT, 1));
            list.add(createItem(ItemName.DANH_HIEU_THANH_UP_DE, 1));
            list.add(createItem(ItemName.HON_LINH_THU, 1000));
            list.add(createItem(942, 1));
        } else if (rank == 4 || rank == 5) {
            list.add(createItem(ItemName.RUONG_SET_HUY_DIET, 1));
            list.add(createItem(942, 1));
            list.add(createItem(ItemName.HON_LINH_THU, 300));
        } else if (rank >= 6 && rank <= 10) {
            list.add(createItem(ItemName.RUONG_1_MON_SKH, 2));
            list.add(createItem(942, 1));
        } else if (rank >= 11 && rank <= 20) {
            list.add(createItem(942, 1));
            list.add(createItem(ItemName.RUONG_DO_CUOI_6_SAO, 1));
            list.add(createItem(ItemName.RUONG_ITEM_CAP_2, 30));
        } else if (rank >= 21 && rank <= 50) {
            list.add(createItem(942, 1));
            list.add(createItem(ItemName.THOI_VANG, 50));
            list.add(createItem(ItemName.RUONG_ITEM_CAP_2, 5));
        } else if (rank >= 51 && rank <= 100) {
            list.add(createItem(ItemName.RUONG_DO_CUOI_5_SAO, 1));
            list.add(createItem(ItemName.THOI_VANG, 20));
        }
        return list;
    }


    private static Item createItem(int id, int quantity) {
        Item item = new Item(id);
        item.quantity = quantity;
        item.setDefaultOptions();
        switch (id) {
            case 2335:
                item.options.add(new ItemOption(77, 35));
                item.options.add(new ItemOption(103, 35));
                item.options.add(new ItemOption(50, 35));
                break;
            case 2289:
                item.options.add(new ItemOption(77, 35));
                item.options.add(new ItemOption(103, 35));
                item.options.add(new ItemOption(50, 35));
                break;
            case 2355:
                item.options.add(new ItemOption(77, 15));
                item.options.add(new ItemOption(103, 15));
                item.options.add(new ItemOption(50, 15));
                break;
            case 2252:
                item.options.add(new ItemOption(77, 15));
                item.options.add(new ItemOption(103, 15));
                item.options.add(new ItemOption(50, 15));
                break;
            case 2255:
                item.options.add(new ItemOption(77, 35));
                item.options.add(new ItemOption(103, 35));
                item.options.add(new ItemOption(50, 35));
                break;
            case 942:
                item.options.clear();
                item.options.add(new ItemOption(77, 15));
                item.options.add(new ItemOption(103, 15));
                item.options.add(new ItemOption(50, 15));
                break;
            case 1974:
            case 1975:
            case 1976:
                item.options.clear();
                item.options.add(new ItemOption(77, 8));
                item.options.add(new ItemOption(103, 8));
                item.options.add(new ItemOption(50, 8));
                break;
            case 2268:
                item.options.add(new ItemOption(77, 10));
                item.options.add(new ItemOption(103, 10));
                break;
            case 2353:
                item.options.add(new ItemOption(77, 5));
                item.options.add(new ItemOption(103, 5));
                item.options.add(new ItemOption(50, 5));
                break;
            case ItemName.DANH_HIEU_TOP_SAN_BOSS:
                item.options.add(new ItemOption(77, 8));
                item.options.add(new ItemOption(103, 8));
                item.options.add(new ItemOption(50, 8));
                break;
            case ItemName.DANH_HIEU_THANH_UP_DE:
                item.options.clear();
                item.options.add(new ItemOption(77, 10));
                item.options.add(new ItemOption(103, 10));
                item.options.add(new ItemOption(50, 10));
                break;
            case ItemName.DANH_HIEU_NGUOI_GIU_LUA:
                item.options.add(new ItemOption(77, 8));
                item.options.add(new ItemOption(103, 8));
                item.options.add(new ItemOption(50, 8));
                break;
        }
        return item;
    }
}
