
package _gwenstudio;

/**
 * @author GwenDevStudio
 */
public class ConfigEvent {
    
    // ==================== EVENT CONFIGURATION ====================
    
    /**
     * Osin Check-in Event (Điểm danh hàng ngày)
     */
    public static final boolean OSIN_CHECKIN_EVENT = true;
    
    /**
     * DHVT Events (Đại Hội Võ Thuật)
     */
    public static final boolean DHVT_EVENT = true;
    
    // ==================== HELPER METHODS ====================
    
    /**
     * Get event status as string
     */
    public static String getEventStatus(String eventName, boolean status) {
        return String.format("[%s] %s: %s", 
            status ? "ON" : "OFF", 
            eventName, 
            status ? "ENABLED" : "DISABLED"
        );
    }
    
    public static void printAllEventStatus() {
        System.out.println("========== EVENT CONFIGURATION ==========");
        System.out.println(getEventStatus("Osin Check-in", OSIN_CHECKIN_EVENT));
        System.out.println(getEventStatus("DHVT", DHVT_EVENT));
        System.out.println("=========================================");
    }
}
