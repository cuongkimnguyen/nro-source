package _gwenstudio.bot;

import com.ngocrong.bot.Boss;
import com.ngocrong.item.Item;
import com.ngocrong.map.MapManager;
import com.ngocrong.map.TMap;
import com.ngocrong.map.tzone.Zone;
import com.ngocrong.mob.Mob;
import com.ngocrong.skill.Skill;
import com.ngocrong.skill.Skills;
import com.ngocrong.user.Info;
import com.ngocrong.user.Player;
import com.ngocrong.util.Utils;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class BotTrain extends Boss {

    private static final Logger logger = Logger.getLogger(BotTrain.class);

    public long lastCheckSM = 0;
    public long lastChangeMap = 0;
    public long lastAddPoint = 0;
    public long lastEquipCheck = 0;
    public long lastBossCheck = 0;
    public long lastAttack = 0;

    public Mob currentTarget = null;
    public Boss currentBoss = null;
    public int targetMapID = -1;
    public int currentTrainMap = 0;

    public long targetSM = 0;
    public long currentSM = 0;
    public int currentLevel = 0;

    public boolean isTraining = false;
    public boolean needChangeMap = false;
    public boolean needEquip = false;
    public boolean needAddPoint = false;

    public static int TotalBotTrain = 0;

    private static final long CHECK_SM_INTERVAL = 10000;
    private static final long CHANGE_MAP_INTERVAL = 1800000;
    private static final long EQUIP_CHECK_INTERVAL = 60000;
    private static final long ADD_POINT_INTERVAL = 5000;
    private static final long BOSS_CHECK_INTERVAL = 300000;
    private static final long ATTACK_COOLDOWN = 550;

    private static final int MOB_LEVEL_DIFF = 5;
    private static final double BOSS_SM_MULTIPLIER = 2.0;

    public BotTrain(String name, Zone zone) {
        super();
        long hp = Utils.nextInt(100000, 500000);
        long mp = Utils.nextInt(200000, 5000000);
        long dame = Utils.nextInt(10000, 50000);
        this.setInfo(hp, mp, dame, 100, 5);
        this.setBuaThuHut(true);
        this.willLeaveAtDeath = false;
        this.name = name;
        
        if (zone != null && zone.map != null) {
            if (zone.map.mapID != 5) {
                this.setX((short) Utils.nextInt(0, zone.map.width - 50));
            } else {
                if (Utils.nextInt(10) % 2 == 0) {
                    this.setX((short) Utils.nextInt(0, zone.map.width - 50));
                } else {
                    this.setX((short) Utils.nextInt(888, 1280));
                }
            }
            short x = this.getX();
            short y = (short) zone.map.collisionLand(x, (short) Utils.nextInt(0, zone.map.height - 50));
            this.setY(y);
        }
        
        this.itemBag = new Item[100];
        this.gender = (byte) Utils.nextInt(3);
        this.info.power = Utils.nextLong(15_000_000L, 30_000_000L);
        this.id = Utils.nextInt(1000, 100000);
        
        short[][] hair = new short[][]{
            {64, 30, 31}, {9, 29, 32}, {6, 27, 28}
        };
        short head = hair[this.gender][Utils.nextInt(hair[this.gender].length)];
        short body = (short) (this.gender == 0 ? 14 : this.gender == 1 ? 10 : 16);
        short leg = (short) (this.gender == 0 ? 15 : this.gender == 1 ? 11 : 17);
        boolean Ctrang = Utils.isTrue(8, 10);
        this.setHead(Ctrang ? (short) 906 : head);
        this.setBody(Ctrang ? (short) 880 : body);
        this.setLeg(Ctrang ? (short) 881 : leg);
        
        this.isTraining = true;
        this.currentSM = this.info.power;
        this.targetSM = this.currentSM * 2;
        this.currentTrainMap = zone != null && zone.map != null ? zone.map.mapID : 0;
        
        TotalBotTrain++;
    }

    @Override
    public void setInfo(long hp, long mp, long dame, int def, int crit) {
        info.originalHP = hp;
        info.originalMP = Long.MAX_VALUE;
        info.originalDamage = dame;
        info.originalDefense = def;
        info.originalCritical = crit;
        info.setInfo();
        info.recovery(Info.ALL, 100, false);
    }

    @Override
    public void update() {
        this.info.mp = this.info.mpFull = Long.MAX_VALUE;
        this.setBuaThuHut(true);
        
        if (this.zone != null) {
            long now = System.currentTimeMillis();
            
            if (now - lastCheckSM >= CHECK_SM_INTERVAL) {
                checkSM();
                lastCheckSM = now;
            }
            
            if (now - lastChangeMap >= CHANGE_MAP_INTERVAL) {
                if (shouldChangeMap()) {
                    autoChangeMap();
                    lastChangeMap = now;
                }
            }
            
            if (now - lastEquipCheck >= EQUIP_CHECK_INTERVAL) {
                autoEquip();
                lastEquipCheck = now;
            }
            
            if (now - lastAddPoint >= ADD_POINT_INTERVAL) {
                autoAddPoint();
                lastAddPoint = now;
            }
            
            if (now - lastBossCheck >= BOSS_CHECK_INTERVAL) {
                autoAttackBoss();
                lastBossCheck = now;
            }
            
            autoAttackMob();
            
            try {
                super.update();
            } catch (Exception e) {
                logger.error("BotTrain update error", e);
            }
        }
    }

    public void checkSM() {
        this.currentSM = this.info.power;
        this.currentLevel = this.info.level;
        
        if (this.currentSM >= this.targetSM) {
            this.targetSM = this.currentSM * 2;
        }
    }

    public void autoAttackMob() {
        if (zone == null) return;
        
        if (currentTarget == null) {
            currentTarget = findBestMob();
        }
        
        if (currentTarget != null) {
            if (currentTarget.status == 0 || currentTarget.status == 1 
                || currentTarget.isMobMe || currentTarget.hp <= 0) {
                currentTarget = null;
                return;
            }
            
            if (this.skills == null || this.skills.isEmpty()) {
                return;
            }
            
            this.select = skills.get(0);
            if (this.select != null) {
                this.select.manaUse = 0;
            }
            
            int distanceX = Math.abs(this.getX() - currentTarget.x);
            int distanceY = Math.abs(this.getY() - currentTarget.y);
            
            if (this.select != null && (distanceX > this.select.dx * 1.2 || distanceY > this.select.dy * 1.2)) {
                if (this.meCanMove()) {
                    this.moveTo(currentTarget.x, currentTarget.y);
                }
                return;
            }
            
            if (this.meCanAttack() && System.currentTimeMillis() - lastAttack >= ATTACK_COOLDOWN) {
                this.zone.attackNpc(this, currentTarget, false);
                lastAttack = System.currentTimeMillis();
            }
        }
    }

    public Mob findBestMob() {
        if (zone == null) return null;
        
        List<Mob> mobs = zone.getListMob();
        Mob bestMob = null;
        double minDistance = Double.MAX_VALUE;
        
        int playerX = this.getX();
        int playerY = this.getY();
        
        for (Mob mob : mobs) {
            if (mob == null || mob.status == 0 || mob.status == 1 
                || mob.isMobMe || mob.hp <= 0) {
                continue;
            }
            
            if (!isMobSuitable(mob)) {
                continue;
            }
            
            double distance = Math.sqrt(
                Math.pow(mob.x - playerX, 2) + 
                Math.pow(mob.y - playerY, 2)
            );
            
            if (distance < minDistance) {
                minDistance = distance;
                bestMob = mob;
            }
        }
        
        return bestMob;
    }

    public boolean isMobSuitable(Mob mob) {
        if (mob == null) return false;
        int mobLevel = mob.level;
        int playerLevel = this.info.level;
        return Math.abs(mobLevel - playerLevel) <= MOB_LEVEL_DIFF;
    }

    public void autoAddPoint() {
        if (!hasAvailablePoint()) {
            return;
        }
        
        long currentHP = this.info.originalHP;
        long currentDamage = this.info.originalDamage;
        
        if (currentHP < currentDamage * 10) {
            addPointToHP();
            return;
        }
        
        if (currentDamage < currentHP / 10) {
            addPointToDamage();
            return;
        }
        
        addPointToMP();
    }

    public boolean hasAvailablePoint() {
        return this.info.potential > 0;
    }

    public void addPointToHP() {
        if (this.info.potential >= 1000) {
            this.info.originalHP += Info.HP_FROM_1000_TIEM_NANG;
            this.info.potential -= 1000;
            this.info.setInfo();
        }
    }

    public void addPointToMP() {
        if (this.info.potential >= 1000) {
            this.info.originalMP += Info.MP_FROM_1000_TIEM_NANG;
            this.info.potential -= 1000;
            this.info.setInfo();
        }
    }

    public void addPointToDamage() {
        if (this.info.potential >= 1000) {
            this.info.originalDamage += Info.DAMAGE_FROM_1000_TIEM_NANG;
            this.info.potential -= 1000;
            this.info.setInfo();
        }
    }

    public void autoChangeMap() {
        if (!shouldChangeMap()) {
            return;
        }
        
        int newMapID = getSuitableMapBySM(this.currentSM);
        if (newMapID == -1) {
            return;
        }
        
        changeToMap(newMapID);
    }

    public boolean shouldChangeMap() {
        if (this.zone == null || this.zone.map == null) {
            return false;
        }
        
        int currentMapID = this.zone.map.mapID;
        int suitableMapID = getSuitableMapBySM(this.currentSM);
        
        return currentMapID != suitableMapID;
    }

    public int getSuitableMapBySM(long sm) {
        if (sm < 1500000) {
            int[] maps = {0, 1, 2, 7, 8, 9, 14, 15, 16};
            return maps[Utils.nextInt(maps.length)];
        } else if (sm < 5000000) {
            int[] maps = {3, 4, 6, 10, 11, 12, 17, 18, 19};
            return maps[Utils.nextInt(maps.length)];
        } else if (sm < 20000000) {
            int[] maps = {20, 27, 28, 29, 30, 31, 32, 33, 34};
            return maps[Utils.nextInt(maps.length)];
        } else if (sm < 50000000) {
            int[] maps = {35, 36, 37, 38};
            return maps[Utils.nextInt(maps.length)];
        } else {
            return 6;
        }
    }

    public void changeToMap(int mapID) {
        TMap map = MapManager.getInstance().getMap(mapID);
        if (map == null) return;
        
        Zone zone = map.getMinPlayerZone();
        if (zone == null) return;
        
        if (this.zone != null) {
            this.zone.leave(this);
        }
        zone.enter(this);
        this.currentTrainMap = mapID;
    }

    public void autoEquip() {
        int targetLevel = getItemLevelBySM(this.currentSM);
        
        for (int type = 0; type <= 4; type++) {
            Item currentItem = this.itemBody[type];
            Item bestItem = findBestItemInBag(type, targetLevel);
            
            if (bestItem != null && shouldEquip(currentItem, bestItem)) {
                equipItem(bestItem, type);
            }
        }
    }

    public int getItemLevelBySM(long sm) {
        if (sm < 5000000) return 10;
        if (sm < 20000000) return 20;
        if (sm < 50000000) return 30;
        if (sm < 100000000) return 40;
        return 50;
    }

    public Item findBestItemInBag(int type, int minLevel) {
        Item bestItem = null;
        int bestLevel = -1;
        
        if (this.itemBag == null) return null;
        
        for (Item item : this.itemBag) {
            if (item == null) continue;
            if (item.template == null) continue;
            if (item.template.type != type) continue;
            if (item.template.level < minLevel) continue;
            
            if (item.template.gender != this.gender && item.template.gender != 3) {
                continue;
            }
            
            if (item.template.level > bestLevel) {
                bestLevel = item.template.level;
                bestItem = item;
            }
        }
        
        return bestItem;
    }

    public boolean shouldEquip(Item current, Item newItem) {
        if (current == null) return true;
        if (newItem == null) return false;
        
        if (newItem.template.level > current.template.level) {
            return true;
        }
        
        if (newItem.template.level == current.template.level) {
            int newOptions = newItem.options != null ? newItem.options.size() : 0;
            int currentOptions = current.options != null ? current.options.size() : 0;
            return newOptions > currentOptions;
        }
        
        return false;
    }

    public void equipItem(Item item, int slot) {
        if (this.itemBody == null) {
            this.itemBody = new Item[15];
        }
        
        if (this.itemBody[slot] != null) {
            Item oldItem = this.itemBody[slot];
            this.addItem(oldItem);
        }
        
        for (int i = 0; i < this.itemBag.length; i++) {
            if (this.itemBag[i] != null && this.itemBag[i].equals(item)) {
                this.removeItem(i, 1);
                break;
            }
        }
        
        this.itemBody[slot] = item;
        
        this.info.setInfo();
        this.updateSkin();
    }

    public void autoAttackBoss() {
        Boss boss = findSuitableBoss();
        if (boss == null) {
            return;
        }
        
        this.currentBoss = boss;
        
        if (boss.zone != this.zone) {
            changeToMap(boss.zone.map.mapID);
            return;
        }
        
        if (this.meCanAttack() && System.currentTimeMillis() - lastAttack >= ATTACK_COOLDOWN) {
            this.zone.attackPlayer(this, boss);
            lastAttack = System.currentTimeMillis();
        }
    }

    public Boss findSuitableBoss() {
        if (this.zone != null) {
            for (Player player : this.zone.players) {
                if (player instanceof Boss && player != this) {
                    Boss boss = (Boss) player;
                    if (isBossSuitable(boss)) {
                        return boss;
                    }
                }
            }
        }
        
        List<Boss> allBosses = Boss.listBoss;
        for (Boss boss : allBosses) {
            if (boss == null || boss.zone == null) continue;
            if (isBossSuitable(boss)) {
                return boss;
            }
        }
        
        return null;
    }

    public boolean isBossSuitable(Boss boss) {
        if (boss == null || boss.zone == null) return false;
        if (!boss.isShow) return false;
        
        long bossSM = boss.info.power;
        long playerSM = this.currentSM;
        
        return bossSM <= (long)(playerSM * BOSS_SM_MULTIPLIER);
    }

    @Override
    public void initSkill() {
        try {
            skills = new ArrayList<>();
            Skill skill = Skills.getSkill(
                (byte)(gender == 0 ? 0 : gender == 1 ? 9 : 17), 
                (byte)7
            );
            if (skill != null) {
                skills.add(skill.clone());
            }
        } catch (CloneNotSupportedException ex) {
            logger.error("Failed to init skill", ex);
        }
    }

    @Override
    public boolean isBoss() {
        return false;
    }

    @Override
    public boolean isHuman() {
        return true;
    }

    @Override
    public void sendNotificationWhenAppear(String map) {
    }

    @Override
    public void sendNotificationWhenDead(String name) {
    }

    @Override
    public void setDefaultLeg() {
    }

    @Override
    public void setDefaultBody() {
    }

    @Override
    public void setDefaultHead() {
    }

    @Override
    public void close() {
        TotalBotTrain--;
        super.close();
    }
}
