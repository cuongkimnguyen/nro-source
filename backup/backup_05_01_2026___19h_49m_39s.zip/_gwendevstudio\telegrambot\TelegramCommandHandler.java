package _gwendevstudio.telegrambot;

import com.ngocrong.server.Config;
import com.ngocrong.server.SessionManager;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TelegramCommandHandler {
    
    private static final Logger logger = Logger.getLogger(TelegramCommandHandler.class);
    
    public static void handleCommand(String command, String chatId, String username) {
        try {
            logger.info("Handling command: " + command + " from chat: " + chatId + " user: " + username);
            String response = "";
            
            switch (command.toLowerCase()) {
                case "/start":
                case "/help":
                    response = getHelpMessage();
                    break;
                    
                case "/ccu":
                case "/status":
                    response = getCCUStatus();
                    break;
                    
                case "/server":
                    response = getServerInfo();
                    break;
                    
                case "/players":
                    response = getPlayersInfo();
                    break;
                    
                default:
                    response = "Lệnh không hợp lệ. Gõ /help để xem danh sách lệnh.";
                    break;
            }
            
            if (response != null && !response.isEmpty()) {
                boolean sent = TelegramBotService.sendMessage(chatId, response);
                if (sent) {
                    logger.info("Successfully sent response for command: " + command + " to chat: " + chatId);
                } else {
                    logger.error("Failed to send response for command: " + command + " to chat: " + chatId);
                }
            } else {
                logger.warn("Empty response for command: " + command);
            }
        } catch (Exception e) {
            logger.error("Error handling command: " + command, e);
            TelegramBotService.sendMessage(chatId, "Đã xảy ra lỗi khi xử lý lệnh: " + e.getMessage());
        }
    }
    
    private static String getHelpMessage() {
        StringBuilder sb = new StringBuilder();
        sb.append("🤖 Bot Quản Lý Server SSNR\n\n");
        sb.append("📋 Danh sách lệnh:\n");
        sb.append("/start - Bắt đầu sử dụng bot\n");
        sb.append("/help - Hiển thị trợ giúp\n");
        sb.append("/ccu - Kiểm tra số lượng người chơi\n");
        sb.append("/status - Trạng thái server\n");
        sb.append("/server - Thông tin server\n");
        sb.append("/players - Danh sách người chơi online\n");
        return sb.toString();
    }
    
    private static String getCCUStatus() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String formattedTime = LocalDateTime.now().format(formatter);
        
        int totalSessions = SessionManager.sessions.size();
        long totalPlayers = SessionManager.getCountPlayer();
        
        StringBuilder sb = new StringBuilder();
        sb.append("📊 THỐNG KÊ CCU\n");
        sb.append("━━━━━━━━━━━━━━━━━━\n");
        sb.append("⏰ Thời gian: ").append(formattedTime).append("\n");
        sb.append("🖥️ Server ID: ").append(Config.serverID()).append("\n");
        sb.append("📡 Tổng Session: ").append(totalSessions).append("\n");
        sb.append("👥 Player Online: ").append(totalPlayers).append("\n");
        sb.append("━━━━━━━━━━━━━━━━━━");
        
        return sb.toString();
    }
    
    private static String getServerInfo() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String formattedTime = LocalDateTime.now().format(formatter);
        
        StringBuilder sb = new StringBuilder();
        sb.append("🖥️ THÔNG TIN SERVER\n");
        sb.append("━━━━━━━━━━━━━━━━━━\n");
        sb.append("⏰ Thời gian: ").append(formattedTime).append("\n");
        sb.append("🆔 Server ID: ").append(Config.serverID()).append("\n");
        sb.append("📡 Tổng Session: ").append(SessionManager.sessions.size()).append("\n");
        sb.append("👥 Player Online: ").append(SessionManager.getCountPlayer()).append("\n");
        sb.append("━━━━━━━━━━━━━━━━━━");
        
        return sb.toString();
    }
    
    private static String getPlayersInfo() {
        long totalPlayers = SessionManager.getCountPlayer();
        int totalSessions = SessionManager.sessions.size();
        
        StringBuilder sb = new StringBuilder();
        sb.append("👥 THÔNG TIN NGƯỜI CHƠI\n");
        sb.append("━━━━━━━━━━━━━━━━━━\n");
        sb.append("📡 Tổng Session: ").append(totalSessions).append("\n");
        sb.append("👤 Player Online: ").append(totalPlayers).append("\n");
        sb.append("━━━━━━━━━━━━━━━━━━");
        
        return sb.toString();
    }
    
    public static void processUpdate(String jsonResponse) {
        try {
            JSONObject json = new JSONObject(jsonResponse);
            if (!json.getBoolean("ok")) {
                logger.warn("Telegram API returned not ok: " + jsonResponse);
                return;
            }
            
            JSONArray results = json.getJSONArray("result");
            logger.debug("Processing " + results.length() + " updates");
            
            for (int i = 0; i < results.length(); i++) {
                JSONObject update = results.getJSONObject(i);
                
                JSONObject message = null;
                if (update.has("message")) {
                    message = update.getJSONObject("message");
                } else if (update.has("channel_post")) {
                    message = update.getJSONObject("channel_post");
                } else if (update.has("edited_message")) {
                    message = update.getJSONObject("edited_message");
                } else if (update.has("edited_channel_post")) {
                    message = update.getJSONObject("edited_channel_post");
                }
                
                if (message != null && message.has("text")) {
                    String text = message.getString("text");
                    JSONObject chat = message.getJSONObject("chat");
                    String chatId = String.valueOf(chat.getLong("id"));
                    String username = "Unknown";
                    
                    if (chat.has("username")) {
                        username = chat.getString("username");
                    } else if (chat.has("first_name")) {
                        username = chat.getString("first_name");
                    } else if (chat.has("title")) {
                        username = chat.getString("title");
                    }
                    
                    logger.info("Received message: " + text + " from chat: " + chatId + " (" + username + ")");
                    
                    if (text.startsWith("/")) {
                        String command = text.split(" ")[0];
                        logger.info("Processing command: " + command);
                        handleCommand(command, chatId, username);
                    }
                }
            }
        } catch (Exception e) {
            logger.error("Error processing update: " + jsonResponse, e);
        }
    }
}

