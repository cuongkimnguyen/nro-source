package com.ngocrong.NQMP;

import com.ngocrong.bot.VirtualBot_SoSinh;
import com.ngocrong.consts.CMDMenu;
import com.ngocrong.consts.NpcName;
import com.ngocrong.data.BotConfigData;
import com.ngocrong.lib.KeyValue;
import com.ngocrong.map.MapManager;
import com.ngocrong.map.TMap;
import com.ngocrong.map.tzone.Zone;
import com.ngocrong.repository.GameRepository;
import com.ngocrong.user.Player;
import com.ngocrong.util.Utils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class BotMenuHandler {

    public static final int CMD_Menu_Bot = 2100;
    public static BotMenuHandler instance = new BotMenuHandler();

    public static BotMenuHandler gI() {
        return instance;
    }

    public void showMenu(Player player) {
        player.menus.clear();
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo Bot", 1));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa Bot", 2));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa Bot Khu hiện tại", 3));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xem danh sách Bot", 4));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Reset tên Bot đã dùng", 5));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Clear Name Bot", 8));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Thêm tên Bot", 6));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Thêm ID Cải Trang", 7));
        player.service.openUIConfirm(NpcName.CON_MEO, "Quản lý Bot", player.getPetAvatar(), player.menus);
    }

    public void perform(int idAction, Player player, Object... p) {
        switch (idAction) {
            case 1: {
                showCreateBotMenu(player);
                break;
            }
            case 2: {
                showDeleteBotMenu(player);
                break;
            }
            case 3: {
                deleteBotsInCurrentZone(player);
                break;
            }
            case 4: {
                showBotList(player);
                break;
            }
            case 5: {
                resetUsedBotNames(player);
                break;
            }
            case 6: {
                player.service.sendThongBao("Nhập lệnh: addbotname <tên1,tên2,tên3,...> để thêm tên bot");
                break;
            }
            case 7: {
                player.service.sendThongBao("Nhập lệnh: addcaitrang <id1,id2,id3,...> để thêm ID cải trang");
                break;
            }
            case 8: {
                clearUsedBotNames(player);
                break;
            }
            case 10: {
                int quantity = ((Integer) p[0]);
                createBots(player, quantity);
                break;
            }
            case 20: {
                int quantity = ((Integer) p[0]);
                deleteBots(player, quantity);
                break;
            }
        }
    }

    private void showCreateBotMenu(Player player) {
        player.menus.clear();
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo 1 Bot", 10, 1));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo 5 Bot", 10, 5));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo 10 Bot", 10, 10));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo 20 Bot", 10, 20));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo 50 Bot", 10, 50));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Tạo 100 Bot", 10, 100));
        player.service.openUIConfirm(NpcName.CON_MEO, "Chọn số lượng Bot muốn tạo", player.getPetAvatar(), player.menus);
    }

    private void showDeleteBotMenu(Player player) {
        player.menus.clear();
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa 1 Bot", 20, 1));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa 5 Bot", 20, 5));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa 10 Bot", 20, 10));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa 20 Bot", 20, 20));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa 50 Bot", 20, 50));
        player.menus.add(new KeyValue(CMD_Menu_Bot, "Xóa tất cả Bot", 20, -1));
        player.service.openUIConfirm(NpcName.CON_MEO, "Chọn số lượng Bot muốn xóa", player.getPetAvatar(), player.menus);
    }

    public void createBots(Player player, int quantity) {
        int created = 0;

        List<BotConfigData> allConfigs = GameRepository.getInstance().botConfig.findByIsUsedFalse();
        if (allConfigs.isEmpty()) {
            player.service.sendThongBao("Hết tên bot vui lòng thêm tên vào bảng bot_config");
            return;
        }

        for (BotConfigData config : allConfigs) {
            if (config.getBotnameJson() == null || config.getBotnameJson().isEmpty()) {
                continue;
            }
            
            try {
                JSONArray botnameArray = new JSONArray(config.getBotnameJson());
                JSONArray usedNamesArray = new JSONArray();
                if (config.getUsedBotnames() != null && !config.getUsedBotnames().isEmpty()) {
                    usedNamesArray = new JSONArray(config.getUsedBotnames());
                }
                
                List<String> availableNames = new ArrayList<>();
                for (int j = 0; j < botnameArray.length(); j++) {
                    String configBotname = botnameArray.optString(j, "");
                    if (configBotname.isEmpty()) {
                        continue;
                    }
                    
                    boolean alreadyUsed = false;
                    for (int k = 0; k < usedNamesArray.length(); k++) {
                        if (usedNamesArray.optString(k, "").equals(configBotname)) {
                            alreadyUsed = true;
                            break;
                        }
                    }
                    
                    if (!alreadyUsed) {
                        availableNames.add(configBotname);
                    }
                }
                
                if (availableNames.isEmpty()) {
                    continue;
                }
                
                int toCreate = Math.min(quantity - created, availableNames.size());
                for (int i = 0; i < toCreate; i++) {
                    int randomIndex = Utils.nextInt(availableNames.size());
                    String botName = availableNames.remove(randomIndex);
                    
                    usedNamesArray.put(botName);
                    config.setUsedBotnames(usedNamesArray.toString());
                    GameRepository.getInstance().botConfig.save(config);
                    
                    VirtualBot_SoSinh bot = new VirtualBot_SoSinh(botName);
                    bot.setLocation(0, -1);
                    UtilsNQMP.lastCreateBot = System.currentTimeMillis();
                    created++;
                }
                
                if (created >= quantity) {
                    break;
                }
            } catch (Exception e) {
                continue;
            }
        }

        if (created > 0) {
            player.service.sendThongBao("Đã tạo " + created + " Bot");
        }
        if (created < quantity) {
            player.service.sendThongBao("Hết tên bot vui lòng thêm tên vào bảng bot_config hoặc dùng lệnh Clear Name Bot để tái sử dụng");
        }
    }

    private void deleteBots(Player player, int quantity) {
        int deleted = 0;
        List<Player> botsToDelete = new ArrayList<>();

        for (TMap map : MapManager.getInstance().maps.values()) {
            if (map == null || map.zones == null) {
                continue;
            }
            for (Zone zone : map.zones) {
                if (zone == null || zone.players == null) {
                    continue;
                }
                synchronized (zone.players) {
                    for (Player p : zone.players) {
                        if (p != null && p instanceof VirtualBot_SoSinh && !p.equals(player)) {
                            botsToDelete.add(p);
                            if (quantity > 0 && botsToDelete.size() >= quantity) {
                                break;
                            }
                        }
                    }
                }
                if (quantity > 0 && botsToDelete.size() >= quantity) {
                    break;
                }
            }
            if (quantity > 0 && botsToDelete.size() >= quantity) {
                break;
            }
        }

        for (Player bot : botsToDelete) {
            if (bot.zone != null) {
                bot.zone.leave(bot);
                bot.close();
                deleted++;
            }
        }

        player.service.sendThongBao("Đã xóa " + deleted + " Bot");
    }

    private void deleteBotsInCurrentZone(Player player) {
        if (player.zone == null) {
            return;
        }

        int deleted = 0;
        List<Player> botsToDelete = new ArrayList<>();

        synchronized (player.zone.players) {
            for (Player p : player.zone.players) {
                if (p != null && p instanceof VirtualBot_SoSinh && !p.equals(player)) {
                    botsToDelete.add(p);
                }
            }
        }

        for (Player bot : botsToDelete) {
            player.zone.leave(bot);
            bot.close();
            deleted++;
        }

        player.service.sendThongBao("Đã xóa " + deleted + " Bot trong khu hiện tại");
    }

    private void showBotList(Player player) {
        int totalBots = 0;
        StringBuilder botList = new StringBuilder("Danh sách Bot:\n");

        for (TMap map : MapManager.getInstance().maps.values()) {
            if (map == null || map.zones == null) {
                continue;
            }
            for (Zone zone : map.zones) {
                if (zone == null || zone.players == null) {
                    continue;
                }
                synchronized (zone.players) {
                    for (Player p : zone.players) {
                        if (p != null && p instanceof VirtualBot_SoSinh) {
                            totalBots++;
                            if (totalBots <= 20) {
                                botList.append("- ").append(p.name).append(" (Map: ").append(zone.map.mapID).append(")\n");
                            }
                        }
                    }
                }
            }
        }

        if (totalBots > 20) {
            botList.append("... và ").append(totalBots - 20).append(" Bot khác");
        }

        botList.append("\nTổng: ").append(totalBots).append(" Bot");

        player.service.sendThongBao(botList.toString());
    }

    private void resetUsedBotNames(Player player) {
        try {
            List<BotConfigData> allConfigs = GameRepository.getInstance().botConfig.findAll();
            int resetCount = 0;

            for (BotConfigData config : allConfigs) {
                if (config.getIsUsed() != null && config.getIsUsed()) {
                    config.setIsUsed(false);
                    GameRepository.getInstance().botConfig.save(config);
                    resetCount++;
                }
            }

            player.service.sendThongBao("Đã reset " + resetCount + " config Bot");
        } catch (Exception e) {
            player.service.sendThongBao("Lỗi khi reset config Bot");
        }
    }

    public void addBotNames(Player player, String namesStr) {
        try {
            if (namesStr == null || namesStr.trim().isEmpty()) {
                player.service.sendThongBao("Vui lòng nhập tên bot, cách nhau bởi dấu phẩy");
                return;
            }

            if (GameRepository.getInstance().botConfig == null) {
                player.service.sendThongBao("Lỗi: BotConfig repository chưa được khởi tạo");
                return;
            }

            String[] names = namesStr.split(",");
            List<BotConfigData> allConfigs = GameRepository.getInstance().botConfig.findByIsUsedFalse();
            
            BotConfigData config;
            if (allConfigs.isEmpty()) {
                config = new BotConfigData();
                config.setBotnameJson("[]");
                config.setCaitrangIdJson("[]");
                config.setRatioCaitrang(30);
                config.setRatioTrangbi(70);
                config.setIsUsed(false);
                config.setUsedBotnames("[]");
                config = GameRepository.getInstance().botConfig.save(config);
            } else {
                config = allConfigs.get(0);
            }

            JSONArray botnameArray = new JSONArray();
            
            if (config.getBotnameJson() != null && !config.getBotnameJson().isEmpty()) {
                botnameArray = new JSONArray(config.getBotnameJson());
            }

            int added = 0;
            for (String name : names) {
                name = name.trim();
                if (!name.isEmpty()) {
                    boolean exists = false;
                    for (int i = 0; i < botnameArray.length(); i++) {
                        if (botnameArray.getString(i).equals(name)) {
                            exists = true;
                            break;
                        }
                    }
                    if (!exists) {
                        botnameArray.put(name);
                        added++;
                    }
                }
            }

            config.setBotnameJson(botnameArray.toString());
            GameRepository.getInstance().botConfig.save(config);

            player.service.sendThongBao("Đã thêm " + added + " tên bot vào config");
        } catch (Exception e) {
            player.service.sendThongBao("Lỗi khi thêm tên bot: " + e.getMessage());
        }
    }

    public void addCaiTrangIds(Player player, String idsStr) {
        try {
            if (idsStr == null || idsStr.trim().isEmpty()) {
                player.service.sendThongBao("Vui lòng nhập ID cải trang, cách nhau bởi dấu phẩy");
                return;
            }

            if (GameRepository.getInstance().botConfig == null) {
                player.service.sendThongBao("Lỗi: BotConfig repository chưa được khởi tạo");
                return;
            }

            String[] ids = idsStr.split(",");
            List<BotConfigData> allConfigs = GameRepository.getInstance().botConfig.findByIsUsedFalse();
            
            BotConfigData config;
            if (allConfigs.isEmpty()) {
                config = new BotConfigData();
                config.setBotnameJson("[]");
                config.setCaitrangIdJson("[]");
                config.setRatioCaitrang(30);
                config.setRatioTrangbi(70);
                config.setIsUsed(false);
                config.setUsedBotnames("[]");
                config = GameRepository.getInstance().botConfig.save(config);
            } else {
                config = allConfigs.get(0);
            }
            JSONArray caitrangArray = new JSONArray();
            
            if (config.getCaitrangIdJson() != null && !config.getCaitrangIdJson().isEmpty()) {
                caitrangArray = new JSONArray(config.getCaitrangIdJson());
            }

            int added = 0;
            for (String idStr : ids) {
                idStr = idStr.trim();
                if (!idStr.isEmpty()) {
                    try {
                        int id = Integer.parseInt(idStr);
                        boolean exists = false;
                        for (int i = 0; i < caitrangArray.length(); i++) {
                            if (caitrangArray.getInt(i) == id) {
                                exists = true;
                                break;
                            }
                        }
                        if (!exists) {
                            caitrangArray.put(id);
                            added++;
                        }
                    } catch (NumberFormatException e) {
                        continue;
                    }
                }
            }

            config.setCaitrangIdJson(caitrangArray.toString());
            GameRepository.getInstance().botConfig.save(config);

            player.service.sendThongBao("Đã thêm " + added + " ID cải trang vào config");
        } catch (Exception e) {
            player.service.sendThongBao("Lỗi khi thêm ID cải trang: " + e.getMessage());
        }
    }

    private void clearUsedBotNames(Player player) {
        try {
            List<BotConfigData> allConfigs = GameRepository.getInstance().botConfig.findAll();
            int resetCount = 0;

            for (BotConfigData config : allConfigs) {
                if (config.getUsedBotnames() != null && !config.getUsedBotnames().isEmpty()) {
                    config.setUsedBotnames("[]");
                    GameRepository.getInstance().botConfig.save(config);
                    resetCount++;
                }
            }

            player.service.sendThongBao("Đã xóa tất cả tên bot đã dùng, có thể tái sử dụng");
        } catch (Exception e) {
            player.service.sendThongBao("Lỗi khi xóa danh sách tên bot đã dùng");
        }
    }

    public void setRatioCaitrang(Player player, int ratio) {
        try {
            List<BotConfigData> allConfigs = GameRepository.getInstance().botConfig.findByIsUsedFalse();
            
            BotConfigData config;
            if (allConfigs.isEmpty()) {
                config = new BotConfigData();
                config.setBotnameJson("[]");
                config.setCaitrangIdJson("[]");
                config.setRatioCaitrang(ratio);
                config.setRatioTrangbi(70);
                config.setIsUsed(false);
                config.setUsedBotnames("[]");
                config = GameRepository.getInstance().botConfig.save(config);
            } else {
                config = allConfigs.get(0);
                config.setRatioCaitrang(ratio);
                GameRepository.getInstance().botConfig.save(config);
            }

            player.service.sendThongBao("Đã set tỉ lệ cải trang: " + ratio);
        } catch (Exception e) {
            player.service.sendThongBao("Lỗi khi set tỉ lệ cải trang: " + e.getMessage());
        }
    }

    public void setRatioTrangbi(Player player, int ratio) {
        try {
            List<BotConfigData> allConfigs = GameRepository.getInstance().botConfig.findByIsUsedFalse();
            
            BotConfigData config;
            if (allConfigs.isEmpty()) {
                config = new BotConfigData();
                config.setBotnameJson("[]");
                config.setCaitrangIdJson("[]");
                config.setRatioCaitrang(30);
                config.setRatioTrangbi(ratio);
                config.setIsUsed(false);
                config.setUsedBotnames("[]");
                config = GameRepository.getInstance().botConfig.save(config);
            } else {
                config = allConfigs.get(0);
                config.setRatioTrangbi(ratio);
                GameRepository.getInstance().botConfig.save(config);
            }

            player.service.sendThongBao("Đã set tỉ lệ trang bị: " + ratio);
        } catch (Exception e) {
            player.service.sendThongBao("Lỗi khi set tỉ lệ trang bị: " + e.getMessage());
        }
    }
}
