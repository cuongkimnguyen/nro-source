package _gwendevstudio.telegrambot;

import org.apache.log4j.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

public class TelegramCommandRegistry {
    
    private static final Logger logger = Logger.getLogger(TelegramCommandRegistry.class);
    private static final Map<String, Function<String[], String>> commands = new HashMap<>();
    
    static {
        registerCommand("/ccu", TelegramCommandHandler::handleCCU);
        registerCommand("/baotri", TelegramCommandHandler::handleBaoTri);
        registerCommand("/money", TelegramCommandHandler::handleMoney);
    }
    
    public static void registerCommand(String command, Function<String[], String> handler) {
        commands.put(command.toLowerCase(), handler);
        logger.debug("Registered command: " + command);
    }
    
    public static String executeCommand(String command, String[] args) {
        String commandKey = command.toLowerCase();
        Function<String[], String> handler = commands.get(commandKey);
        
        if (handler != null) {
            logger.info("Executing command: " + command + " with args: " + java.util.Arrays.toString(args));
            return handler.apply(args);
        }
        
        logger.debug("Command not found: " + command);
        return null;
    }
    
    public static boolean hasCommand(String command) {
        return commands.containsKey(command.toLowerCase());
    }
}

