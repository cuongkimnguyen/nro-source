/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ngocrong.combine;

import com.ngocrong.consts.CMDMenu;
import com.ngocrong.item.Item;
import com.ngocrong.item.ItemOption;
import com.ngocrong.item.ItemTemplate;
import com.ngocrong.lib.KeyValue;
import com.ngocrong.server.DragonBall;
import com.ngocrong.util.Utils;

/**
 *
 * @author Administrator
 */
public class DoiDoKichHoat extends Combine {

    public static int[] SKHTD = new int[]{40, 40, 20}; // Tỉ lệ % cho gender 0 (Trái Đất)
    public static int[] SKHNM = new int[]{20, 20, 60}; // Tỉ lệ % cho gender 1 (Namec)
    public static int[] SKHXD = new int[]{20, 60, 20}; // Tỉ lệ % cho gender 2 (Xayda)
    static final int goldRequire = 500_000_000;
    
    // Tỉ lệ level (level càng cao càng hiếm) - tổng = 1010 (tương đương 100%)
    private static final int[] LEVEL_WEIGHTS = {
        150, // Level 1: 15%
        150, // Level 2: 15%
        150, // Level 3: 15%
        120, // Level 4: 12%
        120, // Level 5: 12%
        100, // Level 6: 10%
        80,  // Level 7: 8%
        60,  // Level 8: 6%
        40,  // Level 9: 4%
        20,  // Level 10: 2%
        5,   // Level 11: 0.5%
        5    // Level 12: 0.5%
    };
    
    private static final int MIN_LEVEL = 1;
    private static final int MAX_LEVEL = 12;
    private static final int MIN_TYPE = 0;
    private static final int MAX_TYPE = 4;

    /**
     * Set tỉ lệ % cho SKH Trái Đất
     *
     * @param txh tỉ lệ % cho TXH (index 0)
     * @param krilin tỉ lệ % cho Krilin (index 1)
     * @param sgk tỉ lệ % cho SGK (index 2)
     * @return true nếu set thành công, false nếu tổng không bằng 100
     */
    public static boolean setSKHTD(int txh, int krilin, int sgk) {
        if (txh + krilin + sgk != 100) {
            return false;
        }
        if (txh < 0 || krilin < 0 || sgk < 0) {
            return false;
        }
        SKHTD[0] = txh;
        SKHTD[1] = krilin;
        SKHTD[2] = sgk;
        return true;
    }

    /**
     * Set tỉ lệ % cho SKH Namec
     *
     * @param pcl tỉ lệ % cho PCL (index 0)
     * @param octiu tỉ lệ % cho Octiu (index 1)
     * @param daimao tỉ lệ % cho Daimao (index 2)
     * @return true nếu set thành công, false nếu tổng không bằng 100
     */
    public static boolean setSKHNM(int pcl, int octiu, int daimao) {
        if (pcl + octiu + daimao != 100) {
            return false;
        }
        if (pcl < 0 || octiu < 0 || daimao < 0) {
            return false;
        }
        SKHNM[0] = pcl;
        SKHNM[1] = octiu;
        SKHNM[2] = daimao;
        return true;
    }

    /**
     * Set tỉ lệ % cho SKH Xayda
     *
     * @param kkr tỉ lệ % cho KKR (index 0)
     * @param cadic tỉ lệ % cho Cadic (index 1)
     * @param nappa tỉ lệ % cho Nappa (index 2)
     * @return true nếu set thành công, false nếu tổng không bằng 100
     */
    public static boolean setSKHXD(int kkr, int cadic, int nappa) {
        if (kkr + cadic + nappa != 100) {
            return false;
        }
        if (kkr < 0 || cadic < 0 || nappa < 0) {
            return false;
        }
        SKHXD[0] = kkr;
        SKHXD[1] = cadic;
        SKHXD[2] = nappa;
        return true;
    }

    public DoiDoKichHoat() {
        StringBuilder sb = new StringBuilder();
        sb.append("Vào hành trang").append("\n");
        sb.append("Chọn 1 món đồ Hủy Diệt").append("\n");
        sb.append("Sau đó chọn 'Nâng Cấp'");
        setInfo(sb.toString());

        StringBuilder sb2 = new StringBuilder();
        sb2.append("Ta sẽ phù phép").append("\n");
        sb2.append("Biến đồ Hủy Diệt thành Đồ Kích hoạt").append("\n");
        sb2.append("Ngẫu nhiên Áo Quần Găng Giày Rada").append("\n");
        sb2.append("Từ Level 1 - 12");
        setInfo2(sb2.toString());
    }
    public int type;

    @Override
    public void confirm() {
        if (itemCombine == null) {
            return;
        }
        if (itemCombine.size() != 1) {
            player.service.dialogMessage("Số lượng trang bị không hợp lệ");
            return;
        }
        Item item = player.itemBag[itemCombine.get(0)];
        if (item == null || item.template.type >= 5 || item.template.level != 14) {
            player.service.dialogMessage("Vật phẩm không hợp lệ");
            return;
        }
        String info = "Sau khi nâng cấp, sẽ nhận được 1 trang bị Kích Hoạt ngẫu nhiên (sẽ ngẫu nhiên Áo Quần Găng Giày Rada Từ Level 1 - 12, cần 500tr vàng)";
        player.menus.clear();
        player.menus.add(new KeyValue(CMDMenu.COMBINE, "Đồng ý\n500tr vàng", -1));
        player.menus.add(new KeyValue(CMDMenu.CANCEL, "Từ chối"));
        player.service.openUIConfirm(npc.templateId, info, npc.avatar, player.menus);
    }

    /**
     * Random level từ 1-12 theo tỉ lệ (level càng cao càng hiếm)
     * @return level từ 1-12
     */
    private int getRandomLevel() {
        int totalWeight = 0;
        for (int weight : LEVEL_WEIGHTS) {
            totalWeight += weight;
        }
        
        int randomValue = Utils.nextInt(totalWeight);
        int currentSum = 0;
        
        for (int i = 0; i < LEVEL_WEIGHTS.length; i++) {
            currentSum += LEVEL_WEIGHTS[i];
            if (randomValue < currentSum) {
                return i + MIN_LEVEL; // i từ 0-11, level từ 1-12
            }
        }
        
        return MIN_LEVEL; // Fallback
    }
    
    /**
     * Random type từ 0-4 (Áo/Quần/Găng/Giày/Rada)
     * @return type từ 0-4
     */
    private int getRandomType() {
        return Utils.nextInt(MAX_TYPE - MIN_TYPE + 1) + MIN_TYPE;
    }
    
    /**
     * Tìm ItemTemplate ID ngẫu nhiên theo type, gender, level
     * @param type Loại trang bị (0-4)
     * @param gender Giới tính (0-2, hoặc 3 cho Rada)
     * @param level Level (1-12)
     * @return ItemTemplate ID, hoặc -1 nếu không tìm thấy
     */
    private int getRandomItemTemplateId(int type, int gender, int level) {
        com.ngocrong.server.Server server = DragonBall.getInstance().getServer();
        if (server == null || server.iTemplates == null) {
            return -1;
        }
        
        java.util.ArrayList<Integer> matchingIds = new java.util.ArrayList<>();
        
        for (ItemTemplate template : server.iTemplates.values()) {
            // Bỏ qua một số item đặc biệt
            if (template.id == 693 || template.id == 691 || template.id == 692) {
                continue;
            }
            
            // Kiểm tra điều kiện
            if (template.type == type && template.level == level) {
                // Kiểm tra gender: type 4 (Rada) có thể có gender 3, các type khác phải match gender
                if (type == 4) {
                    if (template.gender == 3 || template.gender == gender) {
                        matchingIds.add((int) template.id);
                    }
                } else {
                    if (template.gender == gender) {
                        matchingIds.add((int) template.id);
                    }
                }
            }
        }
        
        if (matchingIds.isEmpty()) {
            return -1;
        }
        
        // Random một ID từ danh sách
        int randomIndex = Utils.nextInt(matchingIds.size());
        return matchingIds.get(randomIndex);
    }

    public static final int[][][] OPTIONS = {
        {
            {127, 139}, // txh
            {128, 140}, // krilin
            {129, 141} // sgk
        }, {
            {130, 142}, //pcl
            {131, 143}, // octiu
            {132, 144} //daimao
        }, {
            {133, 136}, // kkr
            {134, 137}, // cadic
            {135, 138} // nappa
        }
    };

    /**
     * Chọn index dựa trên tỉ lệ % từ các mảng SKHTD, SKHNM, SKHXD
     *
     * @param gender giới tính của trang bị (0: Trái Đất, 1: Namec, 2: Xayda)
     * @return index được chọn (0, 1, hoặc 2)
     */
    private int getRandomIndexByPercentage(int gender) {
        int[] percentages;
        switch (gender) {
            case 0:
                percentages = SKHTD;
                break;
            case 1:
                percentages = SKHNM;
                break;
            case 2:
                percentages = SKHXD;
                break;
            default:
                percentages = SKHTD; // Default fallback
                break;
        }

        // Tính tổng tỉ lệ
        int totalPercentage = 0;
        for (int percentage : percentages) {
            totalPercentage += percentage;
        }

        // Random một số từ 0 đến totalPercentage - 1
        int randomValue = Utils.nextInt(totalPercentage);

        // Tìm index tương ứng với giá trị random
        int currentSum = 0;
        for (int i = 0; i < percentages.length; i++) {
            currentSum += percentages[i];
            if (randomValue < currentSum) {
                return i;
            }
        }

        // Fallback (không bao giờ xảy ra nếu logic đúng)
        return 0;
    }

    @Override
    public void combine() {
        if (itemCombine == null) {
            return;
        }
        if (itemCombine.size() != 1) {
            player.service.dialogMessage("Số lượng trang bị không hợp lệ");
            return;
        }
        Item oldItem = player.itemBag[itemCombine.get(0)];
        if (oldItem == null || oldItem.template.type >= 5 || oldItem.template.level != 14) {
            player.service.dialogMessage("Vật phẩm không hợp lệ");
            return;
        }
        if (player.gold < 500000000) {
            player.service.sendThongBao("Bạn không đủ vàng");
            return;
        }
        
        // Lưu gender của trang bị ban đầu (giữ nguyên giới tính)
        int gender = oldItem.template.gender;
        if (oldItem.template.type == 4) {
            // Rada có thể có gender 3, nếu vậy thì random gender 0-2
            if (gender == 3) {
                gender = Utils.nextInt(3); // 0, 1, hoặc 2
            }
        }
        
        // Random type (0-4) và level (1-12)
        int randomType = getRandomType();
        int randomLevel = getRandomLevel();
        
        // Tìm ItemTemplate ID phù hợp
        int templateId = getRandomItemTemplateId(randomType, gender, randomLevel);
        
        if (templateId == -1) {
            player.service.dialogMessage("Không tìm thấy trang bị phù hợp. Vui lòng thử lại.");
            return;
        }
        
        // Trừ vàng
        player.addGold(-500000000);
        short oldIcon = oldItem.template.iconID;
        result((byte) 2, oldIcon, oldItem.template.iconID);
        
        // Tạo item mới
        Item newItem = new Item(templateId);
        newItem.quantity = 1;
        newItem.setDefaultOptions();

        // Gán 2 chỉ số SKH ngẫu nhiên theo gender
        int index = getRandomIndexByPercentage(gender);
        newItem.addItemOption(new ItemOption(OPTIONS[gender][index][0], 0));
        newItem.addItemOption(new ItemOption(OPTIONS[gender][index][1], 0));
        newItem.addItemOption(new ItemOption(30, 0));
        
        newItem.indexUI = itemCombine.get(0);
        player.itemBag[newItem.indexUI] = newItem;
        player.service.refreshItem((byte) 1, newItem);
        update();
    }

    @Override
    public void showTab() {
        player.service.combine((byte) 0, this, (short) -1, (short) -1);
    }
}
