package _gwendevstudio;

/**
 *
 * @author GwenDevStudio
 */
public class ConfigStudio {

    public static final String SLOGAN = "Chào mừng bạn đến với Hồi Ức Ngọc Rông";
    public static final String ABBREVIATION = "HUNR";
    public static final String SLOGAN_BOTCOLD = "HUNR";
    public static final String SLOGAN_BOTSOSINH = "HUNR";
    public static final String SLOGAN_BOTTRAIN = "HUNR";
    public static final String MESSAGE_LOGIN2 = "Đăng ký tài khoản tại Hồi Ức Ngọc Rồng (hoiucngocrong.com)";
    public static final String MESSAGE_INPUT_CARD = "Bạn hãy truy cập trang: HOIUCNGOCRONG.COM để nạp tiền!";
    public static final String SERVER_VERSION = "0.0.7";
    public static final String WEBSITE_URL = "HOIUCNGOCRONG.COM";

    // ====================================== MODE ADMIN
    public static final boolean MODE_ADMIN = false;
    public static final String MESSAGE_MODE_ADMIN = "Hiện tại chỉ có Admin mới vào được game, vui lòng đợi";

    // ====================================== MODE COMING SOON
    public static final boolean MODE_COMINGSOON = false;
    public static final int COMINGSOON_YEAR = 2025;
    public static final int COMINGSOON_MONTH = 8;
    public static final int COMINGSOON_DAY = 31;
    public static final int COMINGSOON_HOUR = 17;
    public static final int COMINGSOON_MINUTE = 30;
    public static final String MESSAGE_COMINGSOON = "Bạn sẽ có thể online game vào lúc 17h30 31/08/2025";

}
