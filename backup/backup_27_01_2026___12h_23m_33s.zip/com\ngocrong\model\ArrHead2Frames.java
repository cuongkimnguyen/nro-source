package com.ngocrong.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * ArrHead2Frames - Dùng để tạo animation cho head gốc bằng cách sử dụng nhiều part head
 * Format trong database: [id_ct, id_head1, id_head2, ...]
 * - id_ct: ID của cải trang trong nr_item
 * - id_head1, id_head2, ...: Các ID head (type 0) trong nr_part
 */
public class ArrHead2Frames {
    
    public int itemId; // ID của cải trang trong nr_item (id_ct)
    public List<Integer> headIds; // Danh sách ID head (type 0) trong nr_part
    
    public ArrHead2Frames() {
        this.headIds = new ArrayList<>();
    }
    
    public ArrHead2Frames(int itemId, List<Integer> headIds) {
        this.itemId = itemId;
        this.headIds = headIds != null ? headIds : new ArrayList<>();
    }
    
    /**
     * Get part data từ các head IDs
     * @param parts Map chứa các Part theo ID
     * @return Danh sách Part tương ứng với các head IDs
     */
    public List<Part> getPartData(HashMap<Integer, Part> parts) {
        List<Part> result = new ArrayList<>();
        if (parts == null || headIds == null) {
            return result;
        }
        for (int headId : headIds) {
            Part part = parts.get(headId);
            if (part != null && part.type == 0) { // Chỉ lấy type 0 (head)
                result.add(part);
            }
        }
        return result;
    }
}
