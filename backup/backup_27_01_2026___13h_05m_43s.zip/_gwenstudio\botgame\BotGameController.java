package _gwenstudio.botgame;

import com.ngocrong.user.Player;
import org.apache.log4j.Logger;

/**
 * Controller xử lý lệnh từ player để tạo bot
 */
public class BotGameController {

    private static final Logger logger = Logger.getLogger(BotGameController.class);
    private static BotGameController instance = new BotGameController();
    private BotGameService botGameService;

    public BotGameController() {
        this.botGameService = BotGameService.getInstance();
    }

    public static BotGameController getInstance() {
        return instance;
    }

    /**
     * Xử lý lệnh chat "botgame + số lượng"
     * @param player - Player gửi lệnh
     * @param quantity - Số lượng bot muốn tạo
     */
    public void handleCreateBotCommand(Player player, int quantity) {
        if (player.zone == null) {
            player.service.sendThongBao("Bạn phải ở trong một zone để tạo bot");
            return;
        }

        if (quantity <= 0) {
            player.service.sendThongBao("Số lượng bot phải lớn hơn 0");
            return;
        }

        if (quantity > 100) {
            player.service.sendThongBao("Số lượng bot không được vượt quá 100");
            return;
        }

        int levelMin = 1;
        int levelMax = 200;
        long powerMin = 10000L;
        long powerMax = 1000000L;

        int created = botGameService.createBots(quantity, levelMin, levelMax, powerMin, powerMax, player.zone);

        if (created > 0) {
            player.service.sendThongBao("Đã tạo " + created + "/" + quantity + " bot đánh quái");
            logger.debug(String.format("[BotGameController] Player %s tạo %d bot", player.name, created));
        } else {
            player.service.sendThongBao("Không thể tạo bot. Vui lòng thử lại");
        }
    }
}
