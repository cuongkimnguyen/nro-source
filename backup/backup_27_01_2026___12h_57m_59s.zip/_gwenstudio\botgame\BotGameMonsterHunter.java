package _gwenstudio.botgame;

import com.ngocrong.map.tzone.Zone;
import com.ngocrong.network.Service;
import com.ngocrong.user.Player;
import com.ngocrong.util.Utils;
import org.apache.log4j.Logger;

/**
 * Bot đánh quái - Bot là người thật nhưng tự động đánh quái
 * Không phải Boss, là Player thật
 */
public class BotGameMonsterHunter extends Player {

    private static final Logger logger = Logger.getLogger(BotGameMonsterHunter.class);
    
    private BotGameCombat combat;
    private BotGameMovement movement;
    private BotGameTargeting targeting;
    
    private int botLevel;
    private long botPower;

    public BotGameMonsterHunter(String name, int level, long power, Zone zone) {
        super();
        this.name = name;
        this.id = Utils.nextInt(1000000, 9999999);
        this.botLevel = level;
        this.botPower = power;
        
        logger.debug(String.format("[BotGame] Tạo bot mới - Name: %s, ID: %d, Level: %d, Power: %d", 
            name, this.id, level, power));
        
        initializeBot(zone);
    }

    private void initializeBot(Zone zone) {
        try {
            this.itemBag = new com.ngocrong.item.Item[100];
            this.gender = (byte) Utils.nextInt(3);
            
            long hp = botPower * 10L;
            long mp = Long.MAX_VALUE;
            long dame = botPower / 10L;
            
            this.info.originalHP = hp;
            this.info.originalMP = mp;
            this.info.originalDamage = dame;
            this.info.originalDefense = 100;
            this.info.originalCritical = 5;
            this.info.power = botPower;
            this.info.level = botLevel;
            this.info.setInfo();
            this.info.recovery(com.ngocrong.user.Info.ALL, 100, false);
            
            logger.debug(String.format("[BotGame] Khởi tạo bot - HP: %d, MP: %d, Damage: %d", 
                hp, mp, dame));
            
            setRandomAppearance();
            initSkill();
            
            if (zone != null) {
                this.setX((short) Utils.nextInt(50, zone.map.width - 50));
                this.setY((short) zone.map.collisionLand(this.getX(), (short) 0));
                this.service = new Service(this);
                zone.enter(this);
                
                this.combat = new BotGameCombat(this);
                this.movement = new BotGameMovement(this);
                this.targeting = new BotGameTargeting(this);
                
                logger.debug(String.format("[BotGame] Bot spawn vào Map: %d, Zone: %d, X: %d, Y: %d", 
                    zone.map.mapID, zone.zoneID, this.getX(), this.getY()));
            }
        } catch (Exception e) {
            logger.error("[BotGame] Lỗi khởi tạo bot: " + e.getMessage(), e);
        }
    }

    private void setRandomAppearance() {
        try {
            short[][] hair = new short[][]{
                {64, 30, 31}, {9, 29, 32}, {6, 27, 28}
            };
            short head = hair[this.gender][Utils.nextInt(hair[this.gender].length)];
            short body = (short) (this.gender == 0 ? 14 : this.gender == 1 ? 10 : 16);
            short leg = (short) (this.gender == 0 ? 15 : this.gender == 1 ? 11 : 17);
            
            java.lang.reflect.Method setHeadMethod = Player.class.getDeclaredMethod("setHead", short.class);
            setHeadMethod.setAccessible(true);
            setHeadMethod.invoke(this, head);
            
            java.lang.reflect.Field headField = Player.class.getDeclaredField("head");
            java.lang.reflect.Field bodyField = Player.class.getDeclaredField("body");
            java.lang.reflect.Field legField = Player.class.getDeclaredField("leg");
            java.lang.reflect.Field headDefaultField = Player.class.getDeclaredField("headDefault");
            
            headField.setAccessible(true);
            bodyField.setAccessible(true);
            legField.setAccessible(true);
            headDefaultField.setAccessible(true);
            
            headField.setShort(this, head);
            bodyField.setShort(this, body);
            legField.setShort(this, leg);
            headDefaultField.setShort(this, head);
            
            logger.debug(String.format("[BotGame] Set appearance - Gender: %d, Head: %d, Body: %d, Leg: %d", 
                this.gender, head, body, leg));
        } catch (Exception e) {
            logger.error("[BotGame] Lỗi set appearance: " + e.getMessage(), e);
        }
    }

    @Override
    public void update() {
        if (this.zone == null) {
            return;
        }
        
        this.info.mp = this.info.mpFull = Long.MAX_VALUE;
        
        if (this.isDead()) {
            return;
        }
        
        if (combat != null && movement != null && targeting != null) {
            com.ngocrong.mob.Mob target = targeting.findTarget();
            
            if (target != null) {
                if (combat.isInAttackRange(target)) {
                    combat.attack(target);
                } else {
                    movement.moveToTarget(target);
                }
            }
        }
    }

    @Override
    public void kill(Object victim) {
        super.kill(victim);
        
        if (victim instanceof com.ngocrong.mob.Mob) {
            com.ngocrong.mob.Mob mob = (com.ngocrong.mob.Mob) victim;
            if (mob.level > 0 && zone != null) {
                long exp = mob.level * 100L;
                exp = Zone.callEXP(this, exp);
                if (exp > 0) {
                    info.addPowerOrPotential(com.ngocrong.user.Info.POWER_AND_POTENTIAL, exp);
                    logger.debug(String.format("[BotGame] Bot %s: Giết mob Level %d, Nhận exp: %d, Power mới: %d", 
                        this.name, mob.level, exp, info.power));
                }
            }
            if (targeting != null) {
                targeting.clearTarget();
            }
        }
    }

    @Override
    public boolean isBoss() {
        return false;
    }

    @Override
    public boolean isHuman() {
        return true;
    }

    public void initSkill() {
        try {
            this.skills = new java.util.ArrayList<>();
            com.ngocrong.skill.Skill skill = com.ngocrong.skill.Skills.getSkill((byte) 0, (byte) 1).clone();
            skill.manaUse = 0;
            this.skills.add(skill);
            
            logger.debug(String.format("[BotGame] Bot %s: Khởi tạo skill đấm cơ bản - Skill ID: %d, Range: %dx%d", 
                this.name, skill.id, skill.dx, skill.dy));
        } catch (Exception e) {
            logger.error("[BotGame] Lỗi khởi tạo skill: " + e.getMessage(), e);
        }
    }

}
