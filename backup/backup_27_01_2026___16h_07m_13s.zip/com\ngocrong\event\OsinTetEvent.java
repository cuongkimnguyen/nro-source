package com.ngocrong.event;

import com.ngocrong.data.OsinLixiData;
import com.ngocrong.item.Item;
import com.ngocrong.item.ItemOption;
import com.ngocrong.repository.GameRepository;
import com.ngocrong.repository.OsinLixiRepository;
import com.ngocrong.user.Player;
import com.ngocrong.util.Utils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class OsinTetEvent {

    private static OsinLixiRepository repo() {
        return GameRepository.getInstance().osinLixiRepository;
    }

    public static final int[] CHU_ANKHANG_THINHVUONG = {2462, 2463, 2464, 2465};
    public static final int[] CHU_CHUCMUNG_NAMMOI = {2466, 2467, 2468, 2469};
    public static final int[] ALL_CHU_IDS = {2462, 2463, 2464, 2465, 2466, 2467, 2468, 2469};

    public static class ChuReward {
        public int itemId;
        public int quantity;
        public List<int[]> options;

        public ChuReward(int itemId, int quantity, List<int[]> options) {
            this.itemId = itemId;
            this.quantity = quantity;
            this.options = options;
        }
    }

    private static List<ChuReward> getRewardForBoChu(int[] chuIds) {
        List<ChuReward> rewards = new ArrayList<>();
        
        if (chuIds.length != 4) {
            return rewards;
        }
        
        boolean hasAn = false, hasKhang = false, hasThinh = false, hasVuong = false;
        boolean hasChuc = false, hasMung = false, hasNam = false, hasMoi = false;
        
        for (int chuId : chuIds) {
            if (chuId == 2462) hasAn = true;
            else if (chuId == 2463) hasKhang = true;
            else if (chuId == 2464) hasThinh = true;
            else if (chuId == 2465) hasVuong = true;
            else if (chuId == 2466) hasChuc = true;
            else if (chuId == 2467) hasMung = true;
            else if (chuId == 2468) hasNam = true;
            else if (chuId == 2469) hasMoi = true;
        }
        
        boolean isAnKhangThinhVuong = hasAn && hasKhang && hasThinh && hasVuong;
        boolean isChucMungNamMoi = hasChuc && hasMung && hasNam && hasMoi;
        
        if (isAnKhangThinhVuong) {
            rewards.add(new ChuReward(2453, 1, List.of(new int[]{50, 11}, new int[]{77, 20})));
        } else if (isChucMungNamMoi) {
            rewards.add(new ChuReward(2454, 1, List.of(new int[]{50, 22}, new int[]{77, 33})));
        }
        
        return rewards;
    }

    public static void rutLixi(Player player) {
        if (player == null) {
            return;
        }


        Optional<OsinLixiData> existingLixiOpt = repo().findTodayByPlayer(player.id);
        if (existingLixiOpt.isPresent()) {
            player.service.sendThongBao("Bạn đã rút lì xì hôm nay rồi. Hãy quay lại vào ngày mai.");
            return;
        }

        if (player.getCountEmptyBag() == 0) {
            player.service.sendThongBao("Hành trang đã đầy");
            return;
        }

        int randomChuId = ALL_CHU_IDS[Utils.nextInt(ALL_CHU_IDS.length)];
        Item chuItem = new Item(randomChuId);
        chuItem.setDefaultOptions();
        chuItem.addItemOption(new ItemOption(30, 1));
        chuItem.addItemOption(new ItemOption(174, 2026));
        chuItem.quantity = 1;

        if (player.addItem(chuItem)) {
            OsinLixiData newData = new OsinLixiData();
            newData.setPlayerId(player.id);
            newData.setLixiDate(Instant.now());
            repo().save(newData);

            player.service.sendThongBao("Bạn nhận được: " + chuItem.template.name);
        } else {
            player.service.sendThongBao("Không thể nhận lì xì. Hành trang đã đầy.");
        }
    }

    public static void doiChu(Player player, int[] chuIds) {
        if (player == null) {
            return;
        }

        for (int chuId : chuIds) {
            Item chuItem = player.getItemInBag(chuId);
            if (chuItem == null || chuItem.quantity < 1) {
                player.service.sendThongBao("Bạn không đủ chữ để đổi. Cần đủ 4 chữ cùng bộ.");
                return;
            }
        }

        List<ChuReward> rewards = getRewardForBoChu(chuIds);
        
        if (rewards.isEmpty()) {
            player.service.sendThongBao("Bộ chữ không hợp lệ.");
            return;
        }

        if (player.getCountEmptyBag() < rewards.size()) {
            player.service.sendThongBao("Hành trang không đủ chỗ. Cần ít nhất " + rewards.size() + " ô trống.");
            return;
        }

        List<Item> rewardItems = new ArrayList<>();
        StringBuilder rewardMessage = new StringBuilder();
        boolean hasError = false;

        for (ChuReward reward : rewards) {
            Item rewardItem = new Item(reward.itemId);
            rewardItem.setDefaultOptions();
            rewardItem.quantity = reward.quantity;
            
            if (reward.options != null) {
                for (int[] option : reward.options) {
                    if (option.length >= 2) {
                        rewardItem.addItemOption(new ItemOption(option[0], option[1]));
                    }
                }
            }
            
            rewardItems.add(rewardItem);
            if (rewardMessage.length() > 0) {
                rewardMessage.append(", ");
            }
            rewardMessage.append(rewardItem.template.name).append(" x").append(reward.quantity);
        }

        for (int chuId : chuIds) {
            Item chuItem = player.getItemInBag(chuId);
            player.removeItem(chuItem.indexUI, 1);
        }

        for (Item rewardItem : rewardItems) {
            if (!player.addItem(rewardItem)) {
                hasError = true;
                break;
            }
        }

        if (hasError) {
            player.service.sendThongBao("Không thể nhận quà. Hành trang đã đầy.");
            for (int chuId : chuIds) {
                Item chuItem = new Item(chuId);
                chuItem.setDefaultOptions();
                chuItem.addItemOption(new ItemOption(30, 1));
                chuItem.addItemOption(new ItemOption(174, 2026));
                chuItem.quantity = 1;
                player.addItem(chuItem);
            }
        } else {
            player.service.sendThongBao("Bạn đã đổi thành công! Nhận được: " + rewardMessage.toString());
        }
    }
}
