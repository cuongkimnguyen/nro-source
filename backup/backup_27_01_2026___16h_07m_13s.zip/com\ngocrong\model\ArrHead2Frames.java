package com.ngocrong.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * author GwenDev
 */
public class ArrHead2Frames {
    
    public int itemId; 
    public List<Integer> headIds; 
    
    public ArrHead2Frames() {
        this.headIds = new ArrayList<>();
    }
    
    public ArrHead2Frames(int itemId, List<Integer> headIds) {
        this.itemId = itemId;
        this.headIds = headIds != null ? headIds : new ArrayList<>();
    }
    
    /**
     * Get part data từ các head IDs
     * @param parts Map chứa các Part theo ID
     * @return Danh sách Part tương ứng với các head IDs
     */
    public List<Part> getPartData(HashMap<Integer, Part> parts) {
        List<Part> result = new ArrayList<>();
        if (parts == null || headIds == null) {
            return result;
        }
        for (int headId : headIds) {
            Part part = parts.get(headId);
            if (part != null && part.type == 0) { 
                result.add(part);
            }
        }
        return result;
    }
}
