package _gwenstudio.botgame;

import _gwenstudio.boss.Boss;
import com.ngocrong.map.tzone.Zone;
import com.ngocrong.mob.Mob;
import com.ngocrong.network.Service;
import com.ngocrong.skill.Skill;
import com.ngocrong.skill.Skills;
import com.ngocrong.user.Info;
import com.ngocrong.util.Utils;
import org.apache.log4j.Logger;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

/**
 * Bot đánh quái đơn giản
 * Tự động tìm và tấn công quái gần nhất trong zone
 */
public class BotGameMonsterHunter extends Boss {

    private static final Logger logger = Logger.getLogger(BotGameMonsterHunter.class);

    // Mob đang nhắm tấn công
    public Mob mobTarget = null;
    
    // Thời gian tấn công lần cuối (ms)
    public long lastAttackTime = 0;
    
    // Tốc độ tấn công (ms) - mặc định 550ms
    public int attackSpeed = 550;
    
    // Thời gian spawn bot
    public long timeSpawn = System.currentTimeMillis();
    
    // Level bot (1-200)
    public int botLevel = 50;
    
    // Power bot
    public long botPower = 100000L;

    /**
     * Constructor bot đánh quái
     * @param name - Tên bot
     * @param level - Level bot (1-200)
     * @param power - Power bot
     * @param zone - Zone spawn bot
     */
    public BotGameMonsterHunter(String name, int level, long power, Zone zone) {
        super();
        this.name = name;
        this.id = Utils.nextInt(1000000, 9999999);
        this.botLevel = level;
        this.botPower = power;
        
        logger.debug(String.format("[BotGame] Tạo bot mới - Name: %s, ID: %d, Level: %d, Power: %d", 
            name, this.id, level, power));
        
        initializeBot(zone);
    }

    /**
     * Khởi tạo bot với các thông số cơ bản
     * @param zone - Zone spawn bot
     */
    private void initializeBot(Zone zone) {
        try {
            this.itemBag = new com.ngocrong.item.Item[100];
            this.gender = (byte) Utils.nextInt(3);
            
            // Tính HP, MP, Damage dựa trên power
            long hp = botPower * 10L;
            long mp = Long.MAX_VALUE;
            long dame = botPower / 10L;
            
            this.setInfo(hp, mp, dame, 100, 5);
            this.info.power = botPower;
            this.info.level = botLevel;
            
            logger.debug(String.format("[BotGame] Khởi tạo bot - HP: %d, MP: %d, Damage: %d", 
                hp, mp, dame));
            
            // Set appearance ngẫu nhiên
            setRandomAppearance();
            
            // Khởi tạo skill cho bot (phải gọi sau khi set gender)
            initSkill();
            
            // Spawn vào zone
            if (zone != null) {
                this.setX((short) Utils.nextInt(50, zone.map.width - 50));
                this.setY((short) zone.map.collisionLand(this.getX(), (short) 0));
                this.service = new Service(this);
                zone.enter(this);
                
                logger.debug(String.format("[BotGame] Bot spawn vào Map: %d, Zone: %d, X: %d, Y: %d", 
                    zone.map.mapID, zone.zoneID, this.getX(), this.getY()));
            }
        } catch (Exception e) {
            logger.error("[BotGame] Lỗi khởi tạo bot: " + e.getMessage(), e);
        }
    }

    /**
     * Set appearance ngẫu nhiên cho bot
     */
    private void setRandomAppearance() {
        try {
            short[][] hair = new short[][]{
                {64, 30, 31}, {9, 29, 32}, {6, 27, 28}
            };
            short head = hair[this.gender][Utils.nextInt(hair[this.gender].length)];
            short body = (short) (this.gender == 0 ? 14 : this.gender == 1 ? 10 : 16);
            short leg = (short) (this.gender == 0 ? 15 : this.gender == 1 ? 11 : 17);
            
            Method setHeadMethod = com.ngocrong.user.Player.class.getDeclaredMethod("setHead", short.class);
            setHeadMethod.setAccessible(true);
            setHeadMethod.invoke(this, head);
            
            Field headField = com.ngocrong.user.Player.class.getDeclaredField("head");
            Field bodyField = com.ngocrong.user.Player.class.getDeclaredField("body");
            Field legField = com.ngocrong.user.Player.class.getDeclaredField("leg");
            Field headDefaultField = com.ngocrong.user.Player.class.getDeclaredField("headDefault");
            
            headField.setAccessible(true);
            bodyField.setAccessible(true);
            legField.setAccessible(true);
            headDefaultField.setAccessible(true);
            
            headField.setShort(this, head);
            bodyField.setShort(this, body);
            legField.setShort(this, leg);
            headDefaultField.setShort(this, head);
            
            logger.debug(String.format("[BotGame] Set appearance - Gender: %d, Head: %d, Body: %d, Leg: %d", 
                this.gender, head, body, leg));
        } catch (Exception e) {
            logger.error("[BotGame] Lỗi set appearance: " + e.getMessage(), e);
        }
    }

    /**
     * Update bot mỗi frame
     * Tìm và tấn công quái gần nhất
     */
    @Override
    public void update() {
        if (this.zone == null) {
            return;
        }
        
        // Set MP = MAX để bot luôn có đủ mana
        this.info.mp = this.info.mpFull = Long.MAX_VALUE;
        
        // Nếu bot đã chết thì không làm gì
        if (this.isDead()) {
            return;
        }
        
        // Gọi super.update() để có animation và logic cơ bản
        try {
            super.update();
        } catch (Exception e) {
            logger.error("[BotGame] Lỗi trong super.update(): " + e.getMessage(), e);
        }
        
        // Tìm và tấn công quái (giống VirtualBot)
        attack();
    }
    
    /**
     * Method attack giống VirtualBot để đấm bình thường
     */
    public void attack() {
        if (zone != null) {
            if (mobTarget == null) {
                List<Mob> mobs = zone.getListMob();
                double minDistance = Double.MAX_VALUE;

                int playerX = this.getX();
                int playerY = this.getY();

                for (Mob mob : mobs) {
                    if (mob != null && mob.status != 0 && mob.status != 1 && !mob.isMobMe && mob.hp > 0) {
                        double distance = Math.sqrt(
                                Math.pow(mob.x - playerX, 2)
                                + Math.pow(mob.y - playerY, 2)
                        );

                        if (distance < minDistance) {
                            minDistance = distance;
                            mobTarget = mob;
                        }
                    }
                }
            }
            if (mobTarget != null) {
                if (this.skills == null || this.skills.isEmpty()) {
                    initSkill();
                }
                if (this.skills != null && !this.skills.isEmpty()) {
                    this.select = skills.get(0);
                    this.select.manaUse = 0;
                }
                Mob mob = mobTarget;
                if (mob.status == 0 || mob.status == 1 || mob.isMobMe || mob.hp <= 0) {
                    mobTarget = null;
                    return;
                }
                if (Math.abs(this.getX() - mob.x) > select.dx * 1.2 || Math.abs(this.getY() - mob.y) > select.dy * 1.2) {
                    if (this.meCanMove()) {
                        int stepSize = 100;
                        int newX = mob.x;
                        int newY = mob.y;

                        if (Math.abs(mob.x - this.getX()) > stepSize) {
                            newX = this.getX() + (mob.x > this.getX() ? stepSize : -stepSize);
                        }
                        if (Math.abs(mob.y - this.getY()) > stepSize) {
                            newY = this.getY() + (mob.y > this.getY() ? stepSize : -stepSize);
                        }
                        this.moveTo((short) newX, (short) newY);
                    }
                    return;
                }
                if (this.meCanAttack() && System.currentTimeMillis() - lastAttackTime >= attackSpeed) {
                    lastAttackTime = System.currentTimeMillis();
                    this.zone.attackNpc(this, mobTarget, false);
                }
            }
        }
    }


    /**
     * Xử lý khi bot giết được mob
     * @param victim - Đối tượng bị giết
     */
    @Override
    public void kill(Object victim) {
        super.kill(victim);
        
        if (victim instanceof Mob) {
            Mob mob = (Mob) victim;
            if (mob.level > 0 && zone != null) {
                // Tính exp từ mob
                long exp = mob.level * 100L;
                exp = Zone.callEXP(this, exp);
                if (exp > 0) {
                    info.addPowerOrPotential(Info.POWER_AND_POTENTIAL, exp);
                    
                    logger.debug(String.format("[BotGame] Bot %s: Giết mob Level %d, Nhận exp: %d, Power mới: %d", 
                        this.name, mob.level, exp, info.power));
                }
            }
            // Reset target sau khi giết
            mobTarget = null;
        }
    }

    @Override
    public boolean isBoss() {
        return false;
    }

    @Override
    public boolean isHuman() {
        return true;
    }

    /**
     * Khởi tạo skill cho bot
     * Bot chỉ dùng skill đấm cơ bản (skill 0, level 1)
     */
    @Override
    public void initSkill() {
        try {
            this.skills = new java.util.ArrayList<>();
            // Skill đấm cơ bản: skill ID 0, level 1
            Skill skill = Skills.getSkill((byte) 0, (byte) 1).clone();
            skill.manaUse = 0;
            this.skills.add(skill);
            
            logger.debug(String.format("[BotGame] Bot %s: Khởi tạo skill đấm cơ bản - Skill ID: %d, Range: %dx%d", 
                this.name, skill.id, skill.dx, skill.dy));
        } catch (Exception e) {
            logger.error("[BotGame] Lỗi khởi tạo skill: " + e.getMessage(), e);
            // Fallback: tạo skill đơn giản nếu lỗi
            try {
                this.skills = new java.util.ArrayList<>();
                Skill fallbackSkill = new Skill();
                fallbackSkill.id = 0;
                fallbackSkill.manaUse = 0;
                fallbackSkill.dx = 50;
                fallbackSkill.dy = 50;
                this.skills.add(fallbackSkill);
                logger.debug("[BotGame] Sử dụng skill fallback đơn giản");
            } catch (Exception e2) {
                logger.error("[BotGame] Lỗi tạo skill fallback: " + e2.getMessage(), e2);
            }
        }
    }

    @Override
    public void setDefaultHead() {
    }

    @Override
    public void setDefaultBody() {
    }

    @Override
    public void setDefaultLeg() {
    }
}
