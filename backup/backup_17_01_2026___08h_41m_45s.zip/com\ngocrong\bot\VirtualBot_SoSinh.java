/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ngocrong.bot;

import _gwenstudio.ConfigStudio;
import com.ngocrong.item.Item;
import com.ngocrong.map.MapManager;
import com.ngocrong.map.TMap;
import com.ngocrong.map.tzone.Zone;
import com.ngocrong.server.DragonBall;
import com.ngocrong.server.Server;
import com.ngocrong.util.Utils;
import org.apache.log4j.Logger;

/**
 *
 * @author Administrator
 */
public class VirtualBot_SoSinh extends VirtualBot {

    private static final Logger logger = Logger.getLogger(VirtualBot_SoSinh.class);
    public static int BotSS;

    public VirtualBot_SoSinh(String name) {
        super(name);
        this.gender = (byte) Utils.nextInt(3);
        this.info.power = Utils.nextInt(1500000, 1500005);
        this.setInfo(Utils.nextInt(3000, 5000), Long.MAX_VALUE, Utils.nextInt(50, 70), 10000, 1);
        
        equipItemsByPower();
        currentEquipLevel = getCurrentEquipLevel();
        
        timeSpawn = System.currentTimeMillis();
    }
    
    private int getCurrentEquipLevel() {
        if (itemBody != null && itemBody[0] != null) {
            return itemBody[0].template.level;
        }
        return -1;
    }
    
    private void equipItemsByPower() {
        try {
            Server server = DragonBall.getInstance().getServer();
            if (server == null || server.iTemplates == null || server.iTemplates.isEmpty()) {
                logger.warn("[DEBUG] equipItemsByPower: Server or iTemplates is null/empty");
                return;
            }
            
            if (itemBody == null) {
                itemBody = new Item[16];
            }
            
            logger.info(String.format("[DEBUG] equipItemsByPower: bot=%s, gender=%d, power=%d", name, gender, info.power));
            
            int bestLevel = -1;
            int[] bestItems = new int[5];
            
            for (int level = 14; level >= 0; level--) {
                int[] items = findItemSetByLevel(server, level, gender, info.power);
                // Chỉ cần type 0,1,2,3 (áo, quần, găng tay, giày). Type 5 (hair) là optional
                if (items[0] > 0 && items[1] > 0 && items[2] > 0 && items[3] > 0) {
                    bestLevel = level;
                    bestItems = items;
                    logger.info(String.format("[DEBUG] Found complete set at level %d (type5=%d is optional)", level, items[4]));
                    break;
                }
            }
            
            if (bestLevel >= 0) {
                logger.info(String.format("[DEBUG] Equipping items at level %d: type0=%d, type1=%d, type2=%d, type3=%d, type5=%d", 
                    bestLevel, bestItems[0], bestItems[1], bestItems[2], bestItems[3], bestItems[4]));
                
                if (bestItems[0] > 0) {
                    Item bodyItem = new Item(bestItems[0]);
                    bodyItem.setDefaultOptions();
                    itemBody[0] = bodyItem;
                    itemBody[0].indexUI = 0;
                    logger.info(String.format("[DEBUG] Equipped TYPE_AO: id=%d, part=%d, name=%s", 
                        bodyItem.id, bodyItem.template.part, bodyItem.template.name));
                }
                
                if (bestItems[1] > 0) {
                    Item legItem = new Item(bestItems[1]);
                    legItem.setDefaultOptions();
                    itemBody[1] = legItem;
                    itemBody[1].indexUI = 1;
                    logger.info(String.format("[DEBUG] Equipped TYPE_QUAN: id=%d, part=%d, name=%s", 
                        legItem.id, legItem.template.part, legItem.template.name));
                }
                
                if (bestItems[2] > 0) {
                    Item gloveItem = new Item(bestItems[2]);
                    gloveItem.setDefaultOptions();
                    itemBody[2] = gloveItem;
                    itemBody[2].indexUI = 2;
                    logger.info(String.format("[DEBUG] Equipped TYPE_GANGTAY: id=%d, name=%s", 
                        gloveItem.id, gloveItem.template.name));
                }
                
                if (bestItems[3] > 0) {
                    Item shoeItem = new Item(bestItems[3]);
                    shoeItem.setDefaultOptions();
                    itemBody[3] = shoeItem;
                    itemBody[3].indexUI = 3;
                    logger.info(String.format("[DEBUG] Equipped TYPE_GIAY: id=%d, name=%s", 
                        shoeItem.id, shoeItem.template.name));
                }
                
                if (bestItems[4] > 0) {
                    Item headItem = new Item(bestItems[4]);
                    headItem.setDefaultOptions();
                    headItem.isNhapThe = false;
                    itemBody[5] = headItem;
                    itemBody[5].indexUI = 5;
                    logger.info(String.format("[DEBUG] Equipped TYPE_HAIR: id=%d, part=%d, name=%s, isNhapThe=%s", 
                        headItem.id, headItem.template.part, headItem.template.name, headItem.isNhapThe));
                }
                
                info.setInfo();
                updateSkin();
                
                logger.info(String.format("[DEBUG] After updateSkin: itemBody[0]=%s, itemBody[1]=%s, itemBody[5]=%s", 
                    itemBody[0] != null ? "id=" + itemBody[0].id + ",part=" + itemBody[0].template.part : "null",
                    itemBody[1] != null ? "id=" + itemBody[1].id + ",part=" + itemBody[1].template.part : "null",
                    itemBody[5] != null ? "id=" + itemBody[5].id + ",part=" + itemBody[5].template.part : "null"));
                
                if (service != null) {
                    service.setItemBody();
                }
                if (zone != null && zone.service != null) {
                    zone.service.updateBody((byte) -1, this);
                }
            } else {
                logger.warn(String.format("[DEBUG] No complete item set found for bot=%s, gender=%d, power=%d", name, gender, info.power));
            }
            
        } catch (Exception e) {
            logger.error("[DEBUG] equipItemsByPower error", e);
        }
    }
    
    private int[] findItemSetByLevel(Server server, int level, int gender, long power) {
        int[] items = new int[5];
        int foundCount = 0;
        
        logger.info(String.format("[DEBUG] findItemSetByLevel: level=%d, gender=%d, power=%d", level, gender, power));
        
        for (com.ngocrong.item.ItemTemplate item : server.iTemplates.values()) {
            if (item.id == 693 || item.id == 691 || item.id == 692) {
                continue;
            }
            
            // Debug: Log items that match level and power but not gender
            if (item.level == level && item.require <= power && item.gender != gender) {
                if ((item.type == 0 || item.type == 1 || item.type == 2 || item.type == 3 || item.type == 5) && foundCount < 5) {
                    logger.debug(String.format("[DEBUG] Item found but gender mismatch: id=%d, type=%d, level=%d, require=%d, gender=%d (bot gender=%d)", 
                        item.id, item.type, item.level, item.require, item.gender, gender));
                }
            }
            
            // Check gender match: item.gender == bot.gender OR item.gender == 3 (universal)
            boolean genderMatch = (item.gender == gender || item.gender == 3);
            
            if (item.level == level && item.require <= power && genderMatch) {
                if (item.type == 0 && items[0] == 0) {
                    items[0] = item.id;
                    logger.info(String.format("[DEBUG] Found TYPE_AO (0): id=%d, name=%s, part=%d, require=%d, gender=%d (bot gender=%d)", 
                        item.id, item.name, item.part, item.require, item.gender, gender));
                } else if (item.type == 1 && items[1] == 0) {
                    items[1] = item.id;
                    logger.info(String.format("[DEBUG] Found TYPE_QUAN (1): id=%d, name=%s, part=%d, require=%d, gender=%d (bot gender=%d)", 
                        item.id, item.name, item.part, item.require, item.gender, gender));
                } else if (item.type == 2 && items[2] == 0) {
                    items[2] = item.id;
                    logger.info(String.format("[DEBUG] Found TYPE_GANGTAY (2): id=%d, name=%s, require=%d, gender=%d (bot gender=%d)", 
                        item.id, item.name, item.require, item.gender, gender));
                } else if (item.type == 3 && items[3] == 0) {
                    items[3] = item.id;
                    logger.info(String.format("[DEBUG] Found TYPE_GIAY (3): id=%d, name=%s, require=%d, gender=%d (bot gender=%d)", 
                        item.id, item.name, item.require, item.gender, gender));
                } else if (item.type == 5 && items[4] == 0) {
                    items[4] = item.id;
                    logger.info(String.format("[DEBUG] Found TYPE_HAIR (5): id=%d, name=%s, part=%d, require=%d, gender=%d (bot gender=%d)", 
                        item.id, item.name, item.part, item.require, item.gender, gender));
                }
            }
            
            // Chỉ cần type 0,1,2,3 (áo, quần, găng tay, giày). Type 5 (hair) là optional
            if (items[0] > 0 && items[1] > 0 && items[2] > 0 && items[3] > 0) {
                break;
            }
        }
        
        logger.info(String.format("[DEBUG] findItemSetByLevel result: type0=%d, type1=%d, type2=%d, type3=%d, type5=%d (type5 optional)", 
            items[0], items[1], items[2], items[3], items[4]));
        
        return items;
    }

    int currentEquipLevel = -1;
    long lastCheckEquip = 0;
    
    @Override
    public void update() {
        this.info.mp = this.info.mpFull = Long.MAX_VALUE;

        if (System.currentTimeMillis() - lastCheckEquip >= 5000) {
            checkAndUpgradeEquip();
            lastCheckEquip = System.currentTimeMillis();
        }

        updateNextMap();
        if (zone != null) {
            if (this.zone.map.mapID != mapNext) {
                TMap map = MapManager.getInstance().getMap(mapNext);
                if (map != null) {
                    Zone zone = map.getMinPlayerZone();
                    this.zone.leave(this);
                    zone.enter(this);
                }
            }
        } else {
            TMap map = MapManager.getInstance().getMap(mapNext);
            if (map != null) {
                Zone zone = map.getMinPlayerZone();
                zone.enter(this);
            }
        }

        attack();
    }
    
    private void checkAndUpgradeEquip() {
        try {
            Server server = DragonBall.getInstance().getServer();
            if (server == null || server.iTemplates == null || server.iTemplates.isEmpty()) {
                return;
            }
            
            int bestLevel = -1;
            int[] bestItems = new int[5];
            
            for (int level = 14; level >= 0; level--) {
                if (level <= currentEquipLevel) {
                    break;
                }
                int[] items = findItemSetByLevel(server, level, gender, info.power);
                // Chỉ cần type 0,1,2,3 (áo, quần, găng tay, giày). Type 5 (hair) là optional
                if (items[0] > 0 && items[1] > 0 && items[2] > 0 && items[3] > 0) {
                    bestLevel = level;
                    bestItems = items;
                    logger.info(String.format("[DEBUG] Found upgrade set at level %d (type5=%d is optional)", level, items[4]));
                    break;
                }
            }
            
            if (bestLevel > currentEquipLevel) {
                if (itemBody == null) {
                    itemBody = new Item[16];
                }
                
                if (bestItems[0] > 0) {
                    Item bodyItem = new Item(bestItems[0]);
                    bodyItem.setDefaultOptions();
                    itemBody[0] = bodyItem;
                    itemBody[0].indexUI = 0;
                }
                
                if (bestItems[1] > 0) {
                    Item legItem = new Item(bestItems[1]);
                    legItem.setDefaultOptions();
                    itemBody[1] = legItem;
                    itemBody[1].indexUI = 1;
                }
                
                if (bestItems[2] > 0) {
                    Item gloveItem = new Item(bestItems[2]);
                    gloveItem.setDefaultOptions();
                    itemBody[2] = gloveItem;
                    itemBody[2].indexUI = 2;
                }
                
                if (bestItems[3] > 0) {
                    Item shoeItem = new Item(bestItems[3]);
                    shoeItem.setDefaultOptions();
                    itemBody[3] = shoeItem;
                    itemBody[3].indexUI = 3;
                }
                
                if (bestItems[4] > 0) {
                    Item headItem = new Item(bestItems[4]);
                    headItem.setDefaultOptions();
                    headItem.isNhapThe = false;
                    itemBody[5] = headItem;
                    itemBody[5].indexUI = 5;
                }
                
                currentEquipLevel = bestLevel;
                info.setInfo();
                updateSkin();
                
                if (service != null) {
                    service.setItemBody();
                }
                if (zone != null && zone.service != null) {
                    zone.service.updateBody((byte) -1, this);
                }
            }
            
        } catch (Exception e) {
        }
    }

    @Override
    void setBag1() {
        byte[] bag = new byte[]{19, 20, 21, 22, 105, 106};
        this.clanID = Utils.nextInt(0, 100);
        this.setBag(bag[Utils.nextInt(bag.length)]);
        this.name = Utils.getAbbre("[" + ConfigStudio.SLOGAN_BOTSOSINH + "]") + this.name;
    }

    @Override
    public boolean isBoss() {
        return false;
    }

    @Override
    public boolean isHuman() {
        return true;
    }

    public void updateNextMap() {
        long time = System.currentTimeMillis() - this.timeSpawn;
        int oldMapNext = this.mapNext;
        if (time > 700_000 && this.clanID == -1) {
            setBag1();
        }
        if (time < 50_000) {
            this.mapNext = this.gender == 0 ? 0 : this.gender == 1 ? 7 : 14;

        } else if (time < 100_000) {
            this.mapNext = this.gender == 0 ? 1 : this.gender == 1 ? 8 : 15;

        } else if (time < 150_000) {
            this.mapNext = this.gender == 0 ? 2 : this.gender == 1 ? 9 : 16;

        } else if (time < 300_000) {
            this.mapNext = this.gender == 0 ? 9 : this.gender == 1 ? 16 : 2;
            if (oldMapNext != this.mapNext) {
                this.setInfo(Utils.nextInt(18000, 22000), Utils.nextInt(18000, 22000), Utils.nextInt(500, 700), 10000, 1);
            }

        } else if (time < 450_000) {
            this.mapNext = this.gender == 0 ? 16 : this.gender == 1 ? 2 : 9;

        } else if (time < 500_000) {
            this.mapNext = this.gender == 0 ? 3 : this.gender == 1 ? 11 : 17;
            if (oldMapNext != this.mapNext) {
                this.setInfo(Utils.nextInt(18000, 22000), Utils.nextInt(18000, 22000), Utils.nextInt(500, 700), 10000, 1);
            }

        } else if (time < 600_000) {
            this.mapNext = this.gender == 0 ? 18 : this.gender == 1 ? 4 : 12;
            if (oldMapNext != this.mapNext) {
                this.setInfo(Utils.nextInt(18000, 22000), Utils.nextInt(18000, 22000), Utils.nextInt(200, 500), 10000, 1);
            }

        } else if (time < 650_000) {
            this.mapNext = this.gender == 0 ? 18 : this.gender == 1 ? 4 : 12;
            if (oldMapNext != this.mapNext) {
                this.setInfo(Utils.nextInt(18000, 22000), Utils.nextInt(18000, 22000), Utils.nextInt(500, 800), 10000, 1);
            }

        } else if (time < 700_000) {
            this.mapNext = 27;
            if (oldMapNext != this.mapNext) {
                this.setInfo(Utils.nextInt(18000, 22000), Utils.nextInt(18000, 22000), Utils.nextInt(500, 1000), 10000, 1);
            }

        } else if (time < 800_000) {
            this.mapNext = 31;

        } else if (time < 900_000) {
            this.mapNext = 35;

        } else if (time < 1_000_000) {
            this.mapNext = 30;
            if (oldMapNext != this.mapNext) {
                this.setInfo(this.info.hpFull, 3000000, 1000, 10000, 1);
            }

        } else if (time < 1_100_000) {
            // bamboo - 60 phút
            this.mapNext = 34;

        } else if (time < 1_150_000) {
            this.mapNext = 38;

        } else if (time < 1_200_000) {
            this.mapNext = 6;
            if (oldMapNext != this.mapNext) {
                this.setInfo(this.info.hpFull, 3000000, 3000, 10000, 1);
            }

        } else if (time < 1_300_000) {
            this.mapNext = 10;

        } else if (time < 1_400_000) {
            this.mapNext = 19;

        } else {
            this.mapNext = -1;
            this.zone.leave(this);
            this.close();
        }
    }

}
