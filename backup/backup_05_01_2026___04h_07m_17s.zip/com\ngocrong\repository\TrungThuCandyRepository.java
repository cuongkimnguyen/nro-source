package com.ngocrong.repository;

import com.ngocrong.data.TrungThuCandyData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TrungThuCandyRepository extends JpaRepository<TrungThuCandyData, Integer> {

    Optional<TrungThuCandyData> findByPlayerId(int playerId);
}
