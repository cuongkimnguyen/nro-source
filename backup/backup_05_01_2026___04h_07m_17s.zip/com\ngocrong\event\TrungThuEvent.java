package com.ngocrong.event;

import com.ngocrong.bot.Boss;
import com.ngocrong.bot.VirtualBot;
import com.ngocrong.collection.Card;
import com.ngocrong.collection.CardTemplate;
import com.ngocrong.consts.CMDMenu;
import com.ngocrong.consts.ItemName;
import com.ngocrong.consts.ItemTimeName;
import com.ngocrong.data.TrungThuCandyData;
import com.ngocrong.item.Item;
import com.ngocrong.item.ItemMap;
import com.ngocrong.item.ItemOption;

import com.ngocrong.lib.KeyValue;
import com.ngocrong.lib.RandomCollection;
import com.ngocrong.model.Npc;
import com.ngocrong.mob.Mob;
import com.ngocrong.repository.GameRepository;
import com.ngocrong.repository.TrungThuCandyRepository;
import com.ngocrong.shop.Shop;
import com.ngocrong.top.Top;
import com.ngocrong.user.Player;
import com.ngocrong.util.Utils;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class TrungThuEvent {

    private static final ZoneId ZONE_ID = ZoneId.of("Asia/Ho_Chi_Minh");
    private static final LocalTime START_TIME = LocalTime.of(19, 0);
    private static final LocalTime END_TIME = LocalTime.of(20, 0);
    private static final RandomCollection<Integer> REWARD_POOL = new RandomCollection<Integer>()
            .add(30, 1)
            .add(30, 2)
            .add(20, 3)
            .add(10, 4)
            .add(10, 5);
    private static final int[] EXCHANGE_OPTIONS = {1, 5, 10};
    private static final int[] SPECIAL_MOONCAKE_TIMES = {
        ItemTimeName.BANH_TRUNG_THU_BE,
        ItemTimeName.BANH_TRUNG_THU_LON,
        ItemTimeName.BANH_TRUNG_THU_THAP_CAM
    };
    private static final int ONE_YOLK_MIN_EMPTY_SLOTS = 1;
    private static final int TWO_YOLK_MIN_EMPTY_SLOTS = 1;
    private static final int SPECIAL_BOX_MIN_EMPTY_SLOTS = 1;
    private static final int OPTION_HP_PERCENT = 77;
    private static final int OPTION_KI_PERCENT = 103;
    private static final int OPTION_DAMAGE_PERCENT = 50;
    private static final int OPTION_CRIT_DAMAGE = 5;
    private static final int OPTION_CRIT_CHANCE = 14;
    private static final int OPTION_LAZE_DAMAGE = 197;
    private static final int OPTION_SUICIDE_DAMAGE = 196;
    private static final int OPTION_ARMOR_PERCENT = 94;
    private static final int OPTION_DODGE_PERCENT = 108;
    private static final int OPTION_KHANG_TDHS = 116;
    private static final int OPTION_DURATION_DAYS = 93;
    private static final int OPTION_BOMB_DAMAGE = 196;
    private static final int INGREDIENT_DAU_XANH = ItemName.DAU_XANH;
    private static final int INGREDIENT_THIT_GA = ItemName.GA_QUAY_NGUYEN_CON;
    private static final int INGREDIENT_BOT_MI = ItemName.BOT_MI;
    private static final int INGREDIENT_TRUNG = ItemName.TRUNG_VIT_MUOI;
    private static final int GOLD_BAR_ID = ItemName.THOI_VANG;
    private static final int CARROT_ITEM_ID = ItemName.CU_CA_ROT;
    private static final int COSTUME_ITEM_ID = ItemName.CAI_TRANG_THO_DAI_CA;
    private static final int CARROT_EXCHANGE_REQUIRED = 99;
    private static final long COSTUME_GOLD_COST = 200_000_000L;
    private static final int COSTUME_PERCENT_BONUS = 20;
    private static final int[] INGREDIENT_POOL = {
        INGREDIENT_DAU_XANH,
        INGREDIENT_THIT_GA,
        INGREDIENT_BOT_MI
    };
    private static final long ONE_YOLK_COST_GOLD = 200_000_000L;
    private static final int TWO_YOLK_GOLD_BAR_COST = 5;

    public static void openBXH(Player player, Npc npc) {
        player.menus.clear();
        player.menus.add(new KeyValue(CMDMenu.TRUNG_THU_BXH_CF, "BXH Bánh 1 trứng", 0));
        player.menus.add(new KeyValue(CMDMenu.TRUNG_THU_BXH_CF, "BXH Bánh 2 trứng", 1));
        player.menus.add(new KeyValue(CMDMenu.TRUNG_THU_BXH_CF, "BXH Hộp bánh ĐB", 2));
        player.service.openUIConfirm(npc.templateId, "Bạn muốn xem BXH nào ?", npc.avatar, player.menus);
    }

    public static void openBXH_CF(Player player, Npc npc, int key) {
        int topId;
        switch (key) {
            case 0:
                topId = Top.TOP_BANH1TRUNG;
                break;
            case 1:
                topId = Top.TOP_BANH2TRUNG;
                break;
            case 2:
                topId = Top.TOP_BANHDACBIET;
                break;
            default:
                topId = Top.TOP_BANH1TRUNG; // Default fallback
                break;
        }

        Top topQuaThuong = Top.getTop(topId);
        assert topQuaThuong != null;
        topQuaThuong.update();
        topQuaThuong.show(player);
    }

    private TrungThuEvent() {
    }

    public static void openShop(Player player, Npc npc) {
        player.shop = Shop.getShop(npc.templateId);
        if (player.shop != null) {
            player.shop.setNpc(npc);
            player.service.viewShop(player.shop);
        }
    }

    private static TrungThuCandyRepository repo() {
        return GameRepository.getInstance().trungThuCandyRepository;
    }

    public static void openMenu(Player player, Npc npc) {
        if (player == null || npc == null) {
            return;
        }
        player.menus.clear();
        TrungThuCandyRepository repository = repo();
        if (repository == null) {
            player.service.sendThongBao("Tính năng đang bảo trì.");
            return;
        }
        Optional<TrungThuCandyData> dataOptional = repository.findByPlayerId(player.id);
        TrungThuCandyData data = dataOptional.orElse(null);
        int balance = getBalance(player);
        Instant now = Instant.now();
        StringBuilder content = new StringBuilder();
        content.append("Sự kiện Trung Thu\n");
        content.append("Thời gian nhận kẹo: 19h00 - 20h00 mỗi ngày.\n");
        if (isInRewardTime(now)) {
            content.append("Hiện đang trong khung giờ nhận quà.\n");
        } else {
            content.append("Hiện ngoài khung giờ nhận quà.\n");
        }
        content.append("Bạn đang có ").append(balance).append(" gói kẹo.\n");
        content.append("Một gói kẹo đổi được 1 thỏi vàng.\n");
        content.append("Thu thập Đậu xanh, Thịt gà, Bột mì từ quái và Trứng từ boss để chế bánh.");

        player.menus.add(new KeyValue(CMDMenu.TRUNG_THU_CLAIM, "Nhận\nKẹo"));
        player.menus.add(new KeyValue(CMDMenu.TRUNG_THU_EXCHANGE_MENU, "Đổi\nKẹo"));
        player.menus.add(new KeyValue(CMDMenu.TRUNG_THU_INGREDIENT_MENU, "Đổi\nBánh"));
        player.menus.add(new KeyValue(CMDMenu.TRUNG_THU_SHOP, "Cửa hàng"));
        player.menus.add(new KeyValue(CMDMenu.TRUNG_THU_BXH, "Bảng xếp hạng"));
        player.menus.add(new KeyValue(CMDMenu.CANCEL, "Đóng"));
        player.service.openUIConfirm(npc.templateId, content.toString(), npc.avatar, player.menus);
    }

    public static void claimCandy(Player player, Npc npc) {
        if (player == null || npc == null) {
            return;
        }
        TrungThuCandyRepository repository = repo();
        if (repository == null) {
            player.service.sendThongBao("Tính năng đang bảo trì.");
            return;
        }
        Instant now = Instant.now();
        if (!isInRewardTime(now)) {
            player.service.sendThongBao("Thời gian nhận quà là từ 19h00 đến 20h00 mỗi ngày.");
            openMenu(player, npc);
            return;
        }
        TrungThuCandyData data = repository.findByPlayerId(player.id)
                .orElseGet(() -> createNewData(player.id, now));
        if (data.getPlayerId() == null) {
            data.setPlayerId(player.id);
        }
        if (hasClaimedToday(data)) {
            player.service.sendThongBao("Bạn đã nhận kẹo hôm nay rồi, hãy quay lại vào ngày mai.");
            openMenu(player, npc);
            return;
        }
        int reward = REWARD_POOL.next();
        data.setCandyBalance(reward);
        data.setLastClaimAt(now);
        data.setLastClaimAmount(reward);
        data.setUpdatedAt(now);
        if (data.getCreatedAt() == null) {
            data.setCreatedAt(now);
        }
        repository.save(data);
        Item item = new Item(2467);
        item.quantity = reward;
        player.addItem(item);
        player.service.sendThongBao("Bạn nhận được " + reward + " gói kẹo Trung Thu.");
        openMenu(player, npc);
    }

    public static void openExchangeMenu(Player player, Npc npc) {
        if (player == null || npc == null) {
            return;
        }
        player.menus.clear();
        TrungThuCandyRepository repository = repo();
        if (repository == null) {
            player.service.sendThongBao("Tính năng đang bảo trì.");
            return;
        }
        int balance = getBalance(player);
        if (balance <= 0) {
            player.service.sendThongBao("Bạn không có gói kẹo nào để đổi.");
            openMenu(player, npc);
            return;
        }
        StringBuilder content = new StringBuilder();
        content.append("Chọn số lượng muốn đổi sang thỏi vàng (1 gói = 1 thỏi).");

        for (int option : EXCHANGE_OPTIONS) {
            if (balance >= option) {
                player.menus.add(new KeyValue(CMDMenu.TRUNG_THU_EXCHANGE,
                        "Đổi " + option + "\nThỏi vàng", option));
            }
        }
        player.menus.add(new KeyValue(CMDMenu.TRUNG_THU_EXCHANGE,
                "Đổi tất cả\n(" + balance + ")", balance));
        player.menus.add(new KeyValue(CMDMenu.CANCEL, "Hủy"));
        player.service.openUIConfirm(npc.templateId, content.toString(), npc.avatar, player.menus);
    }

    public static void exchangeCandy(Player player, Npc npc, int amount) {
        if (player == null || npc == null) {
            return;
        }
        if (amount <= 0) {
            openMenu(player, npc);
            return;
        }
        TrungThuCandyRepository repository = repo();
        if (repository == null) {
            player.service.sendThongBao("Tính năng đang bảo trì.");
            return;
        }

        int balance = 0;
        Item keo = player.getItemInBag(2467);
        if (keo != null) {
            balance = keo.quantity == 0 ? 1 : keo.quantity;
        }
        if (balance < amount) {
            player.service.sendThongBao("Số lượng kẹo không đủ.");
            openMenu(player, npc);
            return;
        }
        Item goldBar = new Item(ItemName.THOI_VANG);
        goldBar.quantity = amount;
        if (!player.addItem(goldBar)) {
            player.service.sendThongBao("Hành trang không đủ chỗ trống.");
            openMenu(player, npc);
            return;
        }
        player.removeItem(keo.indexUI, amount);
        player.service.sendThongBao("Đã đổi " + amount + " gói kẹo lấy " + amount + " thỏi vàng.");
        openMenu(player, npc);
    }

    public static void openIngredientMenu(Player player, Npc npc) {
        if (player == null || npc == null) {
            return;
        }
        player.menus.clear();
        StringBuilder content = new StringBuilder();
        content.append("Nguyên liệu đang có:\n");
        content.append("Dùng x1 Đậu xanh, x1 Trứng, x1 Thịt gà, x1 Bột mì + 200tr = Bánh trung thu 1 trứng.");
        content.append("\nDùng x1 Đậu xanh, x2 Trứng, x1 Thịt gà, x1 Bột mì + 5 tv = Bánh trung thu 2 trứng.");
        content.append("\nĐổi 99 Cà rốt + 200tr vàng lấy cải trang Thỏ Đại Ca.");

        player.menus.add(new KeyValue(CMDMenu.TRUNG_THU_CRAFT_ONE_YOLK, "Bánh\n1 trứng"));
        player.menus.add(new KeyValue(CMDMenu.TRUNG_THU_CRAFT_TWO_YOLK, "Bánh\n2 trứng"));
        player.menus.add(new KeyValue(CMDMenu.TRUNG_THU_EXCHANGE_COSTUME, "Đổi\nCải trang"));

        player.menus.add(new KeyValue(CMDMenu.CANCEL, "Đóng"));
        player.service.openUIConfirm(npc.templateId, content.toString(), npc.avatar, player.menus);
    }

    public static void craftMooncake(Player player, Npc npc, boolean doubleYolk) {
        if (player == null || npc == null) {
            return;
        }
        if (player.getCountEmptyBag() == 0) {
            player.service.dialogMessage("Hành trang đã đầy");
            return;
        }
        int dauXanh = getItemQuantity(player, INGREDIENT_DAU_XANH);
        int trung = getItemQuantity(player, INGREDIENT_TRUNG);
        int thitGa = getItemQuantity(player, INGREDIENT_THIT_GA);
        int botMi = getItemQuantity(player, INGREDIENT_BOT_MI);
        if (!doubleYolk) {
            if (dauXanh < 1 || trung < 1 || thitGa < 1 || botMi < 1) {
                player.service.sendThongBao("Bạn chưa đủ nguyên liệu.");
                openIngredientMenu(player, npc);
                return;
            }
            if (player.gold < ONE_YOLK_COST_GOLD) {
                player.service.sendThongBao("Cần " + Utils.currencyFormat(ONE_YOLK_COST_GOLD) + " vàng để chế bánh 1 trứng.");
                openIngredientMenu(player, npc);
                return;
            }
            consumeItems(player, INGREDIENT_DAU_XANH, 1);
            consumeItems(player, INGREDIENT_TRUNG, 1);
            consumeItems(player, INGREDIENT_THIT_GA, 1);
            consumeItems(player, INGREDIENT_BOT_MI, 1);
            player.subGold(ONE_YOLK_COST_GOLD);
            Item reward = new Item(ItemName.BANH_TRUNG_THU_1_TRUNG);
            reward.setDefaultOptions();
            reward.quantity = 1;
            player.addItem(reward);
            player.service.sendThongBao("Bạn nhận được " + reward.template.name + ".");
        } else {
            int eggsRequired = 2;
            if (dauXanh < 1 || trung < eggsRequired || thitGa < 1 || botMi < 1) {
                player.service.sendThongBao("Bạn chưa đủ nguyên liệu.");
                openIngredientMenu(player, npc);
                return;
            }
            int goldBars = getItemQuantity(player, GOLD_BAR_ID);
            if (goldBars < TWO_YOLK_GOLD_BAR_COST) {
                player.service.sendThongBao("Bạn cần " + TWO_YOLK_GOLD_BAR_COST + " thỏi vàng để chế bánh 2 trứng.");
                openIngredientMenu(player, npc);
                return;
            }
            consumeItems(player, INGREDIENT_DAU_XANH, 1);
            consumeItems(player, INGREDIENT_TRUNG, eggsRequired);
            consumeItems(player, INGREDIENT_THIT_GA, 1);
            consumeItems(player, INGREDIENT_BOT_MI, 1);
            consumeItems(player, GOLD_BAR_ID, TWO_YOLK_GOLD_BAR_COST);
            Item reward = new Item(ItemName.BANH_TRUNG_THU_2_TRUNG);
            reward.setDefaultOptions();
            reward.quantity = 1;
            player.addItem(reward);
            player.service.sendThongBao("Bạn nhận được " + reward.template.name + ".");
        }
        openIngredientMenu(player, npc);
    }

    public static void exchangeCostume(Player player, Npc npc) {
        if (player == null || npc == null) {
            return;
        }
        if (player.getCountEmptyBag() == 0) {
            player.service.dialogMessage("Hành trang đã đầy");
            openMenu(player, npc);
            return;
        }
        int carrotCount = getItemQuantity(player, CARROT_ITEM_ID);
        if (carrotCount < CARROT_EXCHANGE_REQUIRED) {
            player.service.sendThongBao("Cần đủ " + CARROT_EXCHANGE_REQUIRED + " Cà rốt để đổi cải trang.");
            openMenu(player, npc);
            return;
        }
        if (player.gold < COSTUME_GOLD_COST) {
            player.service.sendThongBao("Cần " + Utils.currencyFormat(COSTUME_GOLD_COST) + " vàng để đổi cải trang.");
            openMenu(player, npc);
            return;
        }
        consumeItems(player, CARROT_ITEM_ID, CARROT_EXCHANGE_REQUIRED);
        player.subGold(COSTUME_GOLD_COST);

        Item costume = new Item(COSTUME_ITEM_ID);
        costume.setDefaultOptions();
        costume.addItemOption(new ItemOption(77, COSTUME_PERCENT_BONUS));
        costume.addItemOption(new ItemOption(103, COSTUME_PERCENT_BONUS));
        costume.addItemOption(new ItemOption(50, COSTUME_PERCENT_BONUS));
        costume.addItemOption(new ItemOption(116, 0));
        boolean permanent = Utils.isTrue(15, 100);
        if (!permanent) {
            costume.addItemOption(new ItemOption(93, Utils.nextInt(1, 7)));
        }
        costume.quantity = 1;
        if (!player.addItem(costume)) {
            // Should not happen because bag space is checked, but ensure resources are returned if it does.
            player.addGold(COSTUME_GOLD_COST);
            Item refund = new Item(CARROT_ITEM_ID);
            refund.setDefaultOptions();
            refund.quantity = CARROT_EXCHANGE_REQUIRED;
            player.addItem(refund);
            player.service.sendThongBao("Không thể nhận cải trang, vui lòng kiểm tra hành trang.");
            openMenu(player, npc);
            return;
        }
        player.saveData();
        player.service.sendThongBao("Bạn nhận được cải trang Thỏ Đại Ca");
        openMenu(player, npc);
    }

    public static void mobReward(Player player, Mob mob) {
        if (player == null || player.zone == null || player.zone.map == null || mob == null) {
            return;
        }
        if (Utils.isTrue(0.005, 100)) {
            dropRareItem(player, mob);
        } else if (Utils.isTrue(0.5, 100)) {
            dropIngredient(player, mob, randomIngredient(), 1);

        }
    }

    public static void dropRareItem(Player player, Mob mob) {
        if (player == null || player.zone == null || player.zone.map == null || mob == null) {
            return;
        }

        // Random chọn 1 trong 8 loại item
        int randomType = Utils.nextInt(8);
        Item item = null;

        if (randomType == 0) {
            // Template 467: [{"id":"77","param":"20"},{"id":"93","param":"15"}]
            item = new Item(467);
            item.setDefaultOptions();
            item.quantity = 1;
            item.addItemOption(new ItemOption(77, 20));
            item.addItemOption(new ItemOption(93, 15));
        } else if (randomType == 1) {
            // Template 468: [{"id":"103","param":"20"},{"id":"93","param":"15"}]
            item = new Item(468);
            item.setDefaultOptions();
            item.quantity = 1;
            item.addItemOption(new ItemOption(103, 20));
            item.addItemOption(new ItemOption(93, 15));
        } else if (randomType == 2) {
            // Template 469: [{"id":"50","param":"20"},{"id":"93","param":"15"}]
            item = new Item(469);
            item.setDefaultOptions();
            item.quantity = 1;
            item.addItemOption(new ItemOption(50, 20));
            item.addItemOption(new ItemOption(93, 15));
        } else if (randomType == 3) {
            // Template 470: [{"id":"94","param":"20"},{"id":"93","param":"15"}]
            item = new Item(470);
            item.setDefaultOptions();
            item.quantity = 1;
            item.addItemOption(new ItemOption(94, 20));
            item.addItemOption(new ItemOption(93, 15));
        } else if (randomType == 4) {
            // Template 471: [{"id":"101","param":"100"},{"id":"93","param":"15"}]
            item = new Item(471);
            item.setDefaultOptions();
            item.quantity = 1;
            item.addItemOption(new ItemOption(101, 100));
            item.addItemOption(new ItemOption(93, 15));
        } else if (randomType == 5) {
            // Template 2461: [{"id":"77","param":"10"},{"id":"103","param":"10"},{"id":"50","param":"10"},{"id":"14","param":"10"}]
            item = new Item(2461);
            item.setDefaultOptions();
            item.quantity = 1;
            item.addItemOption(new ItemOption(77, 10));
            item.addItemOption(new ItemOption(103, 10));
            item.addItemOption(new ItemOption(50, 10));
            item.addItemOption(new ItemOption(14, 10));
        } else if (randomType == 6) {
            // Template 2462: [{"id":"77","param":"15"},{"id":"103","param":"15"},{"id":"50","param":"15"},{"id":"14","param":"15"}]
            item = new Item(2462);
            item.setDefaultOptions();
            item.quantity = 1;
            item.addItemOption(new ItemOption(77, 15));
            item.addItemOption(new ItemOption(103, 15));
            item.addItemOption(new ItemOption(50, 15));
            item.addItemOption(new ItemOption(14, 15));
        } else {
            // Template 2463: [{"id":"77","param":"20"},{"id":"103","param":"20"},{"id":"50","param":"20"},{"id":"14","param":"20"}]
            item = new Item(2463);
            item.setDefaultOptions();
            item.quantity = 1;
            item.addItemOption(new ItemOption(77, 20));
            item.addItemOption(new ItemOption(103, 20));
            item.addItemOption(new ItemOption(50, 20));
            item.addItemOption(new ItemOption(14, 20));
        }

        if (item == null) {
            return;
        }
        item.addItemOption(new ItemOption(30, 0));

        // Drop item theo pattern của TrungThuEvent.dropIngredient()
        ItemMap itemMap = new ItemMap(player.zone.autoIncrease++);
        itemMap.item = item;
        itemMap.playerID = Math.abs(player.id);
        itemMap.x = player.getX();
        itemMap.y = player.zone.map.collisionLand(player.getX(), player.getY());

        player.zone.addItemMap(itemMap);

        // Add vào mob items
        if (mob != null) {
            mob.items.add(itemMap);
        }

        // Thông báo cho player
        player.service.sendThongBao("Bạn nhận được " + item.template.name + "!");
    }

    public void dropItem(Item item, Player player) {
        item.setDefaultOptions();
        item.quantity = 1;
        ItemMap map = new ItemMap(player.zone.autoIncrease++);
        map.item = item;
        map.playerID = Math.abs(player.id);
        map.x = player.getX();
        map.y = player.zone.map.collisionLand(player.getX(), player.getY());
        player.zone.addItemMap(map);
        player.zone.service.addItemMap(map);
    }

    public static void bossReward(Player player, Boss boss) {
        if (player == null || boss == null || boss.zone == null || boss.zone.map == null) {
            return;
        }
        if (boss instanceof VirtualBot) {
            return;
        }
        Item item = new Item(INGREDIENT_TRUNG);
        item.setDefaultOptions();
        item.quantity = 1;
        ItemMap map = new ItemMap(boss.zone.autoIncrease++);
        map.item = item;
        map.playerID = Math.abs(player.id);
        map.x = boss.getX();
        map.y = boss.zone.map.collisionLand(boss.getX(), boss.getY());
        boss.zone.addItemMap(map);
        boss.zone.service.addItemMap(map);
    }

    public static boolean useItem(Player player, Item item) {
        if (player == null || item == null) {
            return false;
        }
        if (player.getCountEmptyBag() == 0) {
            return false;
        }
        int itemId = item.template.id;
        switch (itemId) {
            case ItemName.BANH_TRUNG_THU_1_TRUNG:
                return openOneYolkMooncake(player, item);
            case ItemName.BANH_TRUNG_THU_2_TRUNG:
                return openTwoYolkMooncake(player, item);
            case ItemName.BANH_DEO_THO_NGOC:
                player.removeItem(item.indexUI, 1);
                player.setItemTime(ItemTimeName.BANH_DEO_THO_NGOC, item.template.iconID, true, 10 * 60);
                player.service.sendThongBao("Sư phụ và đệ tử +30% TNSM trong 10 phút");
                return true;
            case ItemName.BUA_TRANG_RAM:
                player.removeItem(item.indexUI, 1);
                player.setItemTime(ItemTimeName.BUA_TRANG_RAM, item.template.iconID, true, 10 * 60);
                player.service.sendThongBao("Tăng 10% giáp trong 10 phút");
                return true;
            case ItemName.BANH_DEO_HANG_NGA:
                player.removeItem(item.indexUI, 1);
                player.setItemTime(ItemTimeName.BANH_DEO_HANG_NGA, item.template.iconID, true, 10 * 60);
                player.service.sendThongBao("Sư phụ và đệ tử +100% TNSM trong 10 phút");
                return true;
            case ItemName.TRA_SEN_TRANG_RAM:
                player.removeItem(item.indexUI, 1);
                player.setItemTime(ItemTimeName.TRA_SEN_TRANG_RAM, item.template.iconID, true, 10 * 60);
                player.service.sendThongBao("Đệ tử +50% TNSM trong 10 phút");
                return true;
            case ItemName.KEO_DEM_RAM:
                player.removeItem(item.indexUI, 1);
                player.setItemTime(ItemTimeName.KEO_DEM_RAM, item.template.iconID, true, 10 * 60);
                player.service.sendThongBao("Tăng 10% HP trong 10 phút");
                return true;
            case ItemName.BANH_NUONG_RONG_TRANG:
                player.removeItem(item.indexUI, 1);
                player.setItemTime(ItemTimeName.BANH_NUONG_RONG_TRANG, item.template.iconID, true, 10 * 60);
                player.service.sendThongBao("Tăng 10% KI trong 10 phút");
                return true;
            case ItemName.BANH_TRUNG_THU_NGUYET_QUANG:
                player.removeItem(item.indexUI, 1);
                player.setItemTime(ItemTimeName.BANH_TRUNG_THU_NGUYET_QUANG, item.template.iconID, true, 10 * 60);
                player.service.sendThongBao("Tăng 10% Sức đánh trong 10 phút");
                return true;
            case ItemName.BANH_TRUNG_THU_BE:
                if (hasOtherSpecialMooncake(player, ItemTimeName.BANH_TRUNG_THU_BE)) {
                    player.service.sendThongBao("Bạn chỉ có thể sử dụng một loại bánh Trung Thu đặc biệt cùng lúc.");
                    return true;
                }
                player.removeItem(item.indexUI, 1);
                player.setItemTime(ItemTimeName.BANH_TRUNG_THU_BE, item.template.iconID, true, 30 * 60);
                player.service.sendThongBao("Tăng 10% HP, KI, Sức đánh và +10 Chí mạng trong 30 phút");
                return true;
            case ItemName.BANH_TRUNG_THU_LON:
                if (hasOtherSpecialMooncake(player, ItemTimeName.BANH_TRUNG_THU_LON)) {
                    player.service.sendThongBao("Bạn chỉ có thể sử dụng một loại bánh Trung Thu đặc biệt cùng lúc.");
                    return true;
                }
                player.removeItem(item.indexUI, 1);
                player.setItemTime(ItemTimeName.BANH_TRUNG_THU_LON, item.template.iconID, true, 30 * 60);
                player.service.sendThongBao("Tăng 15% HP, KI, Sức đánh và +15 Chí mạng trong 30 phút");
                return true;
            case ItemName.BANH_TRUNG_THU_THAP_CAM:
                if (hasOtherSpecialMooncake(player, ItemTimeName.BANH_TRUNG_THU_THAP_CAM)) {
                    player.service.sendThongBao("Bạn chỉ có thể sử dụng một loại bánh Trung Thu đặc biệt cùng lúc.");
                    return true;
                }
                player.removeItem(item.indexUI, 1);
                player.setItemTime(ItemTimeName.BANH_TRUNG_THU_THAP_CAM, item.template.iconID, true, 30 * 60);
                player.service.sendThongBao("Tăng 20% HP, KI, Sức đánh và +20 Chí mạng trong 30 phút");
                return true;
            case ItemName.HOP_BANH_TRUNG_THU_DAC_BIET:
                return openSpecialMidAutumnBox(player, item);
            default:
                return false;
        }
    }

    private static boolean openOneYolkMooncake(Player player, Item item) {
        if (player.getCountEmptyBag() < ONE_YOLK_MIN_EMPTY_SLOTS) {
            player.service.dialogMessage("Bạn cần ít nhất " + ONE_YOLK_MIN_EMPTY_SLOTS + " ô trống trong hành trang.");
            return false;
        }
        Item reward = randomOneYolkReward();
        if (reward == null) {
            player.service.sendThongBao("Không thể mở bánh Trung Thu 1 trứng lúc này.");
            return false;
        }
        player.point1Trung++;
        player.isChangePoint = true;
        player.removeItem(item.indexUI, 1);
        List<Item> rewards = new ArrayList<>();
        addReward(rewards, reward);
        grantRewards(player, rewards, "bánh Trung Thu 1 trứng");
        return true;
    }

    private static boolean openTwoYolkMooncake(Player player, Item item) {
        if (player.getCountEmptyBag() < TWO_YOLK_MIN_EMPTY_SLOTS) {
            player.service.dialogMessage("Bạn cần ít nhất " + TWO_YOLK_MIN_EMPTY_SLOTS + " ô trống trong hành trang.");
            return false;
        }
        Item reward = randomTwoYolkReward();
        if (reward == null) {
            player.service.sendThongBao("Không thể mở bánh Trung Thu 2 trứng lúc này.");
            return false;
        }
        player.point2Trung++;
        player.isChangePoint = true;
        player.removeItem(item.indexUI, 1);
        List<Item> rewards = new ArrayList<>();
        addReward(rewards, reward);
        grantRewards(player, rewards, "bánh Trung Thu 2 trứng");
        return true;
    }

    private static boolean openSpecialMidAutumnBox(Player player, Item item) {
        if (player.getCountEmptyBag() < SPECIAL_BOX_MIN_EMPTY_SLOTS) {
            player.service.dialogMessage("Bạn cần ít nhất " + SPECIAL_BOX_MIN_EMPTY_SLOTS + " ô trống trong hành trang.");
            return false;
        }
        Item reward = randomSpecialBoxReward();
        if (reward == null) {
            player.service.sendThongBao("Không thể mở Hộp bánh Trung Thu đặc biệt lúc này.");
            return false;
        }
        player.pointHopQuaDacBiet++;
        player.isChangePoint = true;
        player.removeItem(item.indexUI, 1);
        List<Item> rewards = new ArrayList<>();
        addReward(rewards, reward);
        grantRewards(player, rewards, "Hộp bánh Trung Thu đặc biệt");
        return true;
    }

    private static Item randomOneYolkReward() {
        for (int attempt = 0; attempt < 5; attempt++) {
            Item reward;
            switch (Utils.nextInt(8)) {
                case 0:
                    reward = createConsumable(ItemName.BANH_DEO_THO_NGOC);
                    break;
                case 1:
                    reward = createRandomLevelOneItem();
                    break;
                case 2:
                    reward = createRandomDragonBall();
                    break;
                case 3:
                    reward = createRandomCollectionCard();
                    break;
                case 4:
                    reward = createMidAutumnBackItem();
                    break;
                case 5:
                    reward = createMidAutumnCostume();
                    break;
                case 6:
                    reward = createCarrotBundle();
                    break;
                default:
                    reward = createConsumable(ItemName.BUA_TRANG_RAM);
                    break;
            }
            if (reward != null) {
                return reward;
            }
        }
        return createCarrotBundle();
    }

    private static Item randomTwoYolkReward() {
        switch (Utils.nextInt(11)) {
            case 0:
                return createConsumable(ItemName.VAT_PHAM_KHANG_XINBATO);
            case 1:
                return createConsumable(ItemName.VAT_PHAM_KHANG_DRABULA);
            case 2:
                return createConsumable(ItemName.BANH_DEO_HANG_NGA);
            case 3:
                return createConsumable(ItemName.TRA_SEN_TRANG_RAM);
            case 4:
                return createConsumable(ItemName.KEO_DEM_RAM);
            case 5:
                return createConsumable(ItemName.BANH_NUONG_RONG_TRANG);
            case 6:
                return createConsumable(ItemName.BANH_TRUNG_THU_NGUYET_QUANG);
            case 7:
                return createHacHoaAn();
            case 8:
                return createPetHoMapTrang();
            case 9:
                return createProtectStone();
            default:
                return createCaiTrangThoDaiCaReward();
        }
    }

    private static Item randomSpecialBoxReward() {
        switch (Utils.nextInt(17)) {
            case 0:
                return createSpecialFlyingItem(OPTION_CRIT_DAMAGE, 1, 5);
            case 1:
                return createSpecialFlyingItem(OPTION_LAZE_DAMAGE, 1, 5);
            case 2:
                return createSpecialFlyingItem(OPTION_SUICIDE_DAMAGE, 1, 5);
            case 3:
                return createSpecialFlyingItem(OPTION_ARMOR_PERCENT, 1, 5);
            case 4:
                return createSpecialPet(OPTION_ARMOR_PERCENT);
            case 5:
                return createSpecialPet(OPTION_SUICIDE_DAMAGE);
            case 6:
                return createSpecialPet(OPTION_LAZE_DAMAGE);
            case 7:
                return createSpecialPet(OPTION_CRIT_DAMAGE);
            case 8:
                return createNgocBoiReward();
            case 9:
                return createSpecialBackItem(OPTION_CRIT_CHANCE, 1, 10);
            case 10:
                return createSpecialBackItem(OPTION_CRIT_DAMAGE, 1, 5);
            case 11:
                return createSpecialBackItem(OPTION_LAZE_DAMAGE, 1, 5);
            case 12:
                return createSpecialBackItem(OPTION_SUICIDE_DAMAGE, 1, 5);
            case 13:
                return createHacHoaAnWithBonus(OPTION_CRIT_CHANCE, 1, 10);
            case 14:
                return createHacHoaAnWithBonus(OPTION_CRIT_DAMAGE, 1, 10);
            case 15:
                return createHacHoaAnWithBonus(OPTION_LAZE_DAMAGE, 1, 10);
            default:
                return createHacHoaAnWithBonus(OPTION_SUICIDE_DAMAGE, 1, 10);
        }
    }

    private static void grantRewards(Player player, List<Item> rewards, String sourceName) {
        if (player == null || rewards == null || rewards.isEmpty()) {
            return;
        }
        StringBuilder message = new StringBuilder();
        message.append("Bạn nhận được từ ").append(sourceName).append(":\n");
        for (Item reward : rewards) {
            if (reward == null) {
                continue;
            }
            player.addItem(reward);
            message.append("- ").append(reward.template.name);
            if (reward.quantity > 1) {
                message.append(" x").append(reward.quantity);
            }
            message.append('\n');
        }
        player.service.sendThongBao(message.toString().trim());
    }

    private static void addReward(List<Item> rewards, Item reward) {
        if (rewards != null && reward != null) {
            rewards.add(reward);
        }
    }

    private static Item createConsumable(int itemId) {
        Item reward = new Item(itemId);
        reward.setDefaultOptions();
        reward.quantity = 1;
        return reward;
    }

    private static Item createRandomLevelOneItem() {
        int[] options = {ItemName.CUONG_NO, ItemName.BO_HUYET, ItemName.BO_KHI};
        int id = options[Utils.nextInt(options.length)];
        Item reward = new Item(id);
        reward.setDefaultOptions();
        reward.quantity = 1;
        return reward;
    }

    private static Item createRandomDragonBall() {
        int id = Utils.nextInt(ItemName.NGOC_RONG_3_SAO, ItemName.NGOC_RONG_7_SAO);
        Item reward = new Item(id);
        reward.setDefaultOptions();
        reward.quantity = 1;
        return reward;
    }

    private static Item createRandomCollectionCard() {
        if (Card.templates == null || Card.templates.isEmpty()) {
            return null;
        }
        int total = Card.templates.size();
        int start = Math.max(0, total - 3);
        int index = Utils.nextInt(start, total - 1);
        CardTemplate template = Card.templates.get(index);
        Item reward = new Item(template.id);
        reward.setDefaultOptions();
        reward.quantity = 1;
        return reward;
    }

    private static Item createMidAutumnBackItem() {
        Item item = new Item(ItemName.DEO_LUNG_TRUNG_THU);
        item.quantity = 1;
        item.addItemOption(new ItemOption(OPTION_HP_PERCENT, Utils.nextInt(10, 15)));
        item.addItemOption(new ItemOption(OPTION_KI_PERCENT, Utils.nextInt(10, 15)));
        item.addItemOption(new ItemOption(OPTION_DAMAGE_PERCENT, Utils.nextInt(10, 15)));
        switch (Utils.nextInt(3)) {
            case 0:
                item.addItemOption(new ItemOption(OPTION_LAZE_DAMAGE, Utils.nextInt(1, 5)));
                break;
            case 1:
                item.addItemOption(new ItemOption(OPTION_CRIT_DAMAGE, Utils.nextInt(1, 5)));
                break;
            default:
                item.addItemOption(new ItemOption(OPTION_SUICIDE_DAMAGE, Utils.nextInt(1, 5)));
                break;
        }
        applyDurationOption(item, 15);
        return item;
    }

    private static Item createMidAutumnCostume() {
        Item item = new Item(ItemName.CAI_TRANG_TRUNG_THU);
        item.quantity = 1;
        item.addItemOption(new ItemOption(OPTION_HP_PERCENT, Utils.nextInt(30, 35)));
        item.addItemOption(new ItemOption(OPTION_KI_PERCENT, Utils.nextInt(30, 35)));
        item.addItemOption(new ItemOption(OPTION_DAMAGE_PERCENT, Utils.nextInt(30, 35)));
        switch (Utils.nextInt(3)) {
            case 0:
                item.addItemOption(new ItemOption(OPTION_LAZE_DAMAGE, Utils.nextInt(1, 5)));
                break;
            case 1:
                item.addItemOption(new ItemOption(OPTION_DODGE_PERCENT, Utils.nextInt(1, 5)));
                break;
            default:
                item.addItemOption(new ItemOption(OPTION_SUICIDE_DAMAGE, Utils.nextInt(1, 5)));
                break;
        }
        applyDurationOption(item, 15);
        return item;
    }

    private static Item createCarrotBundle() {
        Item item = new Item(ItemName.CU_CA_ROT);
        item.setDefaultOptions();
        item.quantity = Utils.nextInt(1, 10);
        return item;
    }

    private static Item createHacHoaAn() {
        Item item = new Item(ItemName.NGOC_THAN_THUY);
        item.quantity = 1;
        item.addItemOption(new ItemOption(OPTION_HP_PERCENT, Utils.nextInt(1, 5)));
        item.addItemOption(new ItemOption(OPTION_KI_PERCENT, Utils.nextInt(1, 5)));
        item.addItemOption(new ItemOption(OPTION_DAMAGE_PERCENT, Utils.nextInt(1, 5)));
        int bonus = Utils.nextInt(5, 10);
        switch (Utils.nextInt(3)) {
            case 0:
                item.addItemOption(new ItemOption(OPTION_LAZE_DAMAGE, bonus));
                break;
            case 1:
                item.addItemOption(new ItemOption(OPTION_CRIT_DAMAGE, bonus));
                break;
            default:
                item.addItemOption(new ItemOption(OPTION_SUICIDE_DAMAGE, bonus));
                break;
        }
        applyDurationOption(item, 15);
        return item;
    }

    private static Item createPetHoMapTrang() {
        Item item = new Item(ItemName.PET_MEOWTH);
        item.quantity = 1;
        item.addItemOption(new ItemOption(OPTION_HP_PERCENT, Utils.nextInt(10, 15)));
        item.addItemOption(new ItemOption(OPTION_KI_PERCENT, Utils.nextInt(10, 15)));
        item.addItemOption(new ItemOption(OPTION_DAMAGE_PERCENT, Utils.nextInt(10, 15)));
        int bonus = Utils.nextInt(5, 10);
        switch (Utils.nextInt(3)) {
            case 0:
                item.addItemOption(new ItemOption(OPTION_CRIT_DAMAGE, bonus));
                break;
            case 1:
                item.addItemOption(new ItemOption(OPTION_LAZE_DAMAGE, bonus));
                break;
            default:
                item.addItemOption(new ItemOption(OPTION_BOMB_DAMAGE, bonus));
                break;
        }
        applyDurationOption(item, 15);
        return item;
    }

    private static Item createProtectStone() {
        Item item = new Item(ItemName.DA_BAO_VE_987);
        item.setDefaultOptions();
        item.quantity = 1;
        return item;
    }

    private static Item createCaiTrangThoDaiCaReward() {
        Item item = new Item(ItemName.CAI_TRANG_THO_DAI_CA);
        item.quantity = 1;
        item.addItemOption(new ItemOption(OPTION_HP_PERCENT, 20));
        item.addItemOption(new ItemOption(OPTION_KI_PERCENT, 20));
        item.addItemOption(new ItemOption(OPTION_DAMAGE_PERCENT, 20));
        item.addItemOption(new ItemOption(OPTION_KHANG_TDHS, 0));
        applyDurationOption(item, 15);
        return item;
    }

    private static Item createSpecialFlyingItem(int bonusOptionId, int bonusMin, int bonusMax) {
        Item item = new Item(ItemName.HOA_LUAN);
        item.quantity = 1;
        item.addItemOption(new ItemOption(OPTION_HP_PERCENT, Utils.nextInt(4, 8)));
        item.addItemOption(new ItemOption(OPTION_KI_PERCENT, Utils.nextInt(4, 8)));
        item.addItemOption(new ItemOption(OPTION_DAMAGE_PERCENT, Utils.nextInt(4, 8)));
        item.addItemOption(new ItemOption(bonusOptionId, Utils.nextInt(bonusMin, bonusMax)));
        applyDurationOption(item, 15);
        return item;
    }

    private static Item createSpecialPet(int bonusOptionId) {
        Item item = new Item(ItemName.PET_MEOWTH);
        item.quantity = 1;
        item.addItemOption(new ItemOption(OPTION_HP_PERCENT, Utils.nextInt(11, 16)));
        item.addItemOption(new ItemOption(OPTION_KI_PERCENT, Utils.nextInt(11, 16)));
        item.addItemOption(new ItemOption(OPTION_DAMAGE_PERCENT, Utils.nextInt(11, 16)));
        item.addItemOption(new ItemOption(bonusOptionId, Utils.nextInt(1, 10)));
        applyDurationOption(item, 15);
        return item;
    }

    private static Item createSpecialBackItem(int bonusOptionId, int bonusMin, int bonusMax) {
        Item item = new Item(ItemName.DEO_LUNG_TRUNG_THU);
        item.quantity = 1;
        item.addItemOption(new ItemOption(OPTION_HP_PERCENT, Utils.nextInt(11, 16)));
        item.addItemOption(new ItemOption(OPTION_KI_PERCENT, Utils.nextInt(11, 16)));
        item.addItemOption(new ItemOption(OPTION_DAMAGE_PERCENT, Utils.nextInt(11, 16)));
        item.addItemOption(new ItemOption(bonusOptionId, Utils.nextInt(bonusMin, bonusMax)));
        applyDurationOption(item, 15);
        return item;
    }

    private static Item createHacHoaAnWithBonus(int bonusOptionId, int bonusMin, int bonusMax) {
        Item item = new Item(ItemName.NGOC_THAN_THUY);
        item.quantity = 1;
        item.addItemOption(new ItemOption(OPTION_HP_PERCENT, Utils.nextInt(1, 5)));
        item.addItemOption(new ItemOption(OPTION_KI_PERCENT, Utils.nextInt(1, 5)));
        item.addItemOption(new ItemOption(OPTION_DAMAGE_PERCENT, Utils.nextInt(1, 5)));
        item.addItemOption(new ItemOption(bonusOptionId, Utils.nextInt(bonusMin, bonusMax)));
        applyDurationOption(item, 15);
        return item;
    }

    private static Item createNgocBoiReward() {
        Item item = new Item(ItemName.NGOC_THAN_LONG);
        item.quantity = 1;
        item.addItemOption(new ItemOption(OPTION_HP_PERCENT, Utils.nextInt(5, 10)));
        item.addItemOption(new ItemOption(OPTION_KI_PERCENT, Utils.nextInt(5, 10)));
        item.addItemOption(new ItemOption(OPTION_DAMAGE_PERCENT, Utils.nextInt(5, 10)));
        applyDurationOption(item, 15);
        return item;
    }

    private static void applyDurationOption(Item item, int permanentChancePercent) {
        if (item == null) {
            return;
        }
        boolean permanent = Utils.isTrue(permanentChancePercent, 100);
        if (!permanent) {
            int days = Utils.isTrue(1, 2) ? 1 : 3;
            item.addItemOption(new ItemOption(OPTION_DURATION_DAYS, days));
        }
    }

    private static boolean hasOtherSpecialMooncake(Player player, int currentBuffId) {
        for (int buffId : SPECIAL_MOONCAKE_TIMES) {
            if (buffId == currentBuffId) {
                continue;
            }
            if (player.exitsItemTime(buffId)) {
                return true;
            }
        }
        return false;
    }

    private static void dropIngredient(Player player, Mob mob, int itemId, int quantity) {
        Item item = new Item(itemId);
        item.setDefaultOptions();
        item.quantity = quantity;
        ItemMap map = new ItemMap(player.zone.autoIncrease++);
        map.item = item;
        map.playerID = Math.abs(player.id);
        map.x = player.getX();
        map.y = player.zone.map.collisionLand(player.getX(), player.getY());
        player.zone.addItemMap(map);
        if (mob != null) {
            mob.items.add(map);
        }
    }

    private static int randomIngredient() {
        return INGREDIENT_POOL[Utils.nextInt(INGREDIENT_POOL.length)];
    }

    private static int getItemQuantity(Player player, int itemId) {
        if (player == null || player.itemBag == null) {
            return 0;
        }
        int total = 0;
        for (Item bagItem : player.itemBag) {
            if (bagItem != null && bagItem.id == itemId) {
                total += bagItem.quantity;
            }
        }
        return total;
    }

    private static void consumeItems(Player player, int itemId, int quantity) {
        if (player == null || player.itemBag == null || quantity <= 0) {
            return;
        }
        int remaining = quantity;
        for (int i = 0; i < player.itemBag.length && remaining > 0; i++) {
            Item bagItem = player.itemBag[i];
            if (bagItem != null && bagItem.id == itemId) {
                int take = Math.min(bagItem.quantity, remaining);
                player.removeItem(i, take);
                remaining -= take;
            }
        }
    }

    private static boolean hasClaimedToday(TrungThuCandyData data) {
        if (data == null || data.getLastClaimAt() == null) {
            return false;
        }
        LocalDate lastClaimDate = LocalDateTime.ofInstant(data.getLastClaimAt(), ZONE_ID).toLocalDate();
        LocalDate today = LocalDate.now(ZONE_ID);
        return !lastClaimDate.isBefore(today);
    }

    private static boolean isInRewardTime(Instant instant) {
        LocalTime now = LocalDateTime.now().toLocalTime();
        return !now.isBefore(START_TIME) && now.isBefore(END_TIME);
    }

    private static TrungThuCandyData createNewData(int playerId, Instant now) {
        TrungThuCandyData data = new TrungThuCandyData();
        data.setPlayerId(playerId);
        data.setCandyBalance(0);
        data.setCreatedAt(now);
        data.setUpdatedAt(now);
        return data;
    }

    private static int getBalance(Player player) {
        if (player != null && player.getItemInBag(2467) != null) {
            return player.getItemInBag(2467).quantity == 0 ? 1 : player.getItemInBag(2467).quantity;
        }
        return 0;
    }
}
