/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ngocrong.server;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.net.Proxy;
import java.net.InetSocketAddress;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Administrator
 */
public class TelegramBotSender {

    public static String BOT_TOKEN;
    public static String CHAT_ID;
    public static boolean isSendTele = false;
    public static boolean useProxy = false;  

     private static final String PROXY_HOST = "148.163.101.4";
    private static final int PROXY_PORT = 11677;
    private static final String PROXY_USERNAME = "dfsg68uwerg";
    private static final String PROXY_PASSWORD = "sdf356y45";

    public static void sendCCU() {
        if (!isSendTele) {
            return;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String formattedTime = LocalDateTime.now().format(formatter);
        String text = "GWENDEV STUDIO - CHECKER SERVER" + Config.serverID() + "   -   " + formattedTime + "\n"
                + "Tổng CCU : " + SessionManager.sessions.size() + " Session\n"
                + "     -      " + SessionManager.getCountPlayer() + " Player Online";
        sendMessageTelegram(text);
        System.err.println(text);
    }

    public static void sendMessageTelegram(String message) {
        try {
            // Mã hóa message
            String encodedMessage = URLEncoder.encode(message, "UTF-8");

            // Tạo URL gửi tin nhắn
            String urlString = "https://api.telegram.org/bot" + BOT_TOKEN + "/sendMessage";
            URL url = new URL(urlString);

            HttpURLConnection conn;

            if (useProxy) {
                // Sử dụng proxy SOCKS5
                Proxy proxy = new Proxy(Proxy.Type.SOCKS, new InetSocketAddress(PROXY_HOST, PROXY_PORT));

                // Set proxy authentication
                Authenticator proxyAuth = new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(PROXY_USERNAME, PROXY_PASSWORD.toCharArray());
                    }
                };

                // Mở kết nối qua proxy
                conn = (HttpURLConnection) url.openConnection(proxy);

                // Set authenticator cho connection này
                Authenticator.setDefault(proxyAuth);

                System.out.println("🔄 Đang gửi tin nhắn qua proxy...");
            } else {
                // Kết nối trực tiếp không qua proxy
                conn = (HttpURLConnection) url.openConnection();
                System.out.println("🔄 Đang gửi tin nhắn trực tiếp...");
            }

            // Cấu hình request
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(30000);

            // Tạo dữ liệu gửi đi
            String data = "chat_id=" + CHAT_ID + "&text=" + encodedMessage;

            // Gửi dữ liệu
            try (OutputStream os = conn.getOutputStream()) {
                os.write(data.getBytes());
                os.flush();
            }

            // Kiểm tra phản hồi
            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                String connectionType = useProxy ? "qua proxy" : "trực tiếp";
                System.out.println("✅ Đã gửi tin nhắn thành công " + connectionType + "!");
            } else {
                System.out.println("❌ Gửi tin nhắn thất bại. Mã lỗi: " + responseCode);
            }

        } catch (Exception e) {
            String connectionType = useProxy ? "qua proxy" : "trực tiếp";
            System.out.println("❌ Lỗi khi gửi tin nhắn " + connectionType + ": " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Phương thức để bật/tắt việc sử dụng proxy
     *
     * @param enabled true để sử dụng proxy, false để kết nối trực tiếp
     */
    public static void setProxyEnabled(boolean enabled) {
        useProxy = enabled;
        String status = enabled ? "BẬT" : "TẮT";
        System.out.println("🔧 Đã " + status + " chế độ sử dụng proxy cho Telegram Bot");
    }

    /**
     * Kiểm tra trạng thái proxy hiện tại
     *
     * @return true nếu đang sử dụng proxy, false nếu không
     */
    public static boolean isProxyEnabled() {
        return useProxy;
    }
}
