package com.ngocrong.data;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "nr_trung_thu_candy")
public class TrungThuCandyData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "player_id", unique = true, nullable = false)
    private Integer playerId;

    @Column(name = "candy_balance")
    private Integer candyBalance;

    @Column(name = "last_claim_at")
    private Instant lastClaimAt;

    @Column(name = "last_claim_amount")
    private Integer lastClaimAmount;

    @Column(name = "created_at")
    private Instant createdAt;

    @Column(name = "updated_at")
    private Instant updatedAt;
}
